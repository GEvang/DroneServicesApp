package io.mavsdk.camera;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Camera implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Camera.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private CameraServiceGrpc.CameraServiceStub stub;

  private volatile boolean isInitialized = false;

  public Camera(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Camera() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = CameraServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class CameraException extends MavsdkException {
    private CameraResult.Result code;
    private String description;

    public CameraException(CameraResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public CameraResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum Mode {
      
      UNKNOWN {
        @Override
        protected CameraProto.Mode rpcMode() {
          return CameraProto.Mode.MODE_UNKNOWN;
        }
      }, 
      PHOTO {
        @Override
        protected CameraProto.Mode rpcMode() {
          return CameraProto.Mode.MODE_PHOTO;
        }
      }, 
      VIDEO {
        @Override
        protected CameraProto.Mode rpcMode() {
          return CameraProto.Mode.MODE_VIDEO;
        }
      };

      protected static Mode translateFromRpc(CameraProto.Mode rpcMode) {
        switch (rpcMode) {
          case MODE_UNKNOWN: default: 
            return Mode.UNKNOWN;
          case MODE_PHOTO: 
            return Mode.PHOTO;
          case MODE_VIDEO: 
            return Mode.VIDEO;
        }
      }

      protected abstract CameraProto.Mode rpcMode();
    }
    public enum PhotosRange {
      
      ALL {
        @Override
        protected CameraProto.PhotosRange rpcPhotosRange() {
          return CameraProto.PhotosRange.PHOTOS_RANGE_ALL;
        }
      }, 
      SINCE_CONNECTION {
        @Override
        protected CameraProto.PhotosRange rpcPhotosRange() {
          return CameraProto.PhotosRange.PHOTOS_RANGE_SINCE_CONNECTION;
        }
      };

      protected static PhotosRange translateFromRpc(CameraProto.PhotosRange rpcPhotosRange) {
        switch (rpcPhotosRange) {
          case PHOTOS_RANGE_ALL: default: 
            return PhotosRange.ALL;
          case PHOTOS_RANGE_SINCE_CONNECTION: 
            return PhotosRange.SINCE_CONNECTION;
        }
      }

      protected abstract CameraProto.PhotosRange rpcPhotosRange();
    }


    public static class CameraResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_SUCCESS;
            }
          }, 
          IN_PROGRESS {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_IN_PROGRESS;
            }
          }, 
          BUSY {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_BUSY;
            }
          }, 
          DENIED {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_DENIED;
            }
          }, 
          ERROR {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_ERROR;
            }
          }, 
          TIMEOUT {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_TIMEOUT;
            }
          }, 
          WRONG_ARGUMENT {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_WRONG_ARGUMENT;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected CameraProto.CameraResult.Result rpcResult() {
              return CameraProto.CameraResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(CameraProto.CameraResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_IN_PROGRESS: 
                return Result.IN_PROGRESS;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_DENIED: 
                return Result.DENIED;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_WRONG_ARGUMENT: 
                return Result.WRONG_ARGUMENT;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract CameraProto.CameraResult.Result rpcResult();
        }

      public CameraResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected CameraProto.CameraResult rpcCameraResult() {
        return CameraProto.CameraResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static CameraResult translateFromRpc(CameraProto.CameraResult rpcCameraResult) {
        return new CameraResult(
                Result.translateFromRpc(rpcCameraResult.getResult()),
                rpcCameraResult.getResultStr());
      }
    }


    public static class Position {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float relativeAltitudeM;

      public Position(Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float relativeAltitudeM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.relativeAltitudeM = relativeAltitudeM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getRelativeAltitudeM() {
        return relativeAltitudeM;
      }

      protected CameraProto.Position rpcPosition() {
        return CameraProto.Position.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setRelativeAltitudeM(this.relativeAltitudeM)
          .build();
      }

      protected static Position translateFromRpc(CameraProto.Position rpcPosition) {
        return new Position(
                rpcPosition.getLatitudeDeg(),
                rpcPosition.getLongitudeDeg(),
                rpcPosition.getAbsoluteAltitudeM(),
                rpcPosition.getRelativeAltitudeM());
      }
    }


    public static class Quaternion {
      private Float w;
      private Float x;
      private Float y;
      private Float z;

      public Quaternion(Float w, Float x, Float y, Float z) {
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
      }
      public Float getW() {
        return w;
      }
      public Float getX() {
        return x;
      }
      public Float getY() {
        return y;
      }
      public Float getZ() {
        return z;
      }

      protected CameraProto.Quaternion rpcQuaternion() {
        return CameraProto.Quaternion.newBuilder()
          .setW(this.w)
          .setX(this.x)
          .setY(this.y)
          .setZ(this.z)
          .build();
      }

      protected static Quaternion translateFromRpc(CameraProto.Quaternion rpcQuaternion) {
        return new Quaternion(
                rpcQuaternion.getW(),
                rpcQuaternion.getX(),
                rpcQuaternion.getY(),
                rpcQuaternion.getZ());
      }
    }


    public static class EulerAngle {
      private Float rollDeg;
      private Float pitchDeg;
      private Float yawDeg;

      public EulerAngle(Float rollDeg, Float pitchDeg, Float yawDeg) {
        this.rollDeg = rollDeg;
        this.pitchDeg = pitchDeg;
        this.yawDeg = yawDeg;
      }
      public Float getRollDeg() {
        return rollDeg;
      }
      public Float getPitchDeg() {
        return pitchDeg;
      }
      public Float getYawDeg() {
        return yawDeg;
      }

      protected CameraProto.EulerAngle rpcEulerAngle() {
        return CameraProto.EulerAngle.newBuilder()
          .setRollDeg(this.rollDeg)
          .setPitchDeg(this.pitchDeg)
          .setYawDeg(this.yawDeg)
          .build();
      }

      protected static EulerAngle translateFromRpc(CameraProto.EulerAngle rpcEulerAngle) {
        return new EulerAngle(
                rpcEulerAngle.getRollDeg(),
                rpcEulerAngle.getPitchDeg(),
                rpcEulerAngle.getYawDeg());
      }
    }


    public static class CaptureInfo {
      private Position position;
      private Quaternion attitudeQuaternion;
      private EulerAngle attitudeEulerAngle;
      private Long timeUtcUs;
      private Boolean isSuccess;
      private Integer index;
      private String fileUrl;

      public CaptureInfo(Position position, Quaternion attitudeQuaternion, EulerAngle attitudeEulerAngle, Long timeUtcUs, Boolean isSuccess, Integer index, String fileUrl) {
        this.position = position;
        this.attitudeQuaternion = attitudeQuaternion;
        this.attitudeEulerAngle = attitudeEulerAngle;
        this.timeUtcUs = timeUtcUs;
        this.isSuccess = isSuccess;
        this.index = index;
        this.fileUrl = fileUrl;
      }
      public Position getPosition() {
        return position;
      }
      public Quaternion getAttitudeQuaternion() {
        return attitudeQuaternion;
      }
      public EulerAngle getAttitudeEulerAngle() {
        return attitudeEulerAngle;
      }
      public Long getTimeUtcUs() {
        return timeUtcUs;
      }
      public Boolean getIsSuccess() {
        return isSuccess;
      }
      public Integer getIndex() {
        return index;
      }
      public String getFileUrl() {
        return fileUrl;
      }

      protected CameraProto.CaptureInfo rpcCaptureInfo() {
        return CameraProto.CaptureInfo.newBuilder()
          .setPosition(this.position.rpcPosition())
          .setAttitudeQuaternion(this.attitudeQuaternion.rpcQuaternion())
          .setAttitudeEulerAngle(this.attitudeEulerAngle.rpcEulerAngle())
          .setTimeUtcUs(this.timeUtcUs)
          .setIsSuccess(this.isSuccess)
          .setIndex(this.index)
          .setFileUrl(this.fileUrl)
          .build();
      }

      protected static CaptureInfo translateFromRpc(CameraProto.CaptureInfo rpcCaptureInfo) {
        return new CaptureInfo(
                Position.translateFromRpc(rpcCaptureInfo.getPosition()),
                Quaternion.translateFromRpc(rpcCaptureInfo.getAttitudeQuaternion()),
                EulerAngle.translateFromRpc(rpcCaptureInfo.getAttitudeEulerAngle()),
                rpcCaptureInfo.getTimeUtcUs(),
                rpcCaptureInfo.getIsSuccess(),
                rpcCaptureInfo.getIndex(),
                rpcCaptureInfo.getFileUrl());
      }
    }


    public static class VideoStreamSettings {
      private Float frameRateHz;
      private Integer horizontalResolutionPix;
      private Integer verticalResolutionPix;
      private Integer bitRateBS;
      private Integer rotationDeg;
      private String uri;
      private Float horizontalFovDeg;

      public VideoStreamSettings(Float frameRateHz, Integer horizontalResolutionPix, Integer verticalResolutionPix, Integer bitRateBS, Integer rotationDeg, String uri, Float horizontalFovDeg) {
        this.frameRateHz = frameRateHz;
        this.horizontalResolutionPix = horizontalResolutionPix;
        this.verticalResolutionPix = verticalResolutionPix;
        this.bitRateBS = bitRateBS;
        this.rotationDeg = rotationDeg;
        this.uri = uri;
        this.horizontalFovDeg = horizontalFovDeg;
      }
      public Float getFrameRateHz() {
        return frameRateHz;
      }
      public Integer getHorizontalResolutionPix() {
        return horizontalResolutionPix;
      }
      public Integer getVerticalResolutionPix() {
        return verticalResolutionPix;
      }
      public Integer getBitRateBS() {
        return bitRateBS;
      }
      public Integer getRotationDeg() {
        return rotationDeg;
      }
      public String getUri() {
        return uri;
      }
      public Float getHorizontalFovDeg() {
        return horizontalFovDeg;
      }

      protected CameraProto.VideoStreamSettings rpcVideoStreamSettings() {
        return CameraProto.VideoStreamSettings.newBuilder()
          .setFrameRateHz(this.frameRateHz)
          .setHorizontalResolutionPix(this.horizontalResolutionPix)
          .setVerticalResolutionPix(this.verticalResolutionPix)
          .setBitRateBS(this.bitRateBS)
          .setRotationDeg(this.rotationDeg)
          .setUri(this.uri)
          .setHorizontalFovDeg(this.horizontalFovDeg)
          .build();
      }

      protected static VideoStreamSettings translateFromRpc(CameraProto.VideoStreamSettings rpcVideoStreamSettings) {
        return new VideoStreamSettings(
                rpcVideoStreamSettings.getFrameRateHz(),
                rpcVideoStreamSettings.getHorizontalResolutionPix(),
                rpcVideoStreamSettings.getVerticalResolutionPix(),
                rpcVideoStreamSettings.getBitRateBS(),
                rpcVideoStreamSettings.getRotationDeg(),
                rpcVideoStreamSettings.getUri(),
                rpcVideoStreamSettings.getHorizontalFovDeg());
      }
    }


    public static class VideoStreamInfo {
      private VideoStreamSettings settings;
      private VideoStreamStatus status;
      private VideoStreamSpectrum spectrum;
      
        public enum VideoStreamStatus {
          
          NOT_RUNNING {
            @Override
            protected CameraProto.VideoStreamInfo.VideoStreamStatus rpcVideoStreamStatus() {
              return CameraProto.VideoStreamInfo.VideoStreamStatus.VIDEO_STREAM_STATUS_NOT_RUNNING;
            }
          }, 
          IN_PROGRESS {
            @Override
            protected CameraProto.VideoStreamInfo.VideoStreamStatus rpcVideoStreamStatus() {
              return CameraProto.VideoStreamInfo.VideoStreamStatus.VIDEO_STREAM_STATUS_IN_PROGRESS;
            }
          };

          protected static VideoStreamStatus translateFromRpc(CameraProto.VideoStreamInfo.VideoStreamStatus rpcVideoStreamStatus) {
            switch (rpcVideoStreamStatus) {
              case VIDEO_STREAM_STATUS_NOT_RUNNING: default: 
                return VideoStreamStatus.NOT_RUNNING;
              case VIDEO_STREAM_STATUS_IN_PROGRESS: 
                return VideoStreamStatus.IN_PROGRESS;
            }
          }

          protected abstract CameraProto.VideoStreamInfo.VideoStreamStatus rpcVideoStreamStatus();
        }
      
        public enum VideoStreamSpectrum {
          
          UNKNOWN {
            @Override
            protected CameraProto.VideoStreamInfo.VideoStreamSpectrum rpcVideoStreamSpectrum() {
              return CameraProto.VideoStreamInfo.VideoStreamSpectrum.VIDEO_STREAM_SPECTRUM_UNKNOWN;
            }
          }, 
          VISIBLE_LIGHT {
            @Override
            protected CameraProto.VideoStreamInfo.VideoStreamSpectrum rpcVideoStreamSpectrum() {
              return CameraProto.VideoStreamInfo.VideoStreamSpectrum.VIDEO_STREAM_SPECTRUM_VISIBLE_LIGHT;
            }
          }, 
          INFRARED {
            @Override
            protected CameraProto.VideoStreamInfo.VideoStreamSpectrum rpcVideoStreamSpectrum() {
              return CameraProto.VideoStreamInfo.VideoStreamSpectrum.VIDEO_STREAM_SPECTRUM_INFRARED;
            }
          };

          protected static VideoStreamSpectrum translateFromRpc(CameraProto.VideoStreamInfo.VideoStreamSpectrum rpcVideoStreamSpectrum) {
            switch (rpcVideoStreamSpectrum) {
              case VIDEO_STREAM_SPECTRUM_UNKNOWN: default: 
                return VideoStreamSpectrum.UNKNOWN;
              case VIDEO_STREAM_SPECTRUM_VISIBLE_LIGHT: 
                return VideoStreamSpectrum.VISIBLE_LIGHT;
              case VIDEO_STREAM_SPECTRUM_INFRARED: 
                return VideoStreamSpectrum.INFRARED;
            }
          }

          protected abstract CameraProto.VideoStreamInfo.VideoStreamSpectrum rpcVideoStreamSpectrum();
        }

      public VideoStreamInfo(VideoStreamSettings settings, VideoStreamStatus status, VideoStreamSpectrum spectrum) {
        this.settings = settings;
        this.status = status;
        this.spectrum = spectrum;
      }
      public VideoStreamSettings getSettings() {
        return settings;
      }
      public VideoStreamStatus getStatus() {
        return status;
      }
      public VideoStreamSpectrum getSpectrum() {
        return spectrum;
      }

      protected CameraProto.VideoStreamInfo rpcVideoStreamInfo() {
        return CameraProto.VideoStreamInfo.newBuilder()
          .setSettings(this.settings.rpcVideoStreamSettings())
          .setStatus(this.status.rpcVideoStreamStatus())
          .setSpectrum(this.spectrum.rpcVideoStreamSpectrum())
          .build();
      }

      protected static VideoStreamInfo translateFromRpc(CameraProto.VideoStreamInfo rpcVideoStreamInfo) {
        return new VideoStreamInfo(
                VideoStreamSettings.translateFromRpc(rpcVideoStreamInfo.getSettings()),
                VideoStreamStatus.translateFromRpc(rpcVideoStreamInfo.getStatus()),
                VideoStreamSpectrum.translateFromRpc(rpcVideoStreamInfo.getSpectrum()));
      }
    }


    public static class Status {
      private Boolean videoOn;
      private Boolean photoIntervalOn;
      private Float usedStorageMib;
      private Float availableStorageMib;
      private Float totalStorageMib;
      private Float recordingTimeS;
      private String mediaFolderName;
      private StorageStatus storageStatus;
      private Integer storageId;
      private StorageType storageType;
      
        public enum StorageStatus {
          
          NOT_AVAILABLE {
            @Override
            protected CameraProto.Status.StorageStatus rpcStorageStatus() {
              return CameraProto.Status.StorageStatus.STORAGE_STATUS_NOT_AVAILABLE;
            }
          }, 
          UNFORMATTED {
            @Override
            protected CameraProto.Status.StorageStatus rpcStorageStatus() {
              return CameraProto.Status.StorageStatus.STORAGE_STATUS_UNFORMATTED;
            }
          }, 
          FORMATTED {
            @Override
            protected CameraProto.Status.StorageStatus rpcStorageStatus() {
              return CameraProto.Status.StorageStatus.STORAGE_STATUS_FORMATTED;
            }
          }, 
          NOT_SUPPORTED {
            @Override
            protected CameraProto.Status.StorageStatus rpcStorageStatus() {
              return CameraProto.Status.StorageStatus.STORAGE_STATUS_NOT_SUPPORTED;
            }
          };

          protected static StorageStatus translateFromRpc(CameraProto.Status.StorageStatus rpcStorageStatus) {
            switch (rpcStorageStatus) {
              case STORAGE_STATUS_NOT_AVAILABLE: default: 
                return StorageStatus.NOT_AVAILABLE;
              case STORAGE_STATUS_UNFORMATTED: 
                return StorageStatus.UNFORMATTED;
              case STORAGE_STATUS_FORMATTED: 
                return StorageStatus.FORMATTED;
              case STORAGE_STATUS_NOT_SUPPORTED: 
                return StorageStatus.NOT_SUPPORTED;
            }
          }

          protected abstract CameraProto.Status.StorageStatus rpcStorageStatus();
        }
      
        public enum StorageType {
          
          UNKNOWN {
            @Override
            protected CameraProto.Status.StorageType rpcStorageType() {
              return CameraProto.Status.StorageType.STORAGE_TYPE_UNKNOWN;
            }
          }, 
          USB_STICK {
            @Override
            protected CameraProto.Status.StorageType rpcStorageType() {
              return CameraProto.Status.StorageType.STORAGE_TYPE_USB_STICK;
            }
          }, 
          SD {
            @Override
            protected CameraProto.Status.StorageType rpcStorageType() {
              return CameraProto.Status.StorageType.STORAGE_TYPE_SD;
            }
          }, 
          MICROSD {
            @Override
            protected CameraProto.Status.StorageType rpcStorageType() {
              return CameraProto.Status.StorageType.STORAGE_TYPE_MICROSD;
            }
          }, 
          HD {
            @Override
            protected CameraProto.Status.StorageType rpcStorageType() {
              return CameraProto.Status.StorageType.STORAGE_TYPE_HD;
            }
          }, 
          OTHER {
            @Override
            protected CameraProto.Status.StorageType rpcStorageType() {
              return CameraProto.Status.StorageType.STORAGE_TYPE_OTHER;
            }
          };

          protected static StorageType translateFromRpc(CameraProto.Status.StorageType rpcStorageType) {
            switch (rpcStorageType) {
              case STORAGE_TYPE_UNKNOWN: default: 
                return StorageType.UNKNOWN;
              case STORAGE_TYPE_USB_STICK: 
                return StorageType.USB_STICK;
              case STORAGE_TYPE_SD: 
                return StorageType.SD;
              case STORAGE_TYPE_MICROSD: 
                return StorageType.MICROSD;
              case STORAGE_TYPE_HD: 
                return StorageType.HD;
              case STORAGE_TYPE_OTHER: 
                return StorageType.OTHER;
            }
          }

          protected abstract CameraProto.Status.StorageType rpcStorageType();
        }

      public Status(Boolean videoOn, Boolean photoIntervalOn, Float usedStorageMib, Float availableStorageMib, Float totalStorageMib, Float recordingTimeS, String mediaFolderName, StorageStatus storageStatus, Integer storageId, StorageType storageType) {
        this.videoOn = videoOn;
        this.photoIntervalOn = photoIntervalOn;
        this.usedStorageMib = usedStorageMib;
        this.availableStorageMib = availableStorageMib;
        this.totalStorageMib = totalStorageMib;
        this.recordingTimeS = recordingTimeS;
        this.mediaFolderName = mediaFolderName;
        this.storageStatus = storageStatus;
        this.storageId = storageId;
        this.storageType = storageType;
      }
      public Boolean getVideoOn() {
        return videoOn;
      }
      public Boolean getPhotoIntervalOn() {
        return photoIntervalOn;
      }
      public Float getUsedStorageMib() {
        return usedStorageMib;
      }
      public Float getAvailableStorageMib() {
        return availableStorageMib;
      }
      public Float getTotalStorageMib() {
        return totalStorageMib;
      }
      public Float getRecordingTimeS() {
        return recordingTimeS;
      }
      public String getMediaFolderName() {
        return mediaFolderName;
      }
      public StorageStatus getStorageStatus() {
        return storageStatus;
      }
      public Integer getStorageId() {
        return storageId;
      }
      public StorageType getStorageType() {
        return storageType;
      }

      protected CameraProto.Status rpcStatus() {
        return CameraProto.Status.newBuilder()
          .setVideoOn(this.videoOn)
          .setPhotoIntervalOn(this.photoIntervalOn)
          .setUsedStorageMib(this.usedStorageMib)
          .setAvailableStorageMib(this.availableStorageMib)
          .setTotalStorageMib(this.totalStorageMib)
          .setRecordingTimeS(this.recordingTimeS)
          .setMediaFolderName(this.mediaFolderName)
          .setStorageStatus(this.storageStatus.rpcStorageStatus())
          .setStorageId(this.storageId)
          .setStorageType(this.storageType.rpcStorageType())
          .build();
      }

      protected static Status translateFromRpc(CameraProto.Status rpcStatus) {
        return new Status(
                rpcStatus.getVideoOn(),
                rpcStatus.getPhotoIntervalOn(),
                rpcStatus.getUsedStorageMib(),
                rpcStatus.getAvailableStorageMib(),
                rpcStatus.getTotalStorageMib(),
                rpcStatus.getRecordingTimeS(),
                rpcStatus.getMediaFolderName(),
                StorageStatus.translateFromRpc(rpcStatus.getStorageStatus()),
                rpcStatus.getStorageId(),
                StorageType.translateFromRpc(rpcStatus.getStorageType()));
      }
    }


    public static class Option {
      private String optionId;
      private String optionDescription;

      public Option(String optionId, String optionDescription) {
        this.optionId = optionId;
        this.optionDescription = optionDescription;
      }
      public String getOptionId() {
        return optionId;
      }
      public String getOptionDescription() {
        return optionDescription;
      }

      protected CameraProto.Option rpcOption() {
        return CameraProto.Option.newBuilder()
          .setOptionId(this.optionId)
          .setOptionDescription(this.optionDescription)
          .build();
      }

      protected static Option translateFromRpc(CameraProto.Option rpcOption) {
        return new Option(
                rpcOption.getOptionId(),
                rpcOption.getOptionDescription());
      }
    }


    public static class Setting {
      private String settingId;
      private String settingDescription;
      private Option option;
      private Boolean isRange;

      public Setting(String settingId, String settingDescription, Option option, Boolean isRange) {
        this.settingId = settingId;
        this.settingDescription = settingDescription;
        this.option = option;
        this.isRange = isRange;
      }
      public String getSettingId() {
        return settingId;
      }
      public String getSettingDescription() {
        return settingDescription;
      }
      public Option getOption() {
        return option;
      }
      public Boolean getIsRange() {
        return isRange;
      }

      protected CameraProto.Setting rpcSetting() {
        return CameraProto.Setting.newBuilder()
          .setSettingId(this.settingId)
          .setSettingDescription(this.settingDescription)
          .setOption(this.option.rpcOption())
          .setIsRange(this.isRange)
          .build();
      }

      protected static Setting translateFromRpc(CameraProto.Setting rpcSetting) {
        return new Setting(
                rpcSetting.getSettingId(),
                rpcSetting.getSettingDescription(),
                Option.translateFromRpc(rpcSetting.getOption()),
                rpcSetting.getIsRange());
      }
    }


    public static class SettingOptions {
      private String settingId;
      private String settingDescription;
      private List<Option> options;
      private Boolean isRange;

      public SettingOptions(String settingId, String settingDescription, List<Option> options, Boolean isRange) {
        this.settingId = settingId;
        this.settingDescription = settingDescription;
        this.options = options;
        this.isRange = isRange;
      }
      public String getSettingId() {
        return settingId;
      }
      public String getSettingDescription() {
        return settingDescription;
      }
      public List<Option> getOptions() {
        return options;
      }
      public Boolean getIsRange() {
        return isRange;
      }

      protected CameraProto.SettingOptions rpcSettingOptions() {
        return CameraProto.SettingOptions.newBuilder()
          .setSettingId(this.settingId)
          .setSettingDescription(this.settingDescription)
          .addAllOptions(options.stream().map(Option::rpcOption).collect(Collectors.toList()))
          .setIsRange(this.isRange)
          .build();
      }

      protected static SettingOptions translateFromRpc(CameraProto.SettingOptions rpcSettingOptions) {
        return new SettingOptions(
                rpcSettingOptions.getSettingId(),
                rpcSettingOptions.getSettingDescription(),
                    rpcSettingOptions.getOptionsList().stream().map(Option::translateFromRpc).collect(Collectors.toList()),
                rpcSettingOptions.getIsRange());
      }
    }


    public static class Information {
      private String vendorName;
      private String modelName;
      private Float focalLengthMm;
      private Float horizontalSensorSizeMm;
      private Float verticalSensorSizeMm;
      private Integer horizontalResolutionPx;
      private Integer verticalResolutionPx;

      public Information(String vendorName, String modelName, Float focalLengthMm, Float horizontalSensorSizeMm, Float verticalSensorSizeMm, Integer horizontalResolutionPx, Integer verticalResolutionPx) {
        this.vendorName = vendorName;
        this.modelName = modelName;
        this.focalLengthMm = focalLengthMm;
        this.horizontalSensorSizeMm = horizontalSensorSizeMm;
        this.verticalSensorSizeMm = verticalSensorSizeMm;
        this.horizontalResolutionPx = horizontalResolutionPx;
        this.verticalResolutionPx = verticalResolutionPx;
      }
      public String getVendorName() {
        return vendorName;
      }
      public String getModelName() {
        return modelName;
      }
      public Float getFocalLengthMm() {
        return focalLengthMm;
      }
      public Float getHorizontalSensorSizeMm() {
        return horizontalSensorSizeMm;
      }
      public Float getVerticalSensorSizeMm() {
        return verticalSensorSizeMm;
      }
      public Integer getHorizontalResolutionPx() {
        return horizontalResolutionPx;
      }
      public Integer getVerticalResolutionPx() {
        return verticalResolutionPx;
      }

      protected CameraProto.Information rpcInformation() {
        return CameraProto.Information.newBuilder()
          .setVendorName(this.vendorName)
          .setModelName(this.modelName)
          .setFocalLengthMm(this.focalLengthMm)
          .setHorizontalSensorSizeMm(this.horizontalSensorSizeMm)
          .setVerticalSensorSizeMm(this.verticalSensorSizeMm)
          .setHorizontalResolutionPx(this.horizontalResolutionPx)
          .setVerticalResolutionPx(this.verticalResolutionPx)
          .build();
      }

      protected static Information translateFromRpc(CameraProto.Information rpcInformation) {
        return new Information(
                rpcInformation.getVendorName(),
                rpcInformation.getModelName(),
                rpcInformation.getFocalLengthMm(),
                rpcInformation.getHorizontalSensorSizeMm(),
                rpcInformation.getVerticalSensorSizeMm(),
                rpcInformation.getHorizontalResolutionPx(),
                rpcInformation.getVerticalResolutionPx());
      }
    }


    @CheckReturnValue
    public Completable prepare() {

      CameraProto.PrepareRequest request = CameraProto.PrepareRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.prepare(request, new StreamObserver<CameraProto.PrepareResponse>() {

          @Override
          public void onNext(CameraProto.PrepareResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable takePhoto() {

      CameraProto.TakePhotoRequest request = CameraProto.TakePhotoRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.takePhoto(request, new StreamObserver<CameraProto.TakePhotoResponse>() {

          @Override
          public void onNext(CameraProto.TakePhotoResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable startPhotoInterval(@NonNull Float intervalS) {

      CameraProto.StartPhotoIntervalRequest request = CameraProto.StartPhotoIntervalRequest.newBuilder()
        .setIntervalS(intervalS)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startPhotoInterval(request, new StreamObserver<CameraProto.StartPhotoIntervalResponse>() {

          @Override
          public void onNext(CameraProto.StartPhotoIntervalResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable stopPhotoInterval() {

      CameraProto.StopPhotoIntervalRequest request = CameraProto.StopPhotoIntervalRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.stopPhotoInterval(request, new StreamObserver<CameraProto.StopPhotoIntervalResponse>() {

          @Override
          public void onNext(CameraProto.StopPhotoIntervalResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable startVideo() {

      CameraProto.StartVideoRequest request = CameraProto.StartVideoRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startVideo(request, new StreamObserver<CameraProto.StartVideoResponse>() {

          @Override
          public void onNext(CameraProto.StartVideoResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable stopVideo() {

      CameraProto.StopVideoRequest request = CameraProto.StopVideoRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.stopVideo(request, new StreamObserver<CameraProto.StopVideoResponse>() {

          @Override
          public void onNext(CameraProto.StopVideoResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable startVideoStreaming() {

      CameraProto.StartVideoStreamingRequest request = CameraProto.StartVideoStreamingRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startVideoStreaming(request, new StreamObserver<CameraProto.StartVideoStreamingResponse>() {

          @Override
          public void onNext(CameraProto.StartVideoStreamingResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable stopVideoStreaming() {

      CameraProto.StopVideoStreamingRequest request = CameraProto.StopVideoStreamingRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.stopVideoStreaming(request, new StreamObserver<CameraProto.StopVideoStreamingResponse>() {

          @Override
          public void onNext(CameraProto.StopVideoStreamingResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setMode(@NonNull Mode mode) {

      CameraProto.SetModeRequest request = CameraProto.SetModeRequest.newBuilder()
        .setMode(mode.rpcMode())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setMode(request, new StreamObserver<CameraProto.SetModeResponse>() {

          @Override
          public void onNext(CameraProto.SetModeResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<List<Camera.CaptureInfo>> listPhotos(@NonNull PhotosRange photosRange) {
      CameraProto.ListPhotosRequest request = CameraProto.ListPhotosRequest.newBuilder()
        .setPhotosRange(photosRange.rpcPhotosRange())
        .build();

      Single<List<Camera.CaptureInfo>> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.listPhotos(request, new StreamObserver<CameraProto.ListPhotosResponse>() {

          @Override
          public void onNext(CameraProto.ListPhotosResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getCaptureInfosList().stream().map(CaptureInfo::translateFromRpc).collect(Collectors.toList()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<Camera.Mode> modeProcessor = PublishProcessor.create();
    private final Flowable<Camera.Mode> mode = modeProcessor.onBackpressureBuffer().share();;
    private volatile boolean isModeInitialized = false;

    private void processMode() {
      CameraProto.SubscribeModeRequest request = CameraProto.SubscribeModeRequest.newBuilder()
        .build();

      stub.subscribeMode(request, new StreamObserver<CameraProto.ModeResponse>() {

        @Override
        public void onNext(CameraProto.ModeResponse value) {
          modeProcessor.onNext(Mode.translateFromRpc(value.getMode()));
        }

        @Override
        public void onError(Throwable t) {
          modeProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          modeProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Camera.Mode> getMode() {
      if (!isModeInitialized) {
        synchronized (this) {
          if (!isModeInitialized) {
            MavsdkEventQueue.executor().execute(() -> processMode());
            isModeInitialized = true;
          }
        }
      }
      return mode;
    }



    // Infinite stream
    private final FlowableProcessor<Camera.Information> informationProcessor = PublishProcessor.create();
    private final Flowable<Camera.Information> information = informationProcessor.onBackpressureBuffer().share();;
    private volatile boolean isInformationInitialized = false;

    private void processInformation() {
      CameraProto.SubscribeInformationRequest request = CameraProto.SubscribeInformationRequest.newBuilder()
        .build();

      stub.subscribeInformation(request, new StreamObserver<CameraProto.InformationResponse>() {

        @Override
        public void onNext(CameraProto.InformationResponse value) {
          informationProcessor.onNext(Information.translateFromRpc(value.getInformation()));
        }

        @Override
        public void onError(Throwable t) {
          informationProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          informationProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Camera.Information> getInformation() {
      if (!isInformationInitialized) {
        synchronized (this) {
          if (!isInformationInitialized) {
            MavsdkEventQueue.executor().execute(() -> processInformation());
            isInformationInitialized = true;
          }
        }
      }
      return information;
    }



    // Infinite stream
    private final FlowableProcessor<Camera.VideoStreamInfo> videoStreamInfoProcessor = PublishProcessor.create();
    private final Flowable<Camera.VideoStreamInfo> videoStreamInfo = videoStreamInfoProcessor.onBackpressureBuffer().share();;
    private volatile boolean isVideoStreamInfoInitialized = false;

    private void processVideoStreamInfo() {
      CameraProto.SubscribeVideoStreamInfoRequest request = CameraProto.SubscribeVideoStreamInfoRequest.newBuilder()
        .build();

      stub.subscribeVideoStreamInfo(request, new StreamObserver<CameraProto.VideoStreamInfoResponse>() {

        @Override
        public void onNext(CameraProto.VideoStreamInfoResponse value) {
          videoStreamInfoProcessor.onNext(VideoStreamInfo.translateFromRpc(value.getVideoStreamInfo()));
        }

        @Override
        public void onError(Throwable t) {
          videoStreamInfoProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          videoStreamInfoProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Camera.VideoStreamInfo> getVideoStreamInfo() {
      if (!isVideoStreamInfoInitialized) {
        synchronized (this) {
          if (!isVideoStreamInfoInitialized) {
            MavsdkEventQueue.executor().execute(() -> processVideoStreamInfo());
            isVideoStreamInfoInitialized = true;
          }
        }
      }
      return videoStreamInfo;
    }



    // Infinite stream
    private final FlowableProcessor<Camera.CaptureInfo> captureInfoProcessor = PublishProcessor.create();
    private final Flowable<Camera.CaptureInfo> captureInfo = captureInfoProcessor.onBackpressureBuffer().share();;
    private volatile boolean isCaptureInfoInitialized = false;

    private void processCaptureInfo() {
      CameraProto.SubscribeCaptureInfoRequest request = CameraProto.SubscribeCaptureInfoRequest.newBuilder()
        .build();

      stub.subscribeCaptureInfo(request, new StreamObserver<CameraProto.CaptureInfoResponse>() {

        @Override
        public void onNext(CameraProto.CaptureInfoResponse value) {
          captureInfoProcessor.onNext(CaptureInfo.translateFromRpc(value.getCaptureInfo()));
        }

        @Override
        public void onError(Throwable t) {
          captureInfoProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          captureInfoProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Camera.CaptureInfo> getCaptureInfo() {
      if (!isCaptureInfoInitialized) {
        synchronized (this) {
          if (!isCaptureInfoInitialized) {
            MavsdkEventQueue.executor().execute(() -> processCaptureInfo());
            isCaptureInfoInitialized = true;
          }
        }
      }
      return captureInfo;
    }



    // Infinite stream
    private final FlowableProcessor<Camera.Status> statusProcessor = PublishProcessor.create();
    private final Flowable<Camera.Status> status = statusProcessor.onBackpressureBuffer().share();;
    private volatile boolean isStatusInitialized = false;

    private void processStatus() {
      CameraProto.SubscribeStatusRequest request = CameraProto.SubscribeStatusRequest.newBuilder()
        .build();

      stub.subscribeStatus(request, new StreamObserver<CameraProto.StatusResponse>() {

        @Override
        public void onNext(CameraProto.StatusResponse value) {
          statusProcessor.onNext(Status.translateFromRpc(value.getCameraStatus()));
        }

        @Override
        public void onError(Throwable t) {
          statusProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          statusProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Camera.Status> getStatus() {
      if (!isStatusInitialized) {
        synchronized (this) {
          if (!isStatusInitialized) {
            MavsdkEventQueue.executor().execute(() -> processStatus());
            isStatusInitialized = true;
          }
        }
      }
      return status;
    }



    // Infinite stream
    private final FlowableProcessor<List<Camera.Setting>> currentSettingsProcessor = PublishProcessor.create();
    private final Flowable<List<Camera.Setting>> currentSettings = currentSettingsProcessor.onBackpressureBuffer().share();;
    private volatile boolean isCurrentSettingsInitialized = false;

    private void processCurrentSettings() {
      CameraProto.SubscribeCurrentSettingsRequest request = CameraProto.SubscribeCurrentSettingsRequest.newBuilder()
        .build();

      stub.subscribeCurrentSettings(request, new StreamObserver<CameraProto.CurrentSettingsResponse>() {

        @Override
        public void onNext(CameraProto.CurrentSettingsResponse value) {
          currentSettingsProcessor.onNext(value.getCurrentSettingsList().stream().map(Setting::translateFromRpc).collect(Collectors.toList()));
        }

        @Override
        public void onError(Throwable t) {
          currentSettingsProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          currentSettingsProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<List<Camera.Setting>> getCurrentSettings() {
      if (!isCurrentSettingsInitialized) {
        synchronized (this) {
          if (!isCurrentSettingsInitialized) {
            MavsdkEventQueue.executor().execute(() -> processCurrentSettings());
            isCurrentSettingsInitialized = true;
          }
        }
      }
      return currentSettings;
    }



    // Infinite stream
    private final FlowableProcessor<List<Camera.SettingOptions>> possibleSettingOptionsProcessor = PublishProcessor.create();
    private final Flowable<List<Camera.SettingOptions>> possibleSettingOptions = possibleSettingOptionsProcessor.onBackpressureBuffer().share();;
    private volatile boolean isPossibleSettingOptionsInitialized = false;

    private void processPossibleSettingOptions() {
      CameraProto.SubscribePossibleSettingOptionsRequest request = CameraProto.SubscribePossibleSettingOptionsRequest.newBuilder()
        .build();

      stub.subscribePossibleSettingOptions(request, new StreamObserver<CameraProto.PossibleSettingOptionsResponse>() {

        @Override
        public void onNext(CameraProto.PossibleSettingOptionsResponse value) {
          possibleSettingOptionsProcessor.onNext(value.getSettingOptionsList().stream().map(SettingOptions::translateFromRpc).collect(Collectors.toList()));
        }

        @Override
        public void onError(Throwable t) {
          possibleSettingOptionsProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          possibleSettingOptionsProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<List<Camera.SettingOptions>> getPossibleSettingOptions() {
      if (!isPossibleSettingOptionsInitialized) {
        synchronized (this) {
          if (!isPossibleSettingOptionsInitialized) {
            MavsdkEventQueue.executor().execute(() -> processPossibleSettingOptions());
            isPossibleSettingOptionsInitialized = true;
          }
        }
      }
      return possibleSettingOptions;
    }


    @CheckReturnValue
    public Completable setSetting(@NonNull Setting setting) {

      CameraProto.SetSettingRequest request = CameraProto.SetSettingRequest.newBuilder()
        .setSetting(setting.rpcSetting())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setSetting(request, new StreamObserver<CameraProto.SetSettingResponse>() {

          @Override
          public void onNext(CameraProto.SetSettingResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Camera.Setting> getSetting(@NonNull Setting setting) {
      CameraProto.GetSettingRequest request = CameraProto.GetSettingRequest.newBuilder()
        .setSetting(setting.rpcSetting())
        .build();

      Single<Camera.Setting> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getSetting(request, new StreamObserver<CameraProto.GetSettingResponse>() {

          @Override
          public void onNext(CameraProto.GetSettingResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(Setting.translateFromRpc(value.getSetting()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable formatStorage() {

      CameraProto.FormatStorageRequest request = CameraProto.FormatStorageRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.formatStorage(request, new StreamObserver<CameraProto.FormatStorageResponse>() {

          @Override
          public void onNext(CameraProto.FormatStorageResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable selectCamera(@NonNull Integer cameraId) {

      CameraProto.SelectCameraRequest request = CameraProto.SelectCameraRequest.newBuilder()
        .setCameraId(cameraId)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.selectCamera(request, new StreamObserver<CameraProto.SelectCameraResponse>() {

          @Override
          public void onNext(CameraProto.SelectCameraResponse value) {
            CameraResult result = CameraResult.translateFromRpc(value.getCameraResult());

            if (result.result != CameraResult.Result.SUCCESS) {
              emitter.onError(new CameraException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}