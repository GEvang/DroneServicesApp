package io.mavsdk.log_files;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogFiles implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(LogFiles.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private LogFilesServiceGrpc.LogFilesServiceStub stub;

  private volatile boolean isInitialized = false;

  public LogFiles(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public LogFiles() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = LogFilesServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class LogFilesException extends MavsdkException {
    private LogFilesResult.Result code;
    private String description;

    public LogFilesException(LogFilesResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public LogFilesResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class ProgressData {
      private Float progress;

      public ProgressData(Float progress) {
        this.progress = progress;
      }
      public Float getProgress() {
        return progress;
      }

      protected LogFilesProto.ProgressData rpcProgressData() {
        return LogFilesProto.ProgressData.newBuilder()
          .setProgress(this.progress)
          .build();
      }

      protected static ProgressData translateFromRpc(LogFilesProto.ProgressData rpcProgressData) {
        return new ProgressData(
                rpcProgressData.getProgress());
      }
    }


    public static class Entry {
      private Integer id;
      private String date;
      private Integer sizeBytes;

      public Entry(Integer id, String date, Integer sizeBytes) {
        this.id = id;
        this.date = date;
        this.sizeBytes = sizeBytes;
      }
      public Integer getId() {
        return id;
      }
      public String getDate() {
        return date;
      }
      public Integer getSizeBytes() {
        return sizeBytes;
      }

      protected LogFilesProto.Entry rpcEntry() {
        return LogFilesProto.Entry.newBuilder()
          .setId(this.id)
          .setDate(this.date)
          .setSizeBytes(this.sizeBytes)
          .build();
      }

      protected static Entry translateFromRpc(LogFilesProto.Entry rpcEntry) {
        return new Entry(
                rpcEntry.getId(),
                rpcEntry.getDate(),
                rpcEntry.getSizeBytes());
      }
    }


    public static class LogFilesResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_SUCCESS;
            }
          }, 
          NEXT {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_NEXT;
            }
          }, 
          NO_LOGFILES {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_NO_LOGFILES;
            }
          }, 
          TIMEOUT {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_TIMEOUT;
            }
          }, 
          INVALID_ARGUMENT {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_INVALID_ARGUMENT;
            }
          }, 
          FILE_OPEN_FAILED {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_FILE_OPEN_FAILED;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected LogFilesProto.LogFilesResult.Result rpcResult() {
              return LogFilesProto.LogFilesResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(LogFilesProto.LogFilesResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NEXT: 
                return Result.NEXT;
              case RESULT_NO_LOGFILES: 
                return Result.NO_LOGFILES;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_INVALID_ARGUMENT: 
                return Result.INVALID_ARGUMENT;
              case RESULT_FILE_OPEN_FAILED: 
                return Result.FILE_OPEN_FAILED;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract LogFilesProto.LogFilesResult.Result rpcResult();
        }

      public LogFilesResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected LogFilesProto.LogFilesResult rpcLogFilesResult() {
        return LogFilesProto.LogFilesResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static LogFilesResult translateFromRpc(LogFilesProto.LogFilesResult rpcLogFilesResult) {
        return new LogFilesResult(
                Result.translateFromRpc(rpcLogFilesResult.getResult()),
                rpcLogFilesResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Single<List<LogFiles.Entry>> getEntries() {
      LogFilesProto.GetEntriesRequest request = LogFilesProto.GetEntriesRequest.newBuilder()
        .build();

      Single<List<LogFiles.Entry>> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getEntries(request, new StreamObserver<LogFilesProto.GetEntriesResponse>() {

          @Override
          public void onNext(LogFilesProto.GetEntriesResponse value) {
            LogFilesResult result = LogFilesResult.translateFromRpc(value.getLogFilesResult());

            if (result.result != LogFilesResult.Result.SUCCESS) {
              emitter.onError(new LogFilesException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getEntriesList().stream().map(Entry::translateFromRpc).collect(Collectors.toList()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }

    // Finite stream
    private Flowable<LogFiles.ProgressData> createDownloadLogFile(Entry entry, String path) {
      LogFilesProto.SubscribeDownloadLogFileRequest request = LogFilesProto.SubscribeDownloadLogFileRequest.newBuilder()
        .setEntry(entry.rpcEntry())
        .setPath(path)
        .build();

      Flowable<LogFiles.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeDownloadLogFile(request, new StreamObserver<LogFilesProto.DownloadLogFileResponse>() {

          @Override
          public void onNext(LogFilesProto.DownloadLogFileResponse value) {
            LogFilesResult result = LogFilesResult.translateFromRpc(value.getLogFilesResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgress()));
                break;
              default:
                emitter.onError(new LogFilesException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<LogFiles.ProgressData> downloadLogFile(@NonNull Entry entry, @NonNull String path) {
      return createDownloadLogFile(entry, path);
    }


}