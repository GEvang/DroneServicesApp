package io.mavsdk.gimbal;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Gimbal implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Gimbal.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private GimbalServiceGrpc.GimbalServiceStub stub;

  private volatile boolean isInitialized = false;

  public Gimbal(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Gimbal() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = GimbalServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class GimbalException extends MavsdkException {
    private GimbalResult.Result code;
    private String description;

    public GimbalException(GimbalResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public GimbalResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum GimbalMode {
      
      YAW_FOLLOW {
        @Override
        protected GimbalProto.GimbalMode rpcGimbalMode() {
          return GimbalProto.GimbalMode.GIMBAL_MODE_YAW_FOLLOW;
        }
      }, 
      YAW_LOCK {
        @Override
        protected GimbalProto.GimbalMode rpcGimbalMode() {
          return GimbalProto.GimbalMode.GIMBAL_MODE_YAW_LOCK;
        }
      };

      protected static GimbalMode translateFromRpc(GimbalProto.GimbalMode rpcGimbalMode) {
        switch (rpcGimbalMode) {
          case GIMBAL_MODE_YAW_FOLLOW: default: 
            return GimbalMode.YAW_FOLLOW;
          case GIMBAL_MODE_YAW_LOCK: 
            return GimbalMode.YAW_LOCK;
        }
      }

      protected abstract GimbalProto.GimbalMode rpcGimbalMode();
    }
    public enum ControlMode {
      
      NONE {
        @Override
        protected GimbalProto.ControlMode rpcControlMode() {
          return GimbalProto.ControlMode.CONTROL_MODE_NONE;
        }
      }, 
      PRIMARY {
        @Override
        protected GimbalProto.ControlMode rpcControlMode() {
          return GimbalProto.ControlMode.CONTROL_MODE_PRIMARY;
        }
      }, 
      SECONDARY {
        @Override
        protected GimbalProto.ControlMode rpcControlMode() {
          return GimbalProto.ControlMode.CONTROL_MODE_SECONDARY;
        }
      };

      protected static ControlMode translateFromRpc(GimbalProto.ControlMode rpcControlMode) {
        switch (rpcControlMode) {
          case CONTROL_MODE_NONE: default: 
            return ControlMode.NONE;
          case CONTROL_MODE_PRIMARY: 
            return ControlMode.PRIMARY;
          case CONTROL_MODE_SECONDARY: 
            return ControlMode.SECONDARY;
        }
      }

      protected abstract GimbalProto.ControlMode rpcControlMode();
    }


    public static class ControlStatus {
      private ControlMode controlMode;
      private Integer sysidPrimaryControl;
      private Integer compidPrimaryControl;
      private Integer sysidSecondaryControl;
      private Integer compidSecondaryControl;

      public ControlStatus(ControlMode controlMode, Integer sysidPrimaryControl, Integer compidPrimaryControl, Integer sysidSecondaryControl, Integer compidSecondaryControl) {
        this.controlMode = controlMode;
        this.sysidPrimaryControl = sysidPrimaryControl;
        this.compidPrimaryControl = compidPrimaryControl;
        this.sysidSecondaryControl = sysidSecondaryControl;
        this.compidSecondaryControl = compidSecondaryControl;
      }
      public ControlMode getControlMode() {
        return controlMode;
      }
      public Integer getSysidPrimaryControl() {
        return sysidPrimaryControl;
      }
      public Integer getCompidPrimaryControl() {
        return compidPrimaryControl;
      }
      public Integer getSysidSecondaryControl() {
        return sysidSecondaryControl;
      }
      public Integer getCompidSecondaryControl() {
        return compidSecondaryControl;
      }

      protected GimbalProto.ControlStatus rpcControlStatus() {
        return GimbalProto.ControlStatus.newBuilder()
          .setControlMode(this.controlMode.rpcControlMode())
          .setSysidPrimaryControl(this.sysidPrimaryControl)
          .setCompidPrimaryControl(this.compidPrimaryControl)
          .setSysidSecondaryControl(this.sysidSecondaryControl)
          .setCompidSecondaryControl(this.compidSecondaryControl)
          .build();
      }

      protected static ControlStatus translateFromRpc(GimbalProto.ControlStatus rpcControlStatus) {
        return new ControlStatus(
                ControlMode.translateFromRpc(rpcControlStatus.getControlMode()),
                rpcControlStatus.getSysidPrimaryControl(),
                rpcControlStatus.getCompidPrimaryControl(),
                rpcControlStatus.getSysidSecondaryControl(),
                rpcControlStatus.getCompidSecondaryControl());
      }
    }


    public static class GimbalResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected GimbalProto.GimbalResult.Result rpcResult() {
              return GimbalProto.GimbalResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected GimbalProto.GimbalResult.Result rpcResult() {
              return GimbalProto.GimbalResult.Result.RESULT_SUCCESS;
            }
          }, 
          ERROR {
            @Override
            protected GimbalProto.GimbalResult.Result rpcResult() {
              return GimbalProto.GimbalResult.Result.RESULT_ERROR;
            }
          }, 
          TIMEOUT {
            @Override
            protected GimbalProto.GimbalResult.Result rpcResult() {
              return GimbalProto.GimbalResult.Result.RESULT_TIMEOUT;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected GimbalProto.GimbalResult.Result rpcResult() {
              return GimbalProto.GimbalResult.Result.RESULT_UNSUPPORTED;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected GimbalProto.GimbalResult.Result rpcResult() {
              return GimbalProto.GimbalResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(GimbalProto.GimbalResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract GimbalProto.GimbalResult.Result rpcResult();
        }

      public GimbalResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected GimbalProto.GimbalResult rpcGimbalResult() {
        return GimbalProto.GimbalResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static GimbalResult translateFromRpc(GimbalProto.GimbalResult rpcGimbalResult) {
        return new GimbalResult(
                Result.translateFromRpc(rpcGimbalResult.getResult()),
                rpcGimbalResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable setPitchAndYaw(@NonNull Float pitchDeg, @NonNull Float yawDeg) {

      GimbalProto.SetPitchAndYawRequest request = GimbalProto.SetPitchAndYawRequest.newBuilder()
        .setPitchDeg(pitchDeg)
        .setYawDeg(yawDeg)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setPitchAndYaw(request, new StreamObserver<GimbalProto.SetPitchAndYawResponse>() {

          @Override
          public void onNext(GimbalProto.SetPitchAndYawResponse value) {
            GimbalResult result = GimbalResult.translateFromRpc(value.getGimbalResult());

            if (result.result != GimbalResult.Result.SUCCESS) {
              emitter.onError(new GimbalException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setPitchRateAndYawRate(@NonNull Float pitchRateDegS, @NonNull Float yawRateDegS) {

      GimbalProto.SetPitchRateAndYawRateRequest request = GimbalProto.SetPitchRateAndYawRateRequest.newBuilder()
        .setPitchRateDegS(pitchRateDegS)
        .setYawRateDegS(yawRateDegS)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setPitchRateAndYawRate(request, new StreamObserver<GimbalProto.SetPitchRateAndYawRateResponse>() {

          @Override
          public void onNext(GimbalProto.SetPitchRateAndYawRateResponse value) {
            GimbalResult result = GimbalResult.translateFromRpc(value.getGimbalResult());

            if (result.result != GimbalResult.Result.SUCCESS) {
              emitter.onError(new GimbalException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setMode(@NonNull GimbalMode gimbalMode) {

      GimbalProto.SetModeRequest request = GimbalProto.SetModeRequest.newBuilder()
        .setGimbalMode(gimbalMode.rpcGimbalMode())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setMode(request, new StreamObserver<GimbalProto.SetModeResponse>() {

          @Override
          public void onNext(GimbalProto.SetModeResponse value) {
            GimbalResult result = GimbalResult.translateFromRpc(value.getGimbalResult());

            if (result.result != GimbalResult.Result.SUCCESS) {
              emitter.onError(new GimbalException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRoiLocation(@NonNull Double latitudeDeg, @NonNull Double longitudeDeg, @NonNull Float altitudeM) {

      GimbalProto.SetRoiLocationRequest request = GimbalProto.SetRoiLocationRequest.newBuilder()
        .setLatitudeDeg(latitudeDeg)
        .setLongitudeDeg(longitudeDeg)
        .setAltitudeM(altitudeM)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRoiLocation(request, new StreamObserver<GimbalProto.SetRoiLocationResponse>() {

          @Override
          public void onNext(GimbalProto.SetRoiLocationResponse value) {
            GimbalResult result = GimbalResult.translateFromRpc(value.getGimbalResult());

            if (result.result != GimbalResult.Result.SUCCESS) {
              emitter.onError(new GimbalException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable takeControl(@NonNull ControlMode controlMode) {

      GimbalProto.TakeControlRequest request = GimbalProto.TakeControlRequest.newBuilder()
        .setControlMode(controlMode.rpcControlMode())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.takeControl(request, new StreamObserver<GimbalProto.TakeControlResponse>() {

          @Override
          public void onNext(GimbalProto.TakeControlResponse value) {
            GimbalResult result = GimbalResult.translateFromRpc(value.getGimbalResult());

            if (result.result != GimbalResult.Result.SUCCESS) {
              emitter.onError(new GimbalException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable releaseControl() {

      GimbalProto.ReleaseControlRequest request = GimbalProto.ReleaseControlRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.releaseControl(request, new StreamObserver<GimbalProto.ReleaseControlResponse>() {

          @Override
          public void onNext(GimbalProto.ReleaseControlResponse value) {
            GimbalResult result = GimbalResult.translateFromRpc(value.getGimbalResult());

            if (result.result != GimbalResult.Result.SUCCESS) {
              emitter.onError(new GimbalException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<Gimbal.ControlStatus> controlProcessor = PublishProcessor.create();
    private final Flowable<Gimbal.ControlStatus> control = controlProcessor.onBackpressureBuffer().share();;
    private volatile boolean isControlInitialized = false;

    private void processControl() {
      GimbalProto.SubscribeControlRequest request = GimbalProto.SubscribeControlRequest.newBuilder()
        .build();

      stub.subscribeControl(request, new StreamObserver<GimbalProto.ControlResponse>() {

        @Override
        public void onNext(GimbalProto.ControlResponse value) {
          controlProcessor.onNext(ControlStatus.translateFromRpc(value.getControlStatus()));
        }

        @Override
        public void onError(Throwable t) {
          controlProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          controlProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Gimbal.ControlStatus> getControl() {
      if (!isControlInitialized) {
        synchronized (this) {
          if (!isControlInitialized) {
            MavsdkEventQueue.executor().execute(() -> processControl());
            isControlInitialized = true;
          }
        }
      }
      return control;
    }


}