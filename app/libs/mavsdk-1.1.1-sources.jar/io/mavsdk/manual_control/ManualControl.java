package io.mavsdk.manual_control;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ManualControl implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(ManualControl.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ManualControlServiceGrpc.ManualControlServiceStub stub;

  private volatile boolean isInitialized = false;

  public ManualControl(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public ManualControl() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ManualControlServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ManualControlException extends MavsdkException {
    private ManualControlResult.Result code;
    private String description;

    public ManualControlException(ManualControlResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ManualControlResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class ManualControlResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_TIMEOUT;
            }
          }, 
          INPUT_OUT_OF_RANGE {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_INPUT_OUT_OF_RANGE;
            }
          }, 
          INPUT_NOT_SET {
            @Override
            protected ManualControlProto.ManualControlResult.Result rpcResult() {
              return ManualControlProto.ManualControlResult.Result.RESULT_INPUT_NOT_SET;
            }
          };

          protected static Result translateFromRpc(ManualControlProto.ManualControlResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_INPUT_OUT_OF_RANGE: 
                return Result.INPUT_OUT_OF_RANGE;
              case RESULT_INPUT_NOT_SET: 
                return Result.INPUT_NOT_SET;
            }
          }

          protected abstract ManualControlProto.ManualControlResult.Result rpcResult();
        }

      public ManualControlResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ManualControlProto.ManualControlResult rpcManualControlResult() {
        return ManualControlProto.ManualControlResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ManualControlResult translateFromRpc(ManualControlProto.ManualControlResult rpcManualControlResult) {
        return new ManualControlResult(
                Result.translateFromRpc(rpcManualControlResult.getResult()),
                rpcManualControlResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable startPositionControl() {

      ManualControlProto.StartPositionControlRequest request = ManualControlProto.StartPositionControlRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startPositionControl(request, new StreamObserver<ManualControlProto.StartPositionControlResponse>() {

          @Override
          public void onNext(ManualControlProto.StartPositionControlResponse value) {
            ManualControlResult result = ManualControlResult.translateFromRpc(value.getManualControlResult());

            if (result.result != ManualControlResult.Result.SUCCESS) {
              emitter.onError(new ManualControlException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable startAltitudeControl() {

      ManualControlProto.StartAltitudeControlRequest request = ManualControlProto.StartAltitudeControlRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startAltitudeControl(request, new StreamObserver<ManualControlProto.StartAltitudeControlResponse>() {

          @Override
          public void onNext(ManualControlProto.StartAltitudeControlResponse value) {
            ManualControlResult result = ManualControlResult.translateFromRpc(value.getManualControlResult());

            if (result.result != ManualControlResult.Result.SUCCESS) {
              emitter.onError(new ManualControlException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setManualControlInput(@NonNull Float x, @NonNull Float y, @NonNull Float z, @NonNull Float r) {

      ManualControlProto.SetManualControlInputRequest request = ManualControlProto.SetManualControlInputRequest.newBuilder()
        .setX(x)
        .setY(y)
        .setZ(z)
        .setR(r)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setManualControlInput(request, new StreamObserver<ManualControlProto.SetManualControlInputResponse>() {

          @Override
          public void onNext(ManualControlProto.SetManualControlInputResponse value) {
            ManualControlResult result = ManualControlResult.translateFromRpc(value.getManualControlResult());

            if (result.result != ManualControlResult.Result.SUCCESS) {
              emitter.onError(new ManualControlException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}