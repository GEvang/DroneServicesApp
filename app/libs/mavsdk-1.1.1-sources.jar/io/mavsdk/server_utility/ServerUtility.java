package io.mavsdk.server_utility;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServerUtility implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(ServerUtility.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ServerUtilityServiceGrpc.ServerUtilityServiceStub stub;

  private volatile boolean isInitialized = false;

  public ServerUtility(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public ServerUtility() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ServerUtilityServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ServerUtilityException extends MavsdkException {
    private ServerUtilityResult.Result code;
    private String description;

    public ServerUtilityException(ServerUtilityResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ServerUtilityResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum StatusTextType {
      
      DEBUG {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_DEBUG;
        }
      }, 
      INFO {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_INFO;
        }
      }, 
      NOTICE {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_NOTICE;
        }
      }, 
      WARNING {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_WARNING;
        }
      }, 
      ERROR {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_ERROR;
        }
      }, 
      CRITICAL {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_CRITICAL;
        }
      }, 
      ALERT {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_ALERT;
        }
      }, 
      EMERGENCY {
        @Override
        protected ServerUtilityProto.StatusTextType rpcStatusTextType() {
          return ServerUtilityProto.StatusTextType.STATUS_TEXT_TYPE_EMERGENCY;
        }
      };

      protected static StatusTextType translateFromRpc(ServerUtilityProto.StatusTextType rpcStatusTextType) {
        switch (rpcStatusTextType) {
          case STATUS_TEXT_TYPE_DEBUG: default: 
            return StatusTextType.DEBUG;
          case STATUS_TEXT_TYPE_INFO: 
            return StatusTextType.INFO;
          case STATUS_TEXT_TYPE_NOTICE: 
            return StatusTextType.NOTICE;
          case STATUS_TEXT_TYPE_WARNING: 
            return StatusTextType.WARNING;
          case STATUS_TEXT_TYPE_ERROR: 
            return StatusTextType.ERROR;
          case STATUS_TEXT_TYPE_CRITICAL: 
            return StatusTextType.CRITICAL;
          case STATUS_TEXT_TYPE_ALERT: 
            return StatusTextType.ALERT;
          case STATUS_TEXT_TYPE_EMERGENCY: 
            return StatusTextType.EMERGENCY;
        }
      }

      protected abstract ServerUtilityProto.StatusTextType rpcStatusTextType();
    }


    public static class ServerUtilityResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ServerUtilityProto.ServerUtilityResult.Result rpcResult() {
              return ServerUtilityProto.ServerUtilityResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ServerUtilityProto.ServerUtilityResult.Result rpcResult() {
              return ServerUtilityProto.ServerUtilityResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ServerUtilityProto.ServerUtilityResult.Result rpcResult() {
              return ServerUtilityProto.ServerUtilityResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected ServerUtilityProto.ServerUtilityResult.Result rpcResult() {
              return ServerUtilityProto.ServerUtilityResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          INVALID_ARGUMENT {
            @Override
            protected ServerUtilityProto.ServerUtilityResult.Result rpcResult() {
              return ServerUtilityProto.ServerUtilityResult.Result.RESULT_INVALID_ARGUMENT;
            }
          };

          protected static Result translateFromRpc(ServerUtilityProto.ServerUtilityResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_INVALID_ARGUMENT: 
                return Result.INVALID_ARGUMENT;
            }
          }

          protected abstract ServerUtilityProto.ServerUtilityResult.Result rpcResult();
        }

      public ServerUtilityResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ServerUtilityProto.ServerUtilityResult rpcServerUtilityResult() {
        return ServerUtilityProto.ServerUtilityResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ServerUtilityResult translateFromRpc(ServerUtilityProto.ServerUtilityResult rpcServerUtilityResult) {
        return new ServerUtilityResult(
                Result.translateFromRpc(rpcServerUtilityResult.getResult()),
                rpcServerUtilityResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable sendStatusText(@NonNull StatusTextType type, @NonNull String text) {

      ServerUtilityProto.SendStatusTextRequest request = ServerUtilityProto.SendStatusTextRequest.newBuilder()
        .setType(type.rpcStatusTextType())
        .setText(text)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.sendStatusText(request, new StreamObserver<ServerUtilityProto.SendStatusTextResponse>() {

          @Override
          public void onNext(ServerUtilityProto.SendStatusTextResponse value) {
            ServerUtilityResult result = ServerUtilityResult.translateFromRpc(value.getServerUtilityResult());

            if (result.result != ServerUtilityResult.Result.SUCCESS) {
              emitter.onError(new ServerUtilityException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}