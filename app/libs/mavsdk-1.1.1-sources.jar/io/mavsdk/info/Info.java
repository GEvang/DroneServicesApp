package io.mavsdk.info;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Info implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Info.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private InfoServiceGrpc.InfoServiceStub stub;

  private volatile boolean isInitialized = false;

  public Info(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Info() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = InfoServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class InfoException extends MavsdkException {
    private InfoResult.Result code;
    private String description;

    public InfoException(InfoResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public InfoResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class FlightInfo {
      private Integer timeBootMs;
      private Long flightUid;

      public FlightInfo(Integer timeBootMs, Long flightUid) {
        this.timeBootMs = timeBootMs;
        this.flightUid = flightUid;
      }
      public Integer getTimeBootMs() {
        return timeBootMs;
      }
      public Long getFlightUid() {
        return flightUid;
      }

      protected InfoProto.FlightInfo rpcFlightInfo() {
        return InfoProto.FlightInfo.newBuilder()
          .setTimeBootMs(this.timeBootMs)
          .setFlightUid(this.flightUid)
          .build();
      }

      protected static FlightInfo translateFromRpc(InfoProto.FlightInfo rpcFlightInfo) {
        return new FlightInfo(
                rpcFlightInfo.getTimeBootMs(),
                rpcFlightInfo.getFlightUid());
      }
    }


    public static class Identification {
      private String hardwareUid;
      private Long legacyUid;

      public Identification(String hardwareUid, Long legacyUid) {
        this.hardwareUid = hardwareUid;
        this.legacyUid = legacyUid;
      }
      public String getHardwareUid() {
        return hardwareUid;
      }
      public Long getLegacyUid() {
        return legacyUid;
      }

      protected InfoProto.Identification rpcIdentification() {
        return InfoProto.Identification.newBuilder()
          .setHardwareUid(this.hardwareUid)
          .setLegacyUid(this.legacyUid)
          .build();
      }

      protected static Identification translateFromRpc(InfoProto.Identification rpcIdentification) {
        return new Identification(
                rpcIdentification.getHardwareUid(),
                rpcIdentification.getLegacyUid());
      }
    }


    public static class Product {
      private Integer vendorId;
      private String vendorName;
      private Integer productId;
      private String productName;

      public Product(Integer vendorId, String vendorName, Integer productId, String productName) {
        this.vendorId = vendorId;
        this.vendorName = vendorName;
        this.productId = productId;
        this.productName = productName;
      }
      public Integer getVendorId() {
        return vendorId;
      }
      public String getVendorName() {
        return vendorName;
      }
      public Integer getProductId() {
        return productId;
      }
      public String getProductName() {
        return productName;
      }

      protected InfoProto.Product rpcProduct() {
        return InfoProto.Product.newBuilder()
          .setVendorId(this.vendorId)
          .setVendorName(this.vendorName)
          .setProductId(this.productId)
          .setProductName(this.productName)
          .build();
      }

      protected static Product translateFromRpc(InfoProto.Product rpcProduct) {
        return new Product(
                rpcProduct.getVendorId(),
                rpcProduct.getVendorName(),
                rpcProduct.getProductId(),
                rpcProduct.getProductName());
      }
    }


    public static class Version {
      private Integer flightSwMajor;
      private Integer flightSwMinor;
      private Integer flightSwPatch;
      private Integer flightSwVendorMajor;
      private Integer flightSwVendorMinor;
      private Integer flightSwVendorPatch;
      private Integer osSwMajor;
      private Integer osSwMinor;
      private Integer osSwPatch;
      private String flightSwGitHash;
      private String osSwGitHash;

      public Version(Integer flightSwMajor, Integer flightSwMinor, Integer flightSwPatch, Integer flightSwVendorMajor, Integer flightSwVendorMinor, Integer flightSwVendorPatch, Integer osSwMajor, Integer osSwMinor, Integer osSwPatch, String flightSwGitHash, String osSwGitHash) {
        this.flightSwMajor = flightSwMajor;
        this.flightSwMinor = flightSwMinor;
        this.flightSwPatch = flightSwPatch;
        this.flightSwVendorMajor = flightSwVendorMajor;
        this.flightSwVendorMinor = flightSwVendorMinor;
        this.flightSwVendorPatch = flightSwVendorPatch;
        this.osSwMajor = osSwMajor;
        this.osSwMinor = osSwMinor;
        this.osSwPatch = osSwPatch;
        this.flightSwGitHash = flightSwGitHash;
        this.osSwGitHash = osSwGitHash;
      }
      public Integer getFlightSwMajor() {
        return flightSwMajor;
      }
      public Integer getFlightSwMinor() {
        return flightSwMinor;
      }
      public Integer getFlightSwPatch() {
        return flightSwPatch;
      }
      public Integer getFlightSwVendorMajor() {
        return flightSwVendorMajor;
      }
      public Integer getFlightSwVendorMinor() {
        return flightSwVendorMinor;
      }
      public Integer getFlightSwVendorPatch() {
        return flightSwVendorPatch;
      }
      public Integer getOsSwMajor() {
        return osSwMajor;
      }
      public Integer getOsSwMinor() {
        return osSwMinor;
      }
      public Integer getOsSwPatch() {
        return osSwPatch;
      }
      public String getFlightSwGitHash() {
        return flightSwGitHash;
      }
      public String getOsSwGitHash() {
        return osSwGitHash;
      }

      protected InfoProto.Version rpcVersion() {
        return InfoProto.Version.newBuilder()
          .setFlightSwMajor(this.flightSwMajor)
          .setFlightSwMinor(this.flightSwMinor)
          .setFlightSwPatch(this.flightSwPatch)
          .setFlightSwVendorMajor(this.flightSwVendorMajor)
          .setFlightSwVendorMinor(this.flightSwVendorMinor)
          .setFlightSwVendorPatch(this.flightSwVendorPatch)
          .setOsSwMajor(this.osSwMajor)
          .setOsSwMinor(this.osSwMinor)
          .setOsSwPatch(this.osSwPatch)
          .setFlightSwGitHash(this.flightSwGitHash)
          .setOsSwGitHash(this.osSwGitHash)
          .build();
      }

      protected static Version translateFromRpc(InfoProto.Version rpcVersion) {
        return new Version(
                rpcVersion.getFlightSwMajor(),
                rpcVersion.getFlightSwMinor(),
                rpcVersion.getFlightSwPatch(),
                rpcVersion.getFlightSwVendorMajor(),
                rpcVersion.getFlightSwVendorMinor(),
                rpcVersion.getFlightSwVendorPatch(),
                rpcVersion.getOsSwMajor(),
                rpcVersion.getOsSwMinor(),
                rpcVersion.getOsSwPatch(),
                rpcVersion.getFlightSwGitHash(),
                rpcVersion.getOsSwGitHash());
      }
    }


    public static class InfoResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected InfoProto.InfoResult.Result rpcResult() {
              return InfoProto.InfoResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected InfoProto.InfoResult.Result rpcResult() {
              return InfoProto.InfoResult.Result.RESULT_SUCCESS;
            }
          }, 
          INFORMATION_NOT_RECEIVED_YET {
            @Override
            protected InfoProto.InfoResult.Result rpcResult() {
              return InfoProto.InfoResult.Result.RESULT_INFORMATION_NOT_RECEIVED_YET;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected InfoProto.InfoResult.Result rpcResult() {
              return InfoProto.InfoResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(InfoProto.InfoResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_INFORMATION_NOT_RECEIVED_YET: 
                return Result.INFORMATION_NOT_RECEIVED_YET;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract InfoProto.InfoResult.Result rpcResult();
        }

      public InfoResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected InfoProto.InfoResult rpcInfoResult() {
        return InfoProto.InfoResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static InfoResult translateFromRpc(InfoProto.InfoResult rpcInfoResult) {
        return new InfoResult(
                Result.translateFromRpc(rpcInfoResult.getResult()),
                rpcInfoResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Single<Info.FlightInfo> getFlightInformation() {
      InfoProto.GetFlightInformationRequest request = InfoProto.GetFlightInformationRequest.newBuilder()
        .build();

      Single<Info.FlightInfo> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getFlightInformation(request, new StreamObserver<InfoProto.GetFlightInformationResponse>() {

          @Override
          public void onNext(InfoProto.GetFlightInformationResponse value) {
            InfoResult result = InfoResult.translateFromRpc(value.getInfoResult());

            if (result.result != InfoResult.Result.SUCCESS) {
              emitter.onError(new InfoException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(FlightInfo.translateFromRpc(value.getFlightInfo()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Info.Identification> getIdentification() {
      InfoProto.GetIdentificationRequest request = InfoProto.GetIdentificationRequest.newBuilder()
        .build();

      Single<Info.Identification> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getIdentification(request, new StreamObserver<InfoProto.GetIdentificationResponse>() {

          @Override
          public void onNext(InfoProto.GetIdentificationResponse value) {
            InfoResult result = InfoResult.translateFromRpc(value.getInfoResult());

            if (result.result != InfoResult.Result.SUCCESS) {
              emitter.onError(new InfoException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(Identification.translateFromRpc(value.getIdentification()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Info.Product> getProduct() {
      InfoProto.GetProductRequest request = InfoProto.GetProductRequest.newBuilder()
        .build();

      Single<Info.Product> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getProduct(request, new StreamObserver<InfoProto.GetProductResponse>() {

          @Override
          public void onNext(InfoProto.GetProductResponse value) {
            InfoResult result = InfoResult.translateFromRpc(value.getInfoResult());

            if (result.result != InfoResult.Result.SUCCESS) {
              emitter.onError(new InfoException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(Product.translateFromRpc(value.getProduct()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Info.Version> getVersion() {
      InfoProto.GetVersionRequest request = InfoProto.GetVersionRequest.newBuilder()
        .build();

      Single<Info.Version> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getVersion(request, new StreamObserver<InfoProto.GetVersionResponse>() {

          @Override
          public void onNext(InfoProto.GetVersionResponse value) {
            InfoResult result = InfoResult.translateFromRpc(value.getInfoResult());

            if (result.result != InfoResult.Result.SUCCESS) {
              emitter.onError(new InfoException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(Version.translateFromRpc(value.getVersion()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Double> getSpeedFactor() {
      InfoProto.GetSpeedFactorRequest request = InfoProto.GetSpeedFactorRequest.newBuilder()
        .build();

      Single<Double> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getSpeedFactor(request, new StreamObserver<InfoProto.GetSpeedFactorResponse>() {

          @Override
          public void onNext(InfoProto.GetSpeedFactorResponse value) {
            InfoResult result = InfoResult.translateFromRpc(value.getInfoResult());

            if (result.result != InfoResult.Result.SUCCESS) {
              emitter.onError(new InfoException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getSpeedFactor());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}