package io.mavsdk.info;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Provide information about the hardware and/or software of a system.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.42.1)",
    comments = "Source: info/info.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class InfoServiceGrpc {

  private InfoServiceGrpc() {}

  public static final String SERVICE_NAME = "mavsdk.rpc.info.InfoService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetFlightInformationRequest,
      io.mavsdk.info.InfoProto.GetFlightInformationResponse> getGetFlightInformationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetFlightInformation",
      requestType = io.mavsdk.info.InfoProto.GetFlightInformationRequest.class,
      responseType = io.mavsdk.info.InfoProto.GetFlightInformationResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetFlightInformationRequest,
      io.mavsdk.info.InfoProto.GetFlightInformationResponse> getGetFlightInformationMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetFlightInformationRequest, io.mavsdk.info.InfoProto.GetFlightInformationResponse> getGetFlightInformationMethod;
    if ((getGetFlightInformationMethod = InfoServiceGrpc.getGetFlightInformationMethod) == null) {
      synchronized (InfoServiceGrpc.class) {
        if ((getGetFlightInformationMethod = InfoServiceGrpc.getGetFlightInformationMethod) == null) {
          InfoServiceGrpc.getGetFlightInformationMethod = getGetFlightInformationMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.info.InfoProto.GetFlightInformationRequest, io.mavsdk.info.InfoProto.GetFlightInformationResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetFlightInformation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetFlightInformationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetFlightInformationResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGetFlightInformationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetIdentificationRequest,
      io.mavsdk.info.InfoProto.GetIdentificationResponse> getGetIdentificationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetIdentification",
      requestType = io.mavsdk.info.InfoProto.GetIdentificationRequest.class,
      responseType = io.mavsdk.info.InfoProto.GetIdentificationResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetIdentificationRequest,
      io.mavsdk.info.InfoProto.GetIdentificationResponse> getGetIdentificationMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetIdentificationRequest, io.mavsdk.info.InfoProto.GetIdentificationResponse> getGetIdentificationMethod;
    if ((getGetIdentificationMethod = InfoServiceGrpc.getGetIdentificationMethod) == null) {
      synchronized (InfoServiceGrpc.class) {
        if ((getGetIdentificationMethod = InfoServiceGrpc.getGetIdentificationMethod) == null) {
          InfoServiceGrpc.getGetIdentificationMethod = getGetIdentificationMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.info.InfoProto.GetIdentificationRequest, io.mavsdk.info.InfoProto.GetIdentificationResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetIdentification"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetIdentificationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetIdentificationResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGetIdentificationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetProductRequest,
      io.mavsdk.info.InfoProto.GetProductResponse> getGetProductMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetProduct",
      requestType = io.mavsdk.info.InfoProto.GetProductRequest.class,
      responseType = io.mavsdk.info.InfoProto.GetProductResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetProductRequest,
      io.mavsdk.info.InfoProto.GetProductResponse> getGetProductMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetProductRequest, io.mavsdk.info.InfoProto.GetProductResponse> getGetProductMethod;
    if ((getGetProductMethod = InfoServiceGrpc.getGetProductMethod) == null) {
      synchronized (InfoServiceGrpc.class) {
        if ((getGetProductMethod = InfoServiceGrpc.getGetProductMethod) == null) {
          InfoServiceGrpc.getGetProductMethod = getGetProductMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.info.InfoProto.GetProductRequest, io.mavsdk.info.InfoProto.GetProductResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetProduct"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetProductRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetProductResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGetProductMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetVersionRequest,
      io.mavsdk.info.InfoProto.GetVersionResponse> getGetVersionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetVersion",
      requestType = io.mavsdk.info.InfoProto.GetVersionRequest.class,
      responseType = io.mavsdk.info.InfoProto.GetVersionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetVersionRequest,
      io.mavsdk.info.InfoProto.GetVersionResponse> getGetVersionMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetVersionRequest, io.mavsdk.info.InfoProto.GetVersionResponse> getGetVersionMethod;
    if ((getGetVersionMethod = InfoServiceGrpc.getGetVersionMethod) == null) {
      synchronized (InfoServiceGrpc.class) {
        if ((getGetVersionMethod = InfoServiceGrpc.getGetVersionMethod) == null) {
          InfoServiceGrpc.getGetVersionMethod = getGetVersionMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.info.InfoProto.GetVersionRequest, io.mavsdk.info.InfoProto.GetVersionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetVersion"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetVersionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetVersionResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGetVersionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetSpeedFactorRequest,
      io.mavsdk.info.InfoProto.GetSpeedFactorResponse> getGetSpeedFactorMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetSpeedFactor",
      requestType = io.mavsdk.info.InfoProto.GetSpeedFactorRequest.class,
      responseType = io.mavsdk.info.InfoProto.GetSpeedFactorResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetSpeedFactorRequest,
      io.mavsdk.info.InfoProto.GetSpeedFactorResponse> getGetSpeedFactorMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.info.InfoProto.GetSpeedFactorRequest, io.mavsdk.info.InfoProto.GetSpeedFactorResponse> getGetSpeedFactorMethod;
    if ((getGetSpeedFactorMethod = InfoServiceGrpc.getGetSpeedFactorMethod) == null) {
      synchronized (InfoServiceGrpc.class) {
        if ((getGetSpeedFactorMethod = InfoServiceGrpc.getGetSpeedFactorMethod) == null) {
          InfoServiceGrpc.getGetSpeedFactorMethod = getGetSpeedFactorMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.info.InfoProto.GetSpeedFactorRequest, io.mavsdk.info.InfoProto.GetSpeedFactorResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetSpeedFactor"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetSpeedFactorRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.info.InfoProto.GetSpeedFactorResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGetSpeedFactorMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InfoServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InfoServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InfoServiceStub>() {
        @java.lang.Override
        public InfoServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InfoServiceStub(channel, callOptions);
        }
      };
    return InfoServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InfoServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InfoServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InfoServiceBlockingStub>() {
        @java.lang.Override
        public InfoServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InfoServiceBlockingStub(channel, callOptions);
        }
      };
    return InfoServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InfoServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InfoServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InfoServiceFutureStub>() {
        @java.lang.Override
        public InfoServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InfoServiceFutureStub(channel, callOptions);
        }
      };
    return InfoServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Provide information about the hardware and/or software of a system.
   * </pre>
   */
  public static abstract class InfoServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Get flight information of the system.
     * </pre>
     */
    public void getFlightInformation(io.mavsdk.info.InfoProto.GetFlightInformationRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetFlightInformationResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetFlightInformationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Get the identification of the system.
     * </pre>
     */
    public void getIdentification(io.mavsdk.info.InfoProto.GetIdentificationRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetIdentificationResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetIdentificationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Get product information of the system.
     * </pre>
     */
    public void getProduct(io.mavsdk.info.InfoProto.GetProductRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetProductResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetProductMethod(), responseObserver);
    }

    /**
     * <pre>
     * Get the version information of the system.
     * </pre>
     */
    public void getVersion(io.mavsdk.info.InfoProto.GetVersionRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetVersionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetVersionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Get the speed factor of a simulation (with lockstep a simulation can run faster or slower than realtime).
     * </pre>
     */
    public void getSpeedFactor(io.mavsdk.info.InfoProto.GetSpeedFactorRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetSpeedFactorResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetSpeedFactorMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetFlightInformationMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.info.InfoProto.GetFlightInformationRequest,
                io.mavsdk.info.InfoProto.GetFlightInformationResponse>(
                  this, METHODID_GET_FLIGHT_INFORMATION)))
          .addMethod(
            getGetIdentificationMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.info.InfoProto.GetIdentificationRequest,
                io.mavsdk.info.InfoProto.GetIdentificationResponse>(
                  this, METHODID_GET_IDENTIFICATION)))
          .addMethod(
            getGetProductMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.info.InfoProto.GetProductRequest,
                io.mavsdk.info.InfoProto.GetProductResponse>(
                  this, METHODID_GET_PRODUCT)))
          .addMethod(
            getGetVersionMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.info.InfoProto.GetVersionRequest,
                io.mavsdk.info.InfoProto.GetVersionResponse>(
                  this, METHODID_GET_VERSION)))
          .addMethod(
            getGetSpeedFactorMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.info.InfoProto.GetSpeedFactorRequest,
                io.mavsdk.info.InfoProto.GetSpeedFactorResponse>(
                  this, METHODID_GET_SPEED_FACTOR)))
          .build();
    }
  }

  /**
   * <pre>
   * Provide information about the hardware and/or software of a system.
   * </pre>
   */
  public static final class InfoServiceStub extends io.grpc.stub.AbstractAsyncStub<InfoServiceStub> {
    private InfoServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InfoServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InfoServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Get flight information of the system.
     * </pre>
     */
    public void getFlightInformation(io.mavsdk.info.InfoProto.GetFlightInformationRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetFlightInformationResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetFlightInformationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Get the identification of the system.
     * </pre>
     */
    public void getIdentification(io.mavsdk.info.InfoProto.GetIdentificationRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetIdentificationResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetIdentificationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Get product information of the system.
     * </pre>
     */
    public void getProduct(io.mavsdk.info.InfoProto.GetProductRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetProductResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetProductMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Get the version information of the system.
     * </pre>
     */
    public void getVersion(io.mavsdk.info.InfoProto.GetVersionRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetVersionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetVersionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Get the speed factor of a simulation (with lockstep a simulation can run faster or slower than realtime).
     * </pre>
     */
    public void getSpeedFactor(io.mavsdk.info.InfoProto.GetSpeedFactorRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetSpeedFactorResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetSpeedFactorMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Provide information about the hardware and/or software of a system.
   * </pre>
   */
  public static final class InfoServiceBlockingStub extends io.grpc.stub.AbstractBlockingStub<InfoServiceBlockingStub> {
    private InfoServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InfoServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InfoServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Get flight information of the system.
     * </pre>
     */
    public io.mavsdk.info.InfoProto.GetFlightInformationResponse getFlightInformation(io.mavsdk.info.InfoProto.GetFlightInformationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetFlightInformationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get the identification of the system.
     * </pre>
     */
    public io.mavsdk.info.InfoProto.GetIdentificationResponse getIdentification(io.mavsdk.info.InfoProto.GetIdentificationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetIdentificationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get product information of the system.
     * </pre>
     */
    public io.mavsdk.info.InfoProto.GetProductResponse getProduct(io.mavsdk.info.InfoProto.GetProductRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetProductMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get the version information of the system.
     * </pre>
     */
    public io.mavsdk.info.InfoProto.GetVersionResponse getVersion(io.mavsdk.info.InfoProto.GetVersionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetVersionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get the speed factor of a simulation (with lockstep a simulation can run faster or slower than realtime).
     * </pre>
     */
    public io.mavsdk.info.InfoProto.GetSpeedFactorResponse getSpeedFactor(io.mavsdk.info.InfoProto.GetSpeedFactorRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetSpeedFactorMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Provide information about the hardware and/or software of a system.
   * </pre>
   */
  public static final class InfoServiceFutureStub extends io.grpc.stub.AbstractFutureStub<InfoServiceFutureStub> {
    private InfoServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InfoServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InfoServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Get flight information of the system.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.info.InfoProto.GetFlightInformationResponse> getFlightInformation(
        io.mavsdk.info.InfoProto.GetFlightInformationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetFlightInformationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Get the identification of the system.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.info.InfoProto.GetIdentificationResponse> getIdentification(
        io.mavsdk.info.InfoProto.GetIdentificationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetIdentificationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Get product information of the system.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.info.InfoProto.GetProductResponse> getProduct(
        io.mavsdk.info.InfoProto.GetProductRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetProductMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Get the version information of the system.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.info.InfoProto.GetVersionResponse> getVersion(
        io.mavsdk.info.InfoProto.GetVersionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetVersionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Get the speed factor of a simulation (with lockstep a simulation can run faster or slower than realtime).
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.info.InfoProto.GetSpeedFactorResponse> getSpeedFactor(
        io.mavsdk.info.InfoProto.GetSpeedFactorRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetSpeedFactorMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_FLIGHT_INFORMATION = 0;
  private static final int METHODID_GET_IDENTIFICATION = 1;
  private static final int METHODID_GET_PRODUCT = 2;
  private static final int METHODID_GET_VERSION = 3;
  private static final int METHODID_GET_SPEED_FACTOR = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final InfoServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(InfoServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_FLIGHT_INFORMATION:
          serviceImpl.getFlightInformation((io.mavsdk.info.InfoProto.GetFlightInformationRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetFlightInformationResponse>) responseObserver);
          break;
        case METHODID_GET_IDENTIFICATION:
          serviceImpl.getIdentification((io.mavsdk.info.InfoProto.GetIdentificationRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetIdentificationResponse>) responseObserver);
          break;
        case METHODID_GET_PRODUCT:
          serviceImpl.getProduct((io.mavsdk.info.InfoProto.GetProductRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetProductResponse>) responseObserver);
          break;
        case METHODID_GET_VERSION:
          serviceImpl.getVersion((io.mavsdk.info.InfoProto.GetVersionRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetVersionResponse>) responseObserver);
          break;
        case METHODID_GET_SPEED_FACTOR:
          serviceImpl.getSpeedFactor((io.mavsdk.info.InfoProto.GetSpeedFactorRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.info.InfoProto.GetSpeedFactorResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InfoServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .addMethod(getGetFlightInformationMethod())
              .addMethod(getGetIdentificationMethod())
              .addMethod(getGetProductMethod())
              .addMethod(getGetVersionMethod())
              .addMethod(getGetSpeedFactorMethod())
              .build();
        }
      }
    }
    return result;
  }
}
