package io.mavsdk.action;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Action implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Action.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ActionServiceGrpc.ActionServiceStub stub;

  private volatile boolean isInitialized = false;

  public Action(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Action() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ActionServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ActionException extends MavsdkException {
    private ActionResult.Result code;
    private String description;

    public ActionException(ActionResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ActionResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum OrbitYawBehavior {
      
      HOLD_FRONT_TO_CIRCLE_CENTER {
        @Override
        protected ActionProto.OrbitYawBehavior rpcOrbitYawBehavior() {
          return ActionProto.OrbitYawBehavior.ORBIT_YAW_BEHAVIOR_HOLD_FRONT_TO_CIRCLE_CENTER;
        }
      }, 
      HOLD_INITIAL_HEADING {
        @Override
        protected ActionProto.OrbitYawBehavior rpcOrbitYawBehavior() {
          return ActionProto.OrbitYawBehavior.ORBIT_YAW_BEHAVIOR_HOLD_INITIAL_HEADING;
        }
      }, 
      UNCONTROLLED {
        @Override
        protected ActionProto.OrbitYawBehavior rpcOrbitYawBehavior() {
          return ActionProto.OrbitYawBehavior.ORBIT_YAW_BEHAVIOR_UNCONTROLLED;
        }
      }, 
      HOLD_FRONT_TANGENT_TO_CIRCLE {
        @Override
        protected ActionProto.OrbitYawBehavior rpcOrbitYawBehavior() {
          return ActionProto.OrbitYawBehavior.ORBIT_YAW_BEHAVIOR_HOLD_FRONT_TANGENT_TO_CIRCLE;
        }
      }, 
      RC_CONTROLLED {
        @Override
        protected ActionProto.OrbitYawBehavior rpcOrbitYawBehavior() {
          return ActionProto.OrbitYawBehavior.ORBIT_YAW_BEHAVIOR_RC_CONTROLLED;
        }
      };

      protected static OrbitYawBehavior translateFromRpc(ActionProto.OrbitYawBehavior rpcOrbitYawBehavior) {
        switch (rpcOrbitYawBehavior) {
          case ORBIT_YAW_BEHAVIOR_HOLD_FRONT_TO_CIRCLE_CENTER: default: 
            return OrbitYawBehavior.HOLD_FRONT_TO_CIRCLE_CENTER;
          case ORBIT_YAW_BEHAVIOR_HOLD_INITIAL_HEADING: 
            return OrbitYawBehavior.HOLD_INITIAL_HEADING;
          case ORBIT_YAW_BEHAVIOR_UNCONTROLLED: 
            return OrbitYawBehavior.UNCONTROLLED;
          case ORBIT_YAW_BEHAVIOR_HOLD_FRONT_TANGENT_TO_CIRCLE: 
            return OrbitYawBehavior.HOLD_FRONT_TANGENT_TO_CIRCLE;
          case ORBIT_YAW_BEHAVIOR_RC_CONTROLLED: 
            return OrbitYawBehavior.RC_CONTROLLED;
        }
      }

      protected abstract ActionProto.OrbitYawBehavior rpcOrbitYawBehavior();
    }


    public static class ActionResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          COMMAND_DENIED_LANDED_STATE_UNKNOWN {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_COMMAND_DENIED_LANDED_STATE_UNKNOWN;
            }
          }, 
          COMMAND_DENIED_NOT_LANDED {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_COMMAND_DENIED_NOT_LANDED;
            }
          }, 
          TIMEOUT {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_TIMEOUT;
            }
          }, 
          VTOL_TRANSITION_SUPPORT_UNKNOWN {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_VTOL_TRANSITION_SUPPORT_UNKNOWN;
            }
          }, 
          NO_VTOL_TRANSITION_SUPPORT {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_NO_VTOL_TRANSITION_SUPPORT;
            }
          }, 
          PARAMETER_ERROR {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_PARAMETER_ERROR;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected ActionProto.ActionResult.Result rpcResult() {
              return ActionProto.ActionResult.Result.RESULT_UNSUPPORTED;
            }
          };

          protected static Result translateFromRpc(ActionProto.ActionResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_COMMAND_DENIED_LANDED_STATE_UNKNOWN: 
                return Result.COMMAND_DENIED_LANDED_STATE_UNKNOWN;
              case RESULT_COMMAND_DENIED_NOT_LANDED: 
                return Result.COMMAND_DENIED_NOT_LANDED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_VTOL_TRANSITION_SUPPORT_UNKNOWN: 
                return Result.VTOL_TRANSITION_SUPPORT_UNKNOWN;
              case RESULT_NO_VTOL_TRANSITION_SUPPORT: 
                return Result.NO_VTOL_TRANSITION_SUPPORT;
              case RESULT_PARAMETER_ERROR: 
                return Result.PARAMETER_ERROR;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
            }
          }

          protected abstract ActionProto.ActionResult.Result rpcResult();
        }

      public ActionResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ActionProto.ActionResult rpcActionResult() {
        return ActionProto.ActionResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ActionResult translateFromRpc(ActionProto.ActionResult rpcActionResult) {
        return new ActionResult(
                Result.translateFromRpc(rpcActionResult.getResult()),
                rpcActionResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable arm() {

      ActionProto.ArmRequest request = ActionProto.ArmRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.arm(request, new StreamObserver<ActionProto.ArmResponse>() {

          @Override
          public void onNext(ActionProto.ArmResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable disarm() {

      ActionProto.DisarmRequest request = ActionProto.DisarmRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.disarm(request, new StreamObserver<ActionProto.DisarmResponse>() {

          @Override
          public void onNext(ActionProto.DisarmResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable takeoff() {

      ActionProto.TakeoffRequest request = ActionProto.TakeoffRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.takeoff(request, new StreamObserver<ActionProto.TakeoffResponse>() {

          @Override
          public void onNext(ActionProto.TakeoffResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable land() {

      ActionProto.LandRequest request = ActionProto.LandRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.land(request, new StreamObserver<ActionProto.LandResponse>() {

          @Override
          public void onNext(ActionProto.LandResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable reboot() {

      ActionProto.RebootRequest request = ActionProto.RebootRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.reboot(request, new StreamObserver<ActionProto.RebootResponse>() {

          @Override
          public void onNext(ActionProto.RebootResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable shutdown() {

      ActionProto.ShutdownRequest request = ActionProto.ShutdownRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.shutdown(request, new StreamObserver<ActionProto.ShutdownResponse>() {

          @Override
          public void onNext(ActionProto.ShutdownResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable terminate() {

      ActionProto.TerminateRequest request = ActionProto.TerminateRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.terminate(request, new StreamObserver<ActionProto.TerminateResponse>() {

          @Override
          public void onNext(ActionProto.TerminateResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable kill() {

      ActionProto.KillRequest request = ActionProto.KillRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.kill(request, new StreamObserver<ActionProto.KillResponse>() {

          @Override
          public void onNext(ActionProto.KillResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable returnToLaunch() {

      ActionProto.ReturnToLaunchRequest request = ActionProto.ReturnToLaunchRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.returnToLaunch(request, new StreamObserver<ActionProto.ReturnToLaunchResponse>() {

          @Override
          public void onNext(ActionProto.ReturnToLaunchResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable gotoLocation(@NonNull Double latitudeDeg, @NonNull Double longitudeDeg, @NonNull Float absoluteAltitudeM, @NonNull Float yawDeg) {

      ActionProto.GotoLocationRequest request = ActionProto.GotoLocationRequest.newBuilder()
        .setLatitudeDeg(latitudeDeg)
        .setLongitudeDeg(longitudeDeg)
        .setAbsoluteAltitudeM(absoluteAltitudeM)
        .setYawDeg(yawDeg)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.gotoLocation(request, new StreamObserver<ActionProto.GotoLocationResponse>() {

          @Override
          public void onNext(ActionProto.GotoLocationResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable doOrbit(@NonNull Float radiusM, @NonNull Float velocityMs, @NonNull OrbitYawBehavior yawBehavior, @NonNull Double latitudeDeg, @NonNull Double longitudeDeg, @NonNull Double absoluteAltitudeM) {

      ActionProto.DoOrbitRequest request = ActionProto.DoOrbitRequest.newBuilder()
        .setRadiusM(radiusM)
        .setVelocityMs(velocityMs)
        .setYawBehavior(yawBehavior.rpcOrbitYawBehavior())
        .setLatitudeDeg(latitudeDeg)
        .setLongitudeDeg(longitudeDeg)
        .setAbsoluteAltitudeM(absoluteAltitudeM)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.doOrbit(request, new StreamObserver<ActionProto.DoOrbitResponse>() {

          @Override
          public void onNext(ActionProto.DoOrbitResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable hold() {

      ActionProto.HoldRequest request = ActionProto.HoldRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.hold(request, new StreamObserver<ActionProto.HoldResponse>() {

          @Override
          public void onNext(ActionProto.HoldResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setActuator(@NonNull Integer index, @NonNull Float value) {

      ActionProto.SetActuatorRequest request = ActionProto.SetActuatorRequest.newBuilder()
        .setIndex(index)
        .setValue(value)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setActuator(request, new StreamObserver<ActionProto.SetActuatorResponse>() {

          @Override
          public void onNext(ActionProto.SetActuatorResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable transitionToFixedwing() {

      ActionProto.TransitionToFixedwingRequest request = ActionProto.TransitionToFixedwingRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.transitionToFixedwing(request, new StreamObserver<ActionProto.TransitionToFixedwingResponse>() {

          @Override
          public void onNext(ActionProto.TransitionToFixedwingResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable transitionToMulticopter() {

      ActionProto.TransitionToMulticopterRequest request = ActionProto.TransitionToMulticopterRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.transitionToMulticopter(request, new StreamObserver<ActionProto.TransitionToMulticopterResponse>() {

          @Override
          public void onNext(ActionProto.TransitionToMulticopterResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Float> getTakeoffAltitude() {
      ActionProto.GetTakeoffAltitudeRequest request = ActionProto.GetTakeoffAltitudeRequest.newBuilder()
        .build();

      Single<Float> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getTakeoffAltitude(request, new StreamObserver<ActionProto.GetTakeoffAltitudeResponse>() {

          @Override
          public void onNext(ActionProto.GetTakeoffAltitudeResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getAltitude());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setTakeoffAltitude(@NonNull Float altitude) {

      ActionProto.SetTakeoffAltitudeRequest request = ActionProto.SetTakeoffAltitudeRequest.newBuilder()
        .setAltitude(altitude)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setTakeoffAltitude(request, new StreamObserver<ActionProto.SetTakeoffAltitudeResponse>() {

          @Override
          public void onNext(ActionProto.SetTakeoffAltitudeResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Float> getMaximumSpeed() {
      ActionProto.GetMaximumSpeedRequest request = ActionProto.GetMaximumSpeedRequest.newBuilder()
        .build();

      Single<Float> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getMaximumSpeed(request, new StreamObserver<ActionProto.GetMaximumSpeedResponse>() {

          @Override
          public void onNext(ActionProto.GetMaximumSpeedResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getSpeed());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setMaximumSpeed(@NonNull Float speed) {

      ActionProto.SetMaximumSpeedRequest request = ActionProto.SetMaximumSpeedRequest.newBuilder()
        .setSpeed(speed)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setMaximumSpeed(request, new StreamObserver<ActionProto.SetMaximumSpeedResponse>() {

          @Override
          public void onNext(ActionProto.SetMaximumSpeedResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Float> getReturnToLaunchAltitude() {
      ActionProto.GetReturnToLaunchAltitudeRequest request = ActionProto.GetReturnToLaunchAltitudeRequest.newBuilder()
        .build();

      Single<Float> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getReturnToLaunchAltitude(request, new StreamObserver<ActionProto.GetReturnToLaunchAltitudeResponse>() {

          @Override
          public void onNext(ActionProto.GetReturnToLaunchAltitudeResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getRelativeAltitudeM());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setReturnToLaunchAltitude(@NonNull Float relativeAltitudeM) {

      ActionProto.SetReturnToLaunchAltitudeRequest request = ActionProto.SetReturnToLaunchAltitudeRequest.newBuilder()
        .setRelativeAltitudeM(relativeAltitudeM)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setReturnToLaunchAltitude(request, new StreamObserver<ActionProto.SetReturnToLaunchAltitudeResponse>() {

          @Override
          public void onNext(ActionProto.SetReturnToLaunchAltitudeResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setCurrentSpeed(@NonNull Float speedMS) {

      ActionProto.SetCurrentSpeedRequest request = ActionProto.SetCurrentSpeedRequest.newBuilder()
        .setSpeedMS(speedMS)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setCurrentSpeed(request, new StreamObserver<ActionProto.SetCurrentSpeedResponse>() {

          @Override
          public void onNext(ActionProto.SetCurrentSpeedResponse value) {
            ActionResult result = ActionResult.translateFromRpc(value.getActionResult());

            if (result.result != ActionResult.Result.SUCCESS) {
              emitter.onError(new ActionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}