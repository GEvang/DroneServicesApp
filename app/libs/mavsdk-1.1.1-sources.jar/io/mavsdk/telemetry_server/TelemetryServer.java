package io.mavsdk.telemetry_server;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TelemetryServer implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(TelemetryServer.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private TelemetryServerServiceGrpc.TelemetryServerServiceStub stub;

  private volatile boolean isInitialized = false;

  public TelemetryServer(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public TelemetryServer() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = TelemetryServerServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class TelemetryServerException extends MavsdkException {
    private TelemetryServerResult.Result code;
    private String description;

    public TelemetryServerException(TelemetryServerResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public TelemetryServerResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum FixType {
      
      NO_GPS {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_NO_GPS;
        }
      }, 
      NO_FIX {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_NO_FIX;
        }
      }, 
      FIX_2D {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_FIX_2D;
        }
      }, 
      FIX_3D {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_FIX_3D;
        }
      }, 
      FIX_DGPS {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_FIX_DGPS;
        }
      }, 
      RTK_FLOAT {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_RTK_FLOAT;
        }
      }, 
      RTK_FIXED {
        @Override
        protected TelemetryServerProto.FixType rpcFixType() {
          return TelemetryServerProto.FixType.FIX_TYPE_RTK_FIXED;
        }
      };

      protected static FixType translateFromRpc(TelemetryServerProto.FixType rpcFixType) {
        switch (rpcFixType) {
          case FIX_TYPE_NO_GPS: default: 
            return FixType.NO_GPS;
          case FIX_TYPE_NO_FIX: 
            return FixType.NO_FIX;
          case FIX_TYPE_FIX_2D: 
            return FixType.FIX_2D;
          case FIX_TYPE_FIX_3D: 
            return FixType.FIX_3D;
          case FIX_TYPE_FIX_DGPS: 
            return FixType.FIX_DGPS;
          case FIX_TYPE_RTK_FLOAT: 
            return FixType.RTK_FLOAT;
          case FIX_TYPE_RTK_FIXED: 
            return FixType.RTK_FIXED;
        }
      }

      protected abstract TelemetryServerProto.FixType rpcFixType();
    }
    public enum VtolState {
      
      UNDEFINED {
        @Override
        protected TelemetryServerProto.VtolState rpcVtolState() {
          return TelemetryServerProto.VtolState.VTOL_STATE_UNDEFINED;
        }
      }, 
      TRANSITION_TO_FW {
        @Override
        protected TelemetryServerProto.VtolState rpcVtolState() {
          return TelemetryServerProto.VtolState.VTOL_STATE_TRANSITION_TO_FW;
        }
      }, 
      TRANSITION_TO_MC {
        @Override
        protected TelemetryServerProto.VtolState rpcVtolState() {
          return TelemetryServerProto.VtolState.VTOL_STATE_TRANSITION_TO_MC;
        }
      }, 
      MC {
        @Override
        protected TelemetryServerProto.VtolState rpcVtolState() {
          return TelemetryServerProto.VtolState.VTOL_STATE_MC;
        }
      }, 
      FW {
        @Override
        protected TelemetryServerProto.VtolState rpcVtolState() {
          return TelemetryServerProto.VtolState.VTOL_STATE_FW;
        }
      };

      protected static VtolState translateFromRpc(TelemetryServerProto.VtolState rpcVtolState) {
        switch (rpcVtolState) {
          case VTOL_STATE_UNDEFINED: default: 
            return VtolState.UNDEFINED;
          case VTOL_STATE_TRANSITION_TO_FW: 
            return VtolState.TRANSITION_TO_FW;
          case VTOL_STATE_TRANSITION_TO_MC: 
            return VtolState.TRANSITION_TO_MC;
          case VTOL_STATE_MC: 
            return VtolState.MC;
          case VTOL_STATE_FW: 
            return VtolState.FW;
        }
      }

      protected abstract TelemetryServerProto.VtolState rpcVtolState();
    }
    public enum StatusTextType {
      
      DEBUG {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_DEBUG;
        }
      }, 
      INFO {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_INFO;
        }
      }, 
      NOTICE {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_NOTICE;
        }
      }, 
      WARNING {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_WARNING;
        }
      }, 
      ERROR {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_ERROR;
        }
      }, 
      CRITICAL {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_CRITICAL;
        }
      }, 
      ALERT {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_ALERT;
        }
      }, 
      EMERGENCY {
        @Override
        protected TelemetryServerProto.StatusTextType rpcStatusTextType() {
          return TelemetryServerProto.StatusTextType.STATUS_TEXT_TYPE_EMERGENCY;
        }
      };

      protected static StatusTextType translateFromRpc(TelemetryServerProto.StatusTextType rpcStatusTextType) {
        switch (rpcStatusTextType) {
          case STATUS_TEXT_TYPE_DEBUG: default: 
            return StatusTextType.DEBUG;
          case STATUS_TEXT_TYPE_INFO: 
            return StatusTextType.INFO;
          case STATUS_TEXT_TYPE_NOTICE: 
            return StatusTextType.NOTICE;
          case STATUS_TEXT_TYPE_WARNING: 
            return StatusTextType.WARNING;
          case STATUS_TEXT_TYPE_ERROR: 
            return StatusTextType.ERROR;
          case STATUS_TEXT_TYPE_CRITICAL: 
            return StatusTextType.CRITICAL;
          case STATUS_TEXT_TYPE_ALERT: 
            return StatusTextType.ALERT;
          case STATUS_TEXT_TYPE_EMERGENCY: 
            return StatusTextType.EMERGENCY;
        }
      }

      protected abstract TelemetryServerProto.StatusTextType rpcStatusTextType();
    }
    public enum LandedState {
      
      UNKNOWN {
        @Override
        protected TelemetryServerProto.LandedState rpcLandedState() {
          return TelemetryServerProto.LandedState.LANDED_STATE_UNKNOWN;
        }
      }, 
      ON_GROUND {
        @Override
        protected TelemetryServerProto.LandedState rpcLandedState() {
          return TelemetryServerProto.LandedState.LANDED_STATE_ON_GROUND;
        }
      }, 
      IN_AIR {
        @Override
        protected TelemetryServerProto.LandedState rpcLandedState() {
          return TelemetryServerProto.LandedState.LANDED_STATE_IN_AIR;
        }
      }, 
      TAKING_OFF {
        @Override
        protected TelemetryServerProto.LandedState rpcLandedState() {
          return TelemetryServerProto.LandedState.LANDED_STATE_TAKING_OFF;
        }
      }, 
      LANDING {
        @Override
        protected TelemetryServerProto.LandedState rpcLandedState() {
          return TelemetryServerProto.LandedState.LANDED_STATE_LANDING;
        }
      };

      protected static LandedState translateFromRpc(TelemetryServerProto.LandedState rpcLandedState) {
        switch (rpcLandedState) {
          case LANDED_STATE_UNKNOWN: default: 
            return LandedState.UNKNOWN;
          case LANDED_STATE_ON_GROUND: 
            return LandedState.ON_GROUND;
          case LANDED_STATE_IN_AIR: 
            return LandedState.IN_AIR;
          case LANDED_STATE_TAKING_OFF: 
            return LandedState.TAKING_OFF;
          case LANDED_STATE_LANDING: 
            return LandedState.LANDING;
        }
      }

      protected abstract TelemetryServerProto.LandedState rpcLandedState();
    }


    public static class Position {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float relativeAltitudeM;

      public Position(Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float relativeAltitudeM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.relativeAltitudeM = relativeAltitudeM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getRelativeAltitudeM() {
        return relativeAltitudeM;
      }

      protected TelemetryServerProto.Position rpcPosition() {
        return TelemetryServerProto.Position.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setRelativeAltitudeM(this.relativeAltitudeM)
          .build();
      }

      protected static Position translateFromRpc(TelemetryServerProto.Position rpcPosition) {
        return new Position(
                rpcPosition.getLatitudeDeg(),
                rpcPosition.getLongitudeDeg(),
                rpcPosition.getAbsoluteAltitudeM(),
                rpcPosition.getRelativeAltitudeM());
      }
    }


    public static class Heading {
      private Double headingDeg;

      public Heading(Double headingDeg) {
        this.headingDeg = headingDeg;
      }
      public Double getHeadingDeg() {
        return headingDeg;
      }

      protected TelemetryServerProto.Heading rpcHeading() {
        return TelemetryServerProto.Heading.newBuilder()
          .setHeadingDeg(this.headingDeg)
          .build();
      }

      protected static Heading translateFromRpc(TelemetryServerProto.Heading rpcHeading) {
        return new Heading(
                rpcHeading.getHeadingDeg());
      }
    }


    public static class Quaternion {
      private Float w;
      private Float x;
      private Float y;
      private Float z;
      private Long timestampUs;

      public Quaternion(Float w, Float x, Float y, Float z, Long timestampUs) {
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.timestampUs = timestampUs;
      }
      public Float getW() {
        return w;
      }
      public Float getX() {
        return x;
      }
      public Float getY() {
        return y;
      }
      public Float getZ() {
        return z;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }

      protected TelemetryServerProto.Quaternion rpcQuaternion() {
        return TelemetryServerProto.Quaternion.newBuilder()
          .setW(this.w)
          .setX(this.x)
          .setY(this.y)
          .setZ(this.z)
          .setTimestampUs(this.timestampUs)
          .build();
      }

      protected static Quaternion translateFromRpc(TelemetryServerProto.Quaternion rpcQuaternion) {
        return new Quaternion(
                rpcQuaternion.getW(),
                rpcQuaternion.getX(),
                rpcQuaternion.getY(),
                rpcQuaternion.getZ(),
                rpcQuaternion.getTimestampUs());
      }
    }


    public static class EulerAngle {
      private Float rollDeg;
      private Float pitchDeg;
      private Float yawDeg;
      private Long timestampUs;

      public EulerAngle(Float rollDeg, Float pitchDeg, Float yawDeg, Long timestampUs) {
        this.rollDeg = rollDeg;
        this.pitchDeg = pitchDeg;
        this.yawDeg = yawDeg;
        this.timestampUs = timestampUs;
      }
      public Float getRollDeg() {
        return rollDeg;
      }
      public Float getPitchDeg() {
        return pitchDeg;
      }
      public Float getYawDeg() {
        return yawDeg;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }

      protected TelemetryServerProto.EulerAngle rpcEulerAngle() {
        return TelemetryServerProto.EulerAngle.newBuilder()
          .setRollDeg(this.rollDeg)
          .setPitchDeg(this.pitchDeg)
          .setYawDeg(this.yawDeg)
          .setTimestampUs(this.timestampUs)
          .build();
      }

      protected static EulerAngle translateFromRpc(TelemetryServerProto.EulerAngle rpcEulerAngle) {
        return new EulerAngle(
                rpcEulerAngle.getRollDeg(),
                rpcEulerAngle.getPitchDeg(),
                rpcEulerAngle.getYawDeg(),
                rpcEulerAngle.getTimestampUs());
      }
    }


    public static class AngularVelocityBody {
      private Float rollRadS;
      private Float pitchRadS;
      private Float yawRadS;

      public AngularVelocityBody(Float rollRadS, Float pitchRadS, Float yawRadS) {
        this.rollRadS = rollRadS;
        this.pitchRadS = pitchRadS;
        this.yawRadS = yawRadS;
      }
      public Float getRollRadS() {
        return rollRadS;
      }
      public Float getPitchRadS() {
        return pitchRadS;
      }
      public Float getYawRadS() {
        return yawRadS;
      }

      protected TelemetryServerProto.AngularVelocityBody rpcAngularVelocityBody() {
        return TelemetryServerProto.AngularVelocityBody.newBuilder()
          .setRollRadS(this.rollRadS)
          .setPitchRadS(this.pitchRadS)
          .setYawRadS(this.yawRadS)
          .build();
      }

      protected static AngularVelocityBody translateFromRpc(TelemetryServerProto.AngularVelocityBody rpcAngularVelocityBody) {
        return new AngularVelocityBody(
                rpcAngularVelocityBody.getRollRadS(),
                rpcAngularVelocityBody.getPitchRadS(),
                rpcAngularVelocityBody.getYawRadS());
      }
    }


    public static class GpsInfo {
      private Integer numSatellites;
      private FixType fixType;

      public GpsInfo(Integer numSatellites, FixType fixType) {
        this.numSatellites = numSatellites;
        this.fixType = fixType;
      }
      public Integer getNumSatellites() {
        return numSatellites;
      }
      public FixType getFixType() {
        return fixType;
      }

      protected TelemetryServerProto.GpsInfo rpcGpsInfo() {
        return TelemetryServerProto.GpsInfo.newBuilder()
          .setNumSatellites(this.numSatellites)
          .setFixType(this.fixType.rpcFixType())
          .build();
      }

      protected static GpsInfo translateFromRpc(TelemetryServerProto.GpsInfo rpcGpsInfo) {
        return new GpsInfo(
                rpcGpsInfo.getNumSatellites(),
                FixType.translateFromRpc(rpcGpsInfo.getFixType()));
      }
    }


    public static class RawGps {
      private Long timestampUs;
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float hdop;
      private Float vdop;
      private Float velocityMS;
      private Float cogDeg;
      private Float altitudeEllipsoidM;
      private Float horizontalUncertaintyM;
      private Float verticalUncertaintyM;
      private Float velocityUncertaintyMS;
      private Float headingUncertaintyDeg;
      private Float yawDeg;

      public RawGps(Long timestampUs, Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float hdop, Float vdop, Float velocityMS, Float cogDeg, Float altitudeEllipsoidM, Float horizontalUncertaintyM, Float verticalUncertaintyM, Float velocityUncertaintyMS, Float headingUncertaintyDeg, Float yawDeg) {
        this.timestampUs = timestampUs;
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.hdop = hdop;
        this.vdop = vdop;
        this.velocityMS = velocityMS;
        this.cogDeg = cogDeg;
        this.altitudeEllipsoidM = altitudeEllipsoidM;
        this.horizontalUncertaintyM = horizontalUncertaintyM;
        this.verticalUncertaintyM = verticalUncertaintyM;
        this.velocityUncertaintyMS = velocityUncertaintyMS;
        this.headingUncertaintyDeg = headingUncertaintyDeg;
        this.yawDeg = yawDeg;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getHdop() {
        return hdop;
      }
      public Float getVdop() {
        return vdop;
      }
      public Float getVelocityMS() {
        return velocityMS;
      }
      public Float getCogDeg() {
        return cogDeg;
      }
      public Float getAltitudeEllipsoidM() {
        return altitudeEllipsoidM;
      }
      public Float getHorizontalUncertaintyM() {
        return horizontalUncertaintyM;
      }
      public Float getVerticalUncertaintyM() {
        return verticalUncertaintyM;
      }
      public Float getVelocityUncertaintyMS() {
        return velocityUncertaintyMS;
      }
      public Float getHeadingUncertaintyDeg() {
        return headingUncertaintyDeg;
      }
      public Float getYawDeg() {
        return yawDeg;
      }

      protected TelemetryServerProto.RawGps rpcRawGps() {
        return TelemetryServerProto.RawGps.newBuilder()
          .setTimestampUs(this.timestampUs)
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setHdop(this.hdop)
          .setVdop(this.vdop)
          .setVelocityMS(this.velocityMS)
          .setCogDeg(this.cogDeg)
          .setAltitudeEllipsoidM(this.altitudeEllipsoidM)
          .setHorizontalUncertaintyM(this.horizontalUncertaintyM)
          .setVerticalUncertaintyM(this.verticalUncertaintyM)
          .setVelocityUncertaintyMS(this.velocityUncertaintyMS)
          .setHeadingUncertaintyDeg(this.headingUncertaintyDeg)
          .setYawDeg(this.yawDeg)
          .build();
      }

      protected static RawGps translateFromRpc(TelemetryServerProto.RawGps rpcRawGps) {
        return new RawGps(
                rpcRawGps.getTimestampUs(),
                rpcRawGps.getLatitudeDeg(),
                rpcRawGps.getLongitudeDeg(),
                rpcRawGps.getAbsoluteAltitudeM(),
                rpcRawGps.getHdop(),
                rpcRawGps.getVdop(),
                rpcRawGps.getVelocityMS(),
                rpcRawGps.getCogDeg(),
                rpcRawGps.getAltitudeEllipsoidM(),
                rpcRawGps.getHorizontalUncertaintyM(),
                rpcRawGps.getVerticalUncertaintyM(),
                rpcRawGps.getVelocityUncertaintyMS(),
                rpcRawGps.getHeadingUncertaintyDeg(),
                rpcRawGps.getYawDeg());
      }
    }


    public static class Battery {
      private Float voltageV;
      private Float remainingPercent;

      public Battery(Float voltageV, Float remainingPercent) {
        this.voltageV = voltageV;
        this.remainingPercent = remainingPercent;
      }
      public Float getVoltageV() {
        return voltageV;
      }
      public Float getRemainingPercent() {
        return remainingPercent;
      }

      protected TelemetryServerProto.Battery rpcBattery() {
        return TelemetryServerProto.Battery.newBuilder()
          .setVoltageV(this.voltageV)
          .setRemainingPercent(this.remainingPercent)
          .build();
      }

      protected static Battery translateFromRpc(TelemetryServerProto.Battery rpcBattery) {
        return new Battery(
                rpcBattery.getVoltageV(),
                rpcBattery.getRemainingPercent());
      }
    }


    public static class RcStatus {
      private Boolean wasAvailableOnce;
      private Boolean isAvailable;
      private Float signalStrengthPercent;

      public RcStatus(Boolean wasAvailableOnce, Boolean isAvailable, Float signalStrengthPercent) {
        this.wasAvailableOnce = wasAvailableOnce;
        this.isAvailable = isAvailable;
        this.signalStrengthPercent = signalStrengthPercent;
      }
      public Boolean getWasAvailableOnce() {
        return wasAvailableOnce;
      }
      public Boolean getIsAvailable() {
        return isAvailable;
      }
      public Float getSignalStrengthPercent() {
        return signalStrengthPercent;
      }

      protected TelemetryServerProto.RcStatus rpcRcStatus() {
        return TelemetryServerProto.RcStatus.newBuilder()
          .setWasAvailableOnce(this.wasAvailableOnce)
          .setIsAvailable(this.isAvailable)
          .setSignalStrengthPercent(this.signalStrengthPercent)
          .build();
      }

      protected static RcStatus translateFromRpc(TelemetryServerProto.RcStatus rpcRcStatus) {
        return new RcStatus(
                rpcRcStatus.getWasAvailableOnce(),
                rpcRcStatus.getIsAvailable(),
                rpcRcStatus.getSignalStrengthPercent());
      }
    }


    public static class StatusText {
      private StatusTextType type;
      private String text;

      public StatusText(StatusTextType type, String text) {
        this.type = type;
        this.text = text;
      }
      public StatusTextType getType() {
        return type;
      }
      public String getText() {
        return text;
      }

      protected TelemetryServerProto.StatusText rpcStatusText() {
        return TelemetryServerProto.StatusText.newBuilder()
          .setType(this.type.rpcStatusTextType())
          .setText(this.text)
          .build();
      }

      protected static StatusText translateFromRpc(TelemetryServerProto.StatusText rpcStatusText) {
        return new StatusText(
                StatusTextType.translateFromRpc(rpcStatusText.getType()),
                rpcStatusText.getText());
      }
    }


    public static class ActuatorControlTarget {
      private Integer group;
      private List<Float> controls;

      public ActuatorControlTarget(Integer group, List<Float> controls) {
        this.group = group;
        this.controls = controls;
      }
      public Integer getGroup() {
        return group;
      }
      public List<Float> getControls() {
        return controls;
      }

      protected TelemetryServerProto.ActuatorControlTarget rpcActuatorControlTarget() {
        return TelemetryServerProto.ActuatorControlTarget.newBuilder()
          .setGroup(this.group)
          .addAllControls(controls)
          .build();
      }

      protected static ActuatorControlTarget translateFromRpc(TelemetryServerProto.ActuatorControlTarget rpcActuatorControlTarget) {
        return new ActuatorControlTarget(
                rpcActuatorControlTarget.getGroup(),
                    rpcActuatorControlTarget.getControlsList());
      }
    }


    public static class ActuatorOutputStatus {
      private Integer active;
      private List<Float> actuator;

      public ActuatorOutputStatus(Integer active, List<Float> actuator) {
        this.active = active;
        this.actuator = actuator;
      }
      public Integer getActive() {
        return active;
      }
      public List<Float> getActuator() {
        return actuator;
      }

      protected TelemetryServerProto.ActuatorOutputStatus rpcActuatorOutputStatus() {
        return TelemetryServerProto.ActuatorOutputStatus.newBuilder()
          .setActive(this.active)
          .addAllActuator(actuator)
          .build();
      }

      protected static ActuatorOutputStatus translateFromRpc(TelemetryServerProto.ActuatorOutputStatus rpcActuatorOutputStatus) {
        return new ActuatorOutputStatus(
                rpcActuatorOutputStatus.getActive(),
                    rpcActuatorOutputStatus.getActuatorList());
      }
    }


    public static class Covariance {
      private List<Float> covarianceMatrix;

      public Covariance(List<Float> covarianceMatrix) {
        this.covarianceMatrix = covarianceMatrix;
      }
      public List<Float> getCovarianceMatrix() {
        return covarianceMatrix;
      }

      protected TelemetryServerProto.Covariance rpcCovariance() {
        return TelemetryServerProto.Covariance.newBuilder()
          .addAllCovarianceMatrix(covarianceMatrix)
          .build();
      }

      protected static Covariance translateFromRpc(TelemetryServerProto.Covariance rpcCovariance) {
        return new Covariance(
                    rpcCovariance.getCovarianceMatrixList());
      }
    }


    public static class VelocityBody {
      private Float xMS;
      private Float yMS;
      private Float zMS;

      public VelocityBody(Float xMS, Float yMS, Float zMS) {
        this.xMS = xMS;
        this.yMS = yMS;
        this.zMS = zMS;
      }
      public Float getXMS() {
        return xMS;
      }
      public Float getYMS() {
        return yMS;
      }
      public Float getZMS() {
        return zMS;
      }

      protected TelemetryServerProto.VelocityBody rpcVelocityBody() {
        return TelemetryServerProto.VelocityBody.newBuilder()
          .setXMS(this.xMS)
          .setYMS(this.yMS)
          .setZMS(this.zMS)
          .build();
      }

      protected static VelocityBody translateFromRpc(TelemetryServerProto.VelocityBody rpcVelocityBody) {
        return new VelocityBody(
                rpcVelocityBody.getXMS(),
                rpcVelocityBody.getYMS(),
                rpcVelocityBody.getZMS());
      }
    }


    public static class PositionBody {
      private Float xM;
      private Float yM;
      private Float zM;

      public PositionBody(Float xM, Float yM, Float zM) {
        this.xM = xM;
        this.yM = yM;
        this.zM = zM;
      }
      public Float getXM() {
        return xM;
      }
      public Float getYM() {
        return yM;
      }
      public Float getZM() {
        return zM;
      }

      protected TelemetryServerProto.PositionBody rpcPositionBody() {
        return TelemetryServerProto.PositionBody.newBuilder()
          .setXM(this.xM)
          .setYM(this.yM)
          .setZM(this.zM)
          .build();
      }

      protected static PositionBody translateFromRpc(TelemetryServerProto.PositionBody rpcPositionBody) {
        return new PositionBody(
                rpcPositionBody.getXM(),
                rpcPositionBody.getYM(),
                rpcPositionBody.getZM());
      }
    }


    public static class Odometry {
      private Long timeUsec;
      private MavFrame frameId;
      private MavFrame childFrameId;
      private PositionBody positionBody;
      private Quaternion q;
      private VelocityBody velocityBody;
      private AngularVelocityBody angularVelocityBody;
      private Covariance poseCovariance;
      private Covariance velocityCovariance;
      
        public enum MavFrame {
          
          UNDEF {
            @Override
            protected TelemetryServerProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryServerProto.Odometry.MavFrame.MAV_FRAME_UNDEF;
            }
          }, 
          BODY_NED {
            @Override
            protected TelemetryServerProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryServerProto.Odometry.MavFrame.MAV_FRAME_BODY_NED;
            }
          }, 
          VISION_NED {
            @Override
            protected TelemetryServerProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryServerProto.Odometry.MavFrame.MAV_FRAME_VISION_NED;
            }
          }, 
          ESTIM_NED {
            @Override
            protected TelemetryServerProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryServerProto.Odometry.MavFrame.MAV_FRAME_ESTIM_NED;
            }
          };

          protected static MavFrame translateFromRpc(TelemetryServerProto.Odometry.MavFrame rpcMavFrame) {
            switch (rpcMavFrame) {
              case MAV_FRAME_UNDEF: default: 
                return MavFrame.UNDEF;
              case MAV_FRAME_BODY_NED: 
                return MavFrame.BODY_NED;
              case MAV_FRAME_VISION_NED: 
                return MavFrame.VISION_NED;
              case MAV_FRAME_ESTIM_NED: 
                return MavFrame.ESTIM_NED;
            }
          }

          protected abstract TelemetryServerProto.Odometry.MavFrame rpcMavFrame();
        }

      public Odometry(Long timeUsec, MavFrame frameId, MavFrame childFrameId, PositionBody positionBody, Quaternion q, VelocityBody velocityBody, AngularVelocityBody angularVelocityBody, Covariance poseCovariance, Covariance velocityCovariance) {
        this.timeUsec = timeUsec;
        this.frameId = frameId;
        this.childFrameId = childFrameId;
        this.positionBody = positionBody;
        this.q = q;
        this.velocityBody = velocityBody;
        this.angularVelocityBody = angularVelocityBody;
        this.poseCovariance = poseCovariance;
        this.velocityCovariance = velocityCovariance;
      }
      public Long getTimeUsec() {
        return timeUsec;
      }
      public MavFrame getFrameId() {
        return frameId;
      }
      public MavFrame getChildFrameId() {
        return childFrameId;
      }
      public PositionBody getPositionBody() {
        return positionBody;
      }
      public Quaternion getQ() {
        return q;
      }
      public VelocityBody getVelocityBody() {
        return velocityBody;
      }
      public AngularVelocityBody getAngularVelocityBody() {
        return angularVelocityBody;
      }
      public Covariance getPoseCovariance() {
        return poseCovariance;
      }
      public Covariance getVelocityCovariance() {
        return velocityCovariance;
      }

      protected TelemetryServerProto.Odometry rpcOdometry() {
        return TelemetryServerProto.Odometry.newBuilder()
          .setTimeUsec(this.timeUsec)
          .setFrameId(this.frameId.rpcMavFrame())
          .setChildFrameId(this.childFrameId.rpcMavFrame())
          .setPositionBody(this.positionBody.rpcPositionBody())
          .setQ(this.q.rpcQuaternion())
          .setVelocityBody(this.velocityBody.rpcVelocityBody())
          .setAngularVelocityBody(this.angularVelocityBody.rpcAngularVelocityBody())
          .setPoseCovariance(this.poseCovariance.rpcCovariance())
          .setVelocityCovariance(this.velocityCovariance.rpcCovariance())
          .build();
      }

      protected static Odometry translateFromRpc(TelemetryServerProto.Odometry rpcOdometry) {
        return new Odometry(
                rpcOdometry.getTimeUsec(),
                MavFrame.translateFromRpc(rpcOdometry.getFrameId()),
                MavFrame.translateFromRpc(rpcOdometry.getChildFrameId()),
                PositionBody.translateFromRpc(rpcOdometry.getPositionBody()),
                Quaternion.translateFromRpc(rpcOdometry.getQ()),
                VelocityBody.translateFromRpc(rpcOdometry.getVelocityBody()),
                AngularVelocityBody.translateFromRpc(rpcOdometry.getAngularVelocityBody()),
                Covariance.translateFromRpc(rpcOdometry.getPoseCovariance()),
                Covariance.translateFromRpc(rpcOdometry.getVelocityCovariance()));
      }
    }


    public static class DistanceSensor {
      private Float minimumDistanceM;
      private Float maximumDistanceM;
      private Float currentDistanceM;

      public DistanceSensor(Float minimumDistanceM, Float maximumDistanceM, Float currentDistanceM) {
        this.minimumDistanceM = minimumDistanceM;
        this.maximumDistanceM = maximumDistanceM;
        this.currentDistanceM = currentDistanceM;
      }
      public Float getMinimumDistanceM() {
        return minimumDistanceM;
      }
      public Float getMaximumDistanceM() {
        return maximumDistanceM;
      }
      public Float getCurrentDistanceM() {
        return currentDistanceM;
      }

      protected TelemetryServerProto.DistanceSensor rpcDistanceSensor() {
        return TelemetryServerProto.DistanceSensor.newBuilder()
          .setMinimumDistanceM(this.minimumDistanceM)
          .setMaximumDistanceM(this.maximumDistanceM)
          .setCurrentDistanceM(this.currentDistanceM)
          .build();
      }

      protected static DistanceSensor translateFromRpc(TelemetryServerProto.DistanceSensor rpcDistanceSensor) {
        return new DistanceSensor(
                rpcDistanceSensor.getMinimumDistanceM(),
                rpcDistanceSensor.getMaximumDistanceM(),
                rpcDistanceSensor.getCurrentDistanceM());
      }
    }


    public static class ScaledPressure {
      private Long timestampUs;
      private Float absolutePressureHpa;
      private Float differentialPressureHpa;
      private Float temperatureDeg;
      private Float differentialPressureTemperatureDeg;

      public ScaledPressure(Long timestampUs, Float absolutePressureHpa, Float differentialPressureHpa, Float temperatureDeg, Float differentialPressureTemperatureDeg) {
        this.timestampUs = timestampUs;
        this.absolutePressureHpa = absolutePressureHpa;
        this.differentialPressureHpa = differentialPressureHpa;
        this.temperatureDeg = temperatureDeg;
        this.differentialPressureTemperatureDeg = differentialPressureTemperatureDeg;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }
      public Float getAbsolutePressureHpa() {
        return absolutePressureHpa;
      }
      public Float getDifferentialPressureHpa() {
        return differentialPressureHpa;
      }
      public Float getTemperatureDeg() {
        return temperatureDeg;
      }
      public Float getDifferentialPressureTemperatureDeg() {
        return differentialPressureTemperatureDeg;
      }

      protected TelemetryServerProto.ScaledPressure rpcScaledPressure() {
        return TelemetryServerProto.ScaledPressure.newBuilder()
          .setTimestampUs(this.timestampUs)
          .setAbsolutePressureHpa(this.absolutePressureHpa)
          .setDifferentialPressureHpa(this.differentialPressureHpa)
          .setTemperatureDeg(this.temperatureDeg)
          .setDifferentialPressureTemperatureDeg(this.differentialPressureTemperatureDeg)
          .build();
      }

      protected static ScaledPressure translateFromRpc(TelemetryServerProto.ScaledPressure rpcScaledPressure) {
        return new ScaledPressure(
                rpcScaledPressure.getTimestampUs(),
                rpcScaledPressure.getAbsolutePressureHpa(),
                rpcScaledPressure.getDifferentialPressureHpa(),
                rpcScaledPressure.getTemperatureDeg(),
                rpcScaledPressure.getDifferentialPressureTemperatureDeg());
      }
    }


    public static class PositionNed {
      private Float northM;
      private Float eastM;
      private Float downM;

      public PositionNed(Float northM, Float eastM, Float downM) {
        this.northM = northM;
        this.eastM = eastM;
        this.downM = downM;
      }
      public Float getNorthM() {
        return northM;
      }
      public Float getEastM() {
        return eastM;
      }
      public Float getDownM() {
        return downM;
      }

      protected TelemetryServerProto.PositionNed rpcPositionNed() {
        return TelemetryServerProto.PositionNed.newBuilder()
          .setNorthM(this.northM)
          .setEastM(this.eastM)
          .setDownM(this.downM)
          .build();
      }

      protected static PositionNed translateFromRpc(TelemetryServerProto.PositionNed rpcPositionNed) {
        return new PositionNed(
                rpcPositionNed.getNorthM(),
                rpcPositionNed.getEastM(),
                rpcPositionNed.getDownM());
      }
    }


    public static class VelocityNed {
      private Float northMS;
      private Float eastMS;
      private Float downMS;

      public VelocityNed(Float northMS, Float eastMS, Float downMS) {
        this.northMS = northMS;
        this.eastMS = eastMS;
        this.downMS = downMS;
      }
      public Float getNorthMS() {
        return northMS;
      }
      public Float getEastMS() {
        return eastMS;
      }
      public Float getDownMS() {
        return downMS;
      }

      protected TelemetryServerProto.VelocityNed rpcVelocityNed() {
        return TelemetryServerProto.VelocityNed.newBuilder()
          .setNorthMS(this.northMS)
          .setEastMS(this.eastMS)
          .setDownMS(this.downMS)
          .build();
      }

      protected static VelocityNed translateFromRpc(TelemetryServerProto.VelocityNed rpcVelocityNed) {
        return new VelocityNed(
                rpcVelocityNed.getNorthMS(),
                rpcVelocityNed.getEastMS(),
                rpcVelocityNed.getDownMS());
      }
    }


    public static class PositionVelocityNed {
      private PositionNed position;
      private VelocityNed velocity;

      public PositionVelocityNed(PositionNed position, VelocityNed velocity) {
        this.position = position;
        this.velocity = velocity;
      }
      public PositionNed getPosition() {
        return position;
      }
      public VelocityNed getVelocity() {
        return velocity;
      }

      protected TelemetryServerProto.PositionVelocityNed rpcPositionVelocityNed() {
        return TelemetryServerProto.PositionVelocityNed.newBuilder()
          .setPosition(this.position.rpcPositionNed())
          .setVelocity(this.velocity.rpcVelocityNed())
          .build();
      }

      protected static PositionVelocityNed translateFromRpc(TelemetryServerProto.PositionVelocityNed rpcPositionVelocityNed) {
        return new PositionVelocityNed(
                PositionNed.translateFromRpc(rpcPositionVelocityNed.getPosition()),
                VelocityNed.translateFromRpc(rpcPositionVelocityNed.getVelocity()));
      }
    }


    public static class GroundTruth {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;

      public GroundTruth(Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }

      protected TelemetryServerProto.GroundTruth rpcGroundTruth() {
        return TelemetryServerProto.GroundTruth.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .build();
      }

      protected static GroundTruth translateFromRpc(TelemetryServerProto.GroundTruth rpcGroundTruth) {
        return new GroundTruth(
                rpcGroundTruth.getLatitudeDeg(),
                rpcGroundTruth.getLongitudeDeg(),
                rpcGroundTruth.getAbsoluteAltitudeM());
      }
    }


    public static class FixedwingMetrics {
      private Float airspeedMS;
      private Float throttlePercentage;
      private Float climbRateMS;

      public FixedwingMetrics(Float airspeedMS, Float throttlePercentage, Float climbRateMS) {
        this.airspeedMS = airspeedMS;
        this.throttlePercentage = throttlePercentage;
        this.climbRateMS = climbRateMS;
      }
      public Float getAirspeedMS() {
        return airspeedMS;
      }
      public Float getThrottlePercentage() {
        return throttlePercentage;
      }
      public Float getClimbRateMS() {
        return climbRateMS;
      }

      protected TelemetryServerProto.FixedwingMetrics rpcFixedwingMetrics() {
        return TelemetryServerProto.FixedwingMetrics.newBuilder()
          .setAirspeedMS(this.airspeedMS)
          .setThrottlePercentage(this.throttlePercentage)
          .setClimbRateMS(this.climbRateMS)
          .build();
      }

      protected static FixedwingMetrics translateFromRpc(TelemetryServerProto.FixedwingMetrics rpcFixedwingMetrics) {
        return new FixedwingMetrics(
                rpcFixedwingMetrics.getAirspeedMS(),
                rpcFixedwingMetrics.getThrottlePercentage(),
                rpcFixedwingMetrics.getClimbRateMS());
      }
    }


    public static class AccelerationFrd {
      private Float forwardMS2;
      private Float rightMS2;
      private Float downMS2;

      public AccelerationFrd(Float forwardMS2, Float rightMS2, Float downMS2) {
        this.forwardMS2 = forwardMS2;
        this.rightMS2 = rightMS2;
        this.downMS2 = downMS2;
      }
      public Float getForwardMS2() {
        return forwardMS2;
      }
      public Float getRightMS2() {
        return rightMS2;
      }
      public Float getDownMS2() {
        return downMS2;
      }

      protected TelemetryServerProto.AccelerationFrd rpcAccelerationFrd() {
        return TelemetryServerProto.AccelerationFrd.newBuilder()
          .setForwardMS2(this.forwardMS2)
          .setRightMS2(this.rightMS2)
          .setDownMS2(this.downMS2)
          .build();
      }

      protected static AccelerationFrd translateFromRpc(TelemetryServerProto.AccelerationFrd rpcAccelerationFrd) {
        return new AccelerationFrd(
                rpcAccelerationFrd.getForwardMS2(),
                rpcAccelerationFrd.getRightMS2(),
                rpcAccelerationFrd.getDownMS2());
      }
    }


    public static class AngularVelocityFrd {
      private Float forwardRadS;
      private Float rightRadS;
      private Float downRadS;

      public AngularVelocityFrd(Float forwardRadS, Float rightRadS, Float downRadS) {
        this.forwardRadS = forwardRadS;
        this.rightRadS = rightRadS;
        this.downRadS = downRadS;
      }
      public Float getForwardRadS() {
        return forwardRadS;
      }
      public Float getRightRadS() {
        return rightRadS;
      }
      public Float getDownRadS() {
        return downRadS;
      }

      protected TelemetryServerProto.AngularVelocityFrd rpcAngularVelocityFrd() {
        return TelemetryServerProto.AngularVelocityFrd.newBuilder()
          .setForwardRadS(this.forwardRadS)
          .setRightRadS(this.rightRadS)
          .setDownRadS(this.downRadS)
          .build();
      }

      protected static AngularVelocityFrd translateFromRpc(TelemetryServerProto.AngularVelocityFrd rpcAngularVelocityFrd) {
        return new AngularVelocityFrd(
                rpcAngularVelocityFrd.getForwardRadS(),
                rpcAngularVelocityFrd.getRightRadS(),
                rpcAngularVelocityFrd.getDownRadS());
      }
    }


    public static class MagneticFieldFrd {
      private Float forwardGauss;
      private Float rightGauss;
      private Float downGauss;

      public MagneticFieldFrd(Float forwardGauss, Float rightGauss, Float downGauss) {
        this.forwardGauss = forwardGauss;
        this.rightGauss = rightGauss;
        this.downGauss = downGauss;
      }
      public Float getForwardGauss() {
        return forwardGauss;
      }
      public Float getRightGauss() {
        return rightGauss;
      }
      public Float getDownGauss() {
        return downGauss;
      }

      protected TelemetryServerProto.MagneticFieldFrd rpcMagneticFieldFrd() {
        return TelemetryServerProto.MagneticFieldFrd.newBuilder()
          .setForwardGauss(this.forwardGauss)
          .setRightGauss(this.rightGauss)
          .setDownGauss(this.downGauss)
          .build();
      }

      protected static MagneticFieldFrd translateFromRpc(TelemetryServerProto.MagneticFieldFrd rpcMagneticFieldFrd) {
        return new MagneticFieldFrd(
                rpcMagneticFieldFrd.getForwardGauss(),
                rpcMagneticFieldFrd.getRightGauss(),
                rpcMagneticFieldFrd.getDownGauss());
      }
    }


    public static class Imu {
      private AccelerationFrd accelerationFrd;
      private AngularVelocityFrd angularVelocityFrd;
      private MagneticFieldFrd magneticFieldFrd;
      private Float temperatureDegc;
      private Long timestampUs;

      public Imu(AccelerationFrd accelerationFrd, AngularVelocityFrd angularVelocityFrd, MagneticFieldFrd magneticFieldFrd, Float temperatureDegc, Long timestampUs) {
        this.accelerationFrd = accelerationFrd;
        this.angularVelocityFrd = angularVelocityFrd;
        this.magneticFieldFrd = magneticFieldFrd;
        this.temperatureDegc = temperatureDegc;
        this.timestampUs = timestampUs;
      }
      public AccelerationFrd getAccelerationFrd() {
        return accelerationFrd;
      }
      public AngularVelocityFrd getAngularVelocityFrd() {
        return angularVelocityFrd;
      }
      public MagneticFieldFrd getMagneticFieldFrd() {
        return magneticFieldFrd;
      }
      public Float getTemperatureDegc() {
        return temperatureDegc;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }

      protected TelemetryServerProto.Imu rpcImu() {
        return TelemetryServerProto.Imu.newBuilder()
          .setAccelerationFrd(this.accelerationFrd.rpcAccelerationFrd())
          .setAngularVelocityFrd(this.angularVelocityFrd.rpcAngularVelocityFrd())
          .setMagneticFieldFrd(this.magneticFieldFrd.rpcMagneticFieldFrd())
          .setTemperatureDegc(this.temperatureDegc)
          .setTimestampUs(this.timestampUs)
          .build();
      }

      protected static Imu translateFromRpc(TelemetryServerProto.Imu rpcImu) {
        return new Imu(
                AccelerationFrd.translateFromRpc(rpcImu.getAccelerationFrd()),
                AngularVelocityFrd.translateFromRpc(rpcImu.getAngularVelocityFrd()),
                MagneticFieldFrd.translateFromRpc(rpcImu.getMagneticFieldFrd()),
                rpcImu.getTemperatureDegc(),
                rpcImu.getTimestampUs());
      }
    }


    public static class TelemetryServerResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_TIMEOUT;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected TelemetryServerProto.TelemetryServerResult.Result rpcResult() {
              return TelemetryServerProto.TelemetryServerResult.Result.RESULT_UNSUPPORTED;
            }
          };

          protected static Result translateFromRpc(TelemetryServerProto.TelemetryServerResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
            }
          }

          protected abstract TelemetryServerProto.TelemetryServerResult.Result rpcResult();
        }

      public TelemetryServerResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected TelemetryServerProto.TelemetryServerResult rpcTelemetryServerResult() {
        return TelemetryServerProto.TelemetryServerResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static TelemetryServerResult translateFromRpc(TelemetryServerProto.TelemetryServerResult rpcTelemetryServerResult) {
        return new TelemetryServerResult(
                Result.translateFromRpc(rpcTelemetryServerResult.getResult()),
                rpcTelemetryServerResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable publishPosition(@NonNull Position position, @NonNull VelocityNed velocityNed, @NonNull Heading heading) {

      TelemetryServerProto.PublishPositionRequest request = TelemetryServerProto.PublishPositionRequest.newBuilder()
        .setPosition(position.rpcPosition())
        .setVelocityNed(velocityNed.rpcVelocityNed())
        .setHeading(heading.rpcHeading())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishPosition(request, new StreamObserver<TelemetryServerProto.PublishPositionResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishPositionResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishHome(@NonNull Position home) {

      TelemetryServerProto.PublishHomeRequest request = TelemetryServerProto.PublishHomeRequest.newBuilder()
        .setHome(home.rpcPosition())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishHome(request, new StreamObserver<TelemetryServerProto.PublishHomeResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishHomeResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishSysStatus(@NonNull Battery battery, @NonNull Boolean rcReceiverStatus, @NonNull Boolean gyroStatus, @NonNull Boolean accelStatus, @NonNull Boolean magStatus, @NonNull Boolean gpsStatus) {

      TelemetryServerProto.PublishSysStatusRequest request = TelemetryServerProto.PublishSysStatusRequest.newBuilder()
        .setBattery(battery.rpcBattery())
        .setRcReceiverStatus(rcReceiverStatus)
        .setGyroStatus(gyroStatus)
        .setAccelStatus(accelStatus)
        .setMagStatus(magStatus)
        .setGpsStatus(gpsStatus)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishSysStatus(request, new StreamObserver<TelemetryServerProto.PublishSysStatusResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishSysStatusResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishExtendedSysState(@NonNull VtolState vtolState, @NonNull LandedState landedState) {

      TelemetryServerProto.PublishExtendedSysStateRequest request = TelemetryServerProto.PublishExtendedSysStateRequest.newBuilder()
        .setVtolState(vtolState.rpcVtolState())
        .setLandedState(landedState.rpcLandedState())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishExtendedSysState(request, new StreamObserver<TelemetryServerProto.PublishExtendedSysStateResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishExtendedSysStateResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishRawGps(@NonNull RawGps rawGps, @NonNull GpsInfo gpsInfo) {

      TelemetryServerProto.PublishRawGpsRequest request = TelemetryServerProto.PublishRawGpsRequest.newBuilder()
        .setRawGps(rawGps.rpcRawGps())
        .setGpsInfo(gpsInfo.rpcGpsInfo())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishRawGps(request, new StreamObserver<TelemetryServerProto.PublishRawGpsResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishRawGpsResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishBattery(@NonNull Battery battery) {

      TelemetryServerProto.PublishBatteryRequest request = TelemetryServerProto.PublishBatteryRequest.newBuilder()
        .setBattery(battery.rpcBattery())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishBattery(request, new StreamObserver<TelemetryServerProto.PublishBatteryResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishBatteryResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishStatusText(@NonNull StatusText statusText) {

      TelemetryServerProto.PublishStatusTextRequest request = TelemetryServerProto.PublishStatusTextRequest.newBuilder()
        .setStatusText(statusText.rpcStatusText())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishStatusText(request, new StreamObserver<TelemetryServerProto.PublishStatusTextResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishStatusTextResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishOdometry(@NonNull Odometry odometry) {

      TelemetryServerProto.PublishOdometryRequest request = TelemetryServerProto.PublishOdometryRequest.newBuilder()
        .setOdometry(odometry.rpcOdometry())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishOdometry(request, new StreamObserver<TelemetryServerProto.PublishOdometryResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishOdometryResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishPositionVelocityNed(@NonNull PositionVelocityNed positionVelocityNed) {

      TelemetryServerProto.PublishPositionVelocityNedRequest request = TelemetryServerProto.PublishPositionVelocityNedRequest.newBuilder()
        .setPositionVelocityNed(positionVelocityNed.rpcPositionVelocityNed())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishPositionVelocityNed(request, new StreamObserver<TelemetryServerProto.PublishPositionVelocityNedResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishPositionVelocityNedResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishGroundTruth(@NonNull GroundTruth groundTruth) {

      TelemetryServerProto.PublishGroundTruthRequest request = TelemetryServerProto.PublishGroundTruthRequest.newBuilder()
        .setGroundTruth(groundTruth.rpcGroundTruth())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishGroundTruth(request, new StreamObserver<TelemetryServerProto.PublishGroundTruthResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishGroundTruthResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishImu(@NonNull Imu imu) {

      TelemetryServerProto.PublishImuRequest request = TelemetryServerProto.PublishImuRequest.newBuilder()
        .setImu(imu.rpcImu())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishImu(request, new StreamObserver<TelemetryServerProto.PublishImuResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishImuResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishScaledImu(@NonNull Imu imu) {

      TelemetryServerProto.PublishScaledImuRequest request = TelemetryServerProto.PublishScaledImuRequest.newBuilder()
        .setImu(imu.rpcImu())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishScaledImu(request, new StreamObserver<TelemetryServerProto.PublishScaledImuResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishScaledImuResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishRawImu(@NonNull Imu imu) {

      TelemetryServerProto.PublishRawImuRequest request = TelemetryServerProto.PublishRawImuRequest.newBuilder()
        .setImu(imu.rpcImu())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishRawImu(request, new StreamObserver<TelemetryServerProto.PublishRawImuResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishRawImuResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable publishUnixEpochTime(@NonNull Long timeUs) {

      TelemetryServerProto.PublishUnixEpochTimeRequest request = TelemetryServerProto.PublishUnixEpochTimeRequest.newBuilder()
        .setTimeUs(timeUs)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.publishUnixEpochTime(request, new StreamObserver<TelemetryServerProto.PublishUnixEpochTimeResponse>() {

          @Override
          public void onNext(TelemetryServerProto.PublishUnixEpochTimeResponse value) {
            TelemetryServerResult result = TelemetryServerResult.translateFromRpc(value.getTelemetryServerResult());

            if (result.result != TelemetryServerResult.Result.SUCCESS) {
              emitter.onError(new TelemetryServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}