package io.mavsdk.component_information_server;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Provide component information such as parameters.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.42.1)",
    comments = "Source: component_information_server/component_information_server.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ComponentInformationServerServiceGrpc {

  private ComponentInformationServerServiceGrpc() {}

  public static final String SERVICE_NAME = "mavsdk.rpc.component_information_server.ComponentInformationServerService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest,
      io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse> getProvideFloatParamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProvideFloatParam",
      requestType = io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest.class,
      responseType = io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest,
      io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse> getProvideFloatParamMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest, io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse> getProvideFloatParamMethod;
    if ((getProvideFloatParamMethod = ComponentInformationServerServiceGrpc.getProvideFloatParamMethod) == null) {
      synchronized (ComponentInformationServerServiceGrpc.class) {
        if ((getProvideFloatParamMethod = ComponentInformationServerServiceGrpc.getProvideFloatParamMethod) == null) {
          ComponentInformationServerServiceGrpc.getProvideFloatParamMethod = getProvideFloatParamMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest, io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ProvideFloatParam"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getProvideFloatParamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest,
      io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse> getSubscribeFloatParamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SubscribeFloatParam",
      requestType = io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest.class,
      responseType = io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest,
      io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse> getSubscribeFloatParamMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest, io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse> getSubscribeFloatParamMethod;
    if ((getSubscribeFloatParamMethod = ComponentInformationServerServiceGrpc.getSubscribeFloatParamMethod) == null) {
      synchronized (ComponentInformationServerServiceGrpc.class) {
        if ((getSubscribeFloatParamMethod = ComponentInformationServerServiceGrpc.getSubscribeFloatParamMethod) == null) {
          ComponentInformationServerServiceGrpc.getSubscribeFloatParamMethod = getSubscribeFloatParamMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest, io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SubscribeFloatParam"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSubscribeFloatParamMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ComponentInformationServerServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServerServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServerServiceStub>() {
        @java.lang.Override
        public ComponentInformationServerServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ComponentInformationServerServiceStub(channel, callOptions);
        }
      };
    return ComponentInformationServerServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ComponentInformationServerServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServerServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServerServiceBlockingStub>() {
        @java.lang.Override
        public ComponentInformationServerServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ComponentInformationServerServiceBlockingStub(channel, callOptions);
        }
      };
    return ComponentInformationServerServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ComponentInformationServerServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServerServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServerServiceFutureStub>() {
        @java.lang.Override
        public ComponentInformationServerServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ComponentInformationServerServiceFutureStub(channel, callOptions);
        }
      };
    return ComponentInformationServerServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Provide component information such as parameters.
   * </pre>
   */
  public static abstract class ComponentInformationServerServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Provide a param of type float.
     * </pre>
     */
    public void provideFloatParam(io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getProvideFloatParamMethod(), responseObserver);
    }

    /**
     * <pre>
     * Subscribe to float param updates.
     * </pre>
     */
    public void subscribeFloatParam(io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSubscribeFloatParamMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getProvideFloatParamMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest,
                io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse>(
                  this, METHODID_PROVIDE_FLOAT_PARAM)))
          .addMethod(
            getSubscribeFloatParamMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest,
                io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse>(
                  this, METHODID_SUBSCRIBE_FLOAT_PARAM)))
          .build();
    }
  }

  /**
   * <pre>
   * Provide component information such as parameters.
   * </pre>
   */
  public static final class ComponentInformationServerServiceStub extends io.grpc.stub.AbstractAsyncStub<ComponentInformationServerServiceStub> {
    private ComponentInformationServerServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ComponentInformationServerServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ComponentInformationServerServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide a param of type float.
     * </pre>
     */
    public void provideFloatParam(io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getProvideFloatParamMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Subscribe to float param updates.
     * </pre>
     */
    public void subscribeFloatParam(io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getSubscribeFloatParamMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Provide component information such as parameters.
   * </pre>
   */
  public static final class ComponentInformationServerServiceBlockingStub extends io.grpc.stub.AbstractBlockingStub<ComponentInformationServerServiceBlockingStub> {
    private ComponentInformationServerServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ComponentInformationServerServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ComponentInformationServerServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide a param of type float.
     * </pre>
     */
    public io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse provideFloatParam(io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getProvideFloatParamMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Subscribe to float param updates.
     * </pre>
     */
    public java.util.Iterator<io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse> subscribeFloatParam(
        io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getSubscribeFloatParamMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Provide component information such as parameters.
   * </pre>
   */
  public static final class ComponentInformationServerServiceFutureStub extends io.grpc.stub.AbstractFutureStub<ComponentInformationServerServiceFutureStub> {
    private ComponentInformationServerServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ComponentInformationServerServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ComponentInformationServerServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide a param of type float.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse> provideFloatParam(
        io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getProvideFloatParamMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_PROVIDE_FLOAT_PARAM = 0;
  private static final int METHODID_SUBSCRIBE_FLOAT_PARAM = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ComponentInformationServerServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ComponentInformationServerServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_PROVIDE_FLOAT_PARAM:
          serviceImpl.provideFloatParam((io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.component_information_server.ComponentInformationServerProto.ProvideFloatParamResponse>) responseObserver);
          break;
        case METHODID_SUBSCRIBE_FLOAT_PARAM:
          serviceImpl.subscribeFloatParam((io.mavsdk.component_information_server.ComponentInformationServerProto.SubscribeFloatParamRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.component_information_server.ComponentInformationServerProto.FloatParamResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ComponentInformationServerServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .addMethod(getProvideFloatParamMethod())
              .addMethod(getSubscribeFloatParamMethod())
              .build();
        }
      }
    }
    return result;
  }
}
