package io.mavsdk.component_information_server;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ComponentInformationServer implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(ComponentInformationServer.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ComponentInformationServerServiceGrpc.ComponentInformationServerServiceStub stub;

  private volatile boolean isInitialized = false;

  public ComponentInformationServer(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public ComponentInformationServer() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ComponentInformationServerServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ComponentInformationServerException extends MavsdkException {
    private ComponentInformationServerResult.Result code;
    private String description;

    public ComponentInformationServerException(ComponentInformationServerResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ComponentInformationServerResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class FloatParam {
      private String name;
      private String shortDescription;
      private String longDescription;
      private String unit;
      private Integer decimalPlaces;
      private Float startValue;
      private Float defaultValue;
      private Float minValue;
      private Float maxValue;

      public FloatParam(String name, String shortDescription, String longDescription, String unit, Integer decimalPlaces, Float startValue, Float defaultValue, Float minValue, Float maxValue) {
        this.name = name;
        this.shortDescription = shortDescription;
        this.longDescription = longDescription;
        this.unit = unit;
        this.decimalPlaces = decimalPlaces;
        this.startValue = startValue;
        this.defaultValue = defaultValue;
        this.minValue = minValue;
        this.maxValue = maxValue;
      }
      public String getName() {
        return name;
      }
      public String getShortDescription() {
        return shortDescription;
      }
      public String getLongDescription() {
        return longDescription;
      }
      public String getUnit() {
        return unit;
      }
      public Integer getDecimalPlaces() {
        return decimalPlaces;
      }
      public Float getStartValue() {
        return startValue;
      }
      public Float getDefaultValue() {
        return defaultValue;
      }
      public Float getMinValue() {
        return minValue;
      }
      public Float getMaxValue() {
        return maxValue;
      }

      protected ComponentInformationServerProto.FloatParam rpcFloatParam() {
        return ComponentInformationServerProto.FloatParam.newBuilder()
          .setName(this.name)
          .setShortDescription(this.shortDescription)
          .setLongDescription(this.longDescription)
          .setUnit(this.unit)
          .setDecimalPlaces(this.decimalPlaces)
          .setStartValue(this.startValue)
          .setDefaultValue(this.defaultValue)
          .setMinValue(this.minValue)
          .setMaxValue(this.maxValue)
          .build();
      }

      protected static FloatParam translateFromRpc(ComponentInformationServerProto.FloatParam rpcFloatParam) {
        return new FloatParam(
                rpcFloatParam.getName(),
                rpcFloatParam.getShortDescription(),
                rpcFloatParam.getLongDescription(),
                rpcFloatParam.getUnit(),
                rpcFloatParam.getDecimalPlaces(),
                rpcFloatParam.getStartValue(),
                rpcFloatParam.getDefaultValue(),
                rpcFloatParam.getMinValue(),
                rpcFloatParam.getMaxValue());
      }
    }


    public static class FloatParamUpdate {
      private String name;
      private Float value;

      public FloatParamUpdate(String name, Float value) {
        this.name = name;
        this.value = value;
      }
      public String getName() {
        return name;
      }
      public Float getValue() {
        return value;
      }

      protected ComponentInformationServerProto.FloatParamUpdate rpcFloatParamUpdate() {
        return ComponentInformationServerProto.FloatParamUpdate.newBuilder()
          .setName(this.name)
          .setValue(this.value)
          .build();
      }

      protected static FloatParamUpdate translateFromRpc(ComponentInformationServerProto.FloatParamUpdate rpcFloatParamUpdate) {
        return new FloatParamUpdate(
                rpcFloatParamUpdate.getName(),
                rpcFloatParamUpdate.getValue());
      }
    }


    public static class ComponentInformationServerResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_SUCCESS;
            }
          }, 
          DUPLICATE_PARAM {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_DUPLICATE_PARAM;
            }
          }, 
          INVALID_PARAM_START_VALUE {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_INVALID_PARAM_START_VALUE;
            }
          }, 
          INVALID_PARAM_DEFAULT_VALUE {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_INVALID_PARAM_DEFAULT_VALUE;
            }
          }, 
          INVALID_PARAM_NAME {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_INVALID_PARAM_NAME;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult() {
              return ComponentInformationServerProto.ComponentInformationServerResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_DUPLICATE_PARAM: 
                return Result.DUPLICATE_PARAM;
              case RESULT_INVALID_PARAM_START_VALUE: 
                return Result.INVALID_PARAM_START_VALUE;
              case RESULT_INVALID_PARAM_DEFAULT_VALUE: 
                return Result.INVALID_PARAM_DEFAULT_VALUE;
              case RESULT_INVALID_PARAM_NAME: 
                return Result.INVALID_PARAM_NAME;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract ComponentInformationServerProto.ComponentInformationServerResult.Result rpcResult();
        }

      public ComponentInformationServerResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ComponentInformationServerProto.ComponentInformationServerResult rpcComponentInformationServerResult() {
        return ComponentInformationServerProto.ComponentInformationServerResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ComponentInformationServerResult translateFromRpc(ComponentInformationServerProto.ComponentInformationServerResult rpcComponentInformationServerResult) {
        return new ComponentInformationServerResult(
                Result.translateFromRpc(rpcComponentInformationServerResult.getResult()),
                rpcComponentInformationServerResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable provideFloatParam(@NonNull FloatParam param) {

      ComponentInformationServerProto.ProvideFloatParamRequest request = ComponentInformationServerProto.ProvideFloatParamRequest.newBuilder()
        .setParam(param.rpcFloatParam())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.provideFloatParam(request, new StreamObserver<ComponentInformationServerProto.ProvideFloatParamResponse>() {

          @Override
          public void onNext(ComponentInformationServerProto.ProvideFloatParamResponse value) {
            ComponentInformationServerResult result = ComponentInformationServerResult.translateFromRpc(value.getComponentInformationServerResult());

            if (result.result != ComponentInformationServerResult.Result.SUCCESS) {
              emitter.onError(new ComponentInformationServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<ComponentInformationServer.FloatParamUpdate> floatParamProcessor = PublishProcessor.create();
    private final Flowable<ComponentInformationServer.FloatParamUpdate> floatParam = floatParamProcessor.onBackpressureBuffer().share();;
    private volatile boolean isFloatParamInitialized = false;

    private void processFloatParam() {
      ComponentInformationServerProto.SubscribeFloatParamRequest request = ComponentInformationServerProto.SubscribeFloatParamRequest.newBuilder()
        .build();

      stub.subscribeFloatParam(request, new StreamObserver<ComponentInformationServerProto.FloatParamResponse>() {

        @Override
        public void onNext(ComponentInformationServerProto.FloatParamResponse value) {
          floatParamProcessor.onNext(FloatParamUpdate.translateFromRpc(value.getParamUpdate()));
        }

        @Override
        public void onError(Throwable t) {
          floatParamProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          floatParamProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<ComponentInformationServer.FloatParamUpdate> getFloatParam() {
      if (!isFloatParamInitialized) {
        synchronized (this) {
          if (!isFloatParamInitialized) {
            MavsdkEventQueue.executor().execute(() -> processFloatParam());
            isFloatParamInitialized = true;
          }
        }
      }
      return floatParam;
    }


}