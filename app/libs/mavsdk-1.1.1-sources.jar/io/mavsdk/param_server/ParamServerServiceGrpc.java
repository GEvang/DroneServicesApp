package io.mavsdk.param_server;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Provide raw access to retrieve and provide server parameters.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.42.1)",
    comments = "Source: param_server/param_server.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ParamServerServiceGrpc {

  private ParamServerServiceGrpc() {}

  public static final String SERVICE_NAME = "mavsdk.rpc.param_server.ParamServerService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest,
      io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse> getRetrieveParamIntMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RetrieveParamInt",
      requestType = io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest.class,
      responseType = io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest,
      io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse> getRetrieveParamIntMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest, io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse> getRetrieveParamIntMethod;
    if ((getRetrieveParamIntMethod = ParamServerServiceGrpc.getRetrieveParamIntMethod) == null) {
      synchronized (ParamServerServiceGrpc.class) {
        if ((getRetrieveParamIntMethod = ParamServerServiceGrpc.getRetrieveParamIntMethod) == null) {
          ParamServerServiceGrpc.getRetrieveParamIntMethod = getRetrieveParamIntMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest, io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RetrieveParamInt"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRetrieveParamIntMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest,
      io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse> getProvideParamIntMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProvideParamInt",
      requestType = io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest.class,
      responseType = io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest,
      io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse> getProvideParamIntMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest, io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse> getProvideParamIntMethod;
    if ((getProvideParamIntMethod = ParamServerServiceGrpc.getProvideParamIntMethod) == null) {
      synchronized (ParamServerServiceGrpc.class) {
        if ((getProvideParamIntMethod = ParamServerServiceGrpc.getProvideParamIntMethod) == null) {
          ParamServerServiceGrpc.getProvideParamIntMethod = getProvideParamIntMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest, io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ProvideParamInt"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getProvideParamIntMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest,
      io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse> getRetrieveParamFloatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RetrieveParamFloat",
      requestType = io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest.class,
      responseType = io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest,
      io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse> getRetrieveParamFloatMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest, io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse> getRetrieveParamFloatMethod;
    if ((getRetrieveParamFloatMethod = ParamServerServiceGrpc.getRetrieveParamFloatMethod) == null) {
      synchronized (ParamServerServiceGrpc.class) {
        if ((getRetrieveParamFloatMethod = ParamServerServiceGrpc.getRetrieveParamFloatMethod) == null) {
          ParamServerServiceGrpc.getRetrieveParamFloatMethod = getRetrieveParamFloatMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest, io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RetrieveParamFloat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRetrieveParamFloatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest,
      io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse> getProvideParamFloatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProvideParamFloat",
      requestType = io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest.class,
      responseType = io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest,
      io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse> getProvideParamFloatMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest, io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse> getProvideParamFloatMethod;
    if ((getProvideParamFloatMethod = ParamServerServiceGrpc.getProvideParamFloatMethod) == null) {
      synchronized (ParamServerServiceGrpc.class) {
        if ((getProvideParamFloatMethod = ParamServerServiceGrpc.getProvideParamFloatMethod) == null) {
          ParamServerServiceGrpc.getProvideParamFloatMethod = getProvideParamFloatMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest, io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ProvideParamFloat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getProvideParamFloatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest,
      io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse> getRetrieveAllParamsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RetrieveAllParams",
      requestType = io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest.class,
      responseType = io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest,
      io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse> getRetrieveAllParamsMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest, io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse> getRetrieveAllParamsMethod;
    if ((getRetrieveAllParamsMethod = ParamServerServiceGrpc.getRetrieveAllParamsMethod) == null) {
      synchronized (ParamServerServiceGrpc.class) {
        if ((getRetrieveAllParamsMethod = ParamServerServiceGrpc.getRetrieveAllParamsMethod) == null) {
          ParamServerServiceGrpc.getRetrieveAllParamsMethod = getRetrieveAllParamsMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest, io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RetrieveAllParams"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRetrieveAllParamsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ParamServerServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ParamServerServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ParamServerServiceStub>() {
        @java.lang.Override
        public ParamServerServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ParamServerServiceStub(channel, callOptions);
        }
      };
    return ParamServerServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ParamServerServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ParamServerServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ParamServerServiceBlockingStub>() {
        @java.lang.Override
        public ParamServerServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ParamServerServiceBlockingStub(channel, callOptions);
        }
      };
    return ParamServerServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ParamServerServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ParamServerServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ParamServerServiceFutureStub>() {
        @java.lang.Override
        public ParamServerServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ParamServerServiceFutureStub(channel, callOptions);
        }
      };
    return ParamServerServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Provide raw access to retrieve and provide server parameters.
   * </pre>
   */
  public static abstract class ParamServerServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Retrieve an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void retrieveParamInt(io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRetrieveParamIntMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void provideParamInt(io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getProvideParamIntMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieve a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void retrieveParamFloat(io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRetrieveParamFloatMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void provideParamFloat(io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getProvideParamFloatMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieve all parameters.
     * </pre>
     */
    public void retrieveAllParams(io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRetrieveAllParamsMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getRetrieveParamIntMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest,
                io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse>(
                  this, METHODID_RETRIEVE_PARAM_INT)))
          .addMethod(
            getProvideParamIntMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest,
                io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse>(
                  this, METHODID_PROVIDE_PARAM_INT)))
          .addMethod(
            getRetrieveParamFloatMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest,
                io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse>(
                  this, METHODID_RETRIEVE_PARAM_FLOAT)))
          .addMethod(
            getProvideParamFloatMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest,
                io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse>(
                  this, METHODID_PROVIDE_PARAM_FLOAT)))
          .addMethod(
            getRetrieveAllParamsMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest,
                io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse>(
                  this, METHODID_RETRIEVE_ALL_PARAMS)))
          .build();
    }
  }

  /**
   * <pre>
   * Provide raw access to retrieve and provide server parameters.
   * </pre>
   */
  public static final class ParamServerServiceStub extends io.grpc.stub.AbstractAsyncStub<ParamServerServiceStub> {
    private ParamServerServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ParamServerServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ParamServerServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Retrieve an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void retrieveParamInt(io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRetrieveParamIntMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void provideParamInt(io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getProvideParamIntMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieve a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void retrieveParamFloat(io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRetrieveParamFloatMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public void provideParamFloat(io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getProvideParamFloatMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieve all parameters.
     * </pre>
     */
    public void retrieveAllParams(io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRetrieveAllParamsMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Provide raw access to retrieve and provide server parameters.
   * </pre>
   */
  public static final class ParamServerServiceBlockingStub extends io.grpc.stub.AbstractBlockingStub<ParamServerServiceBlockingStub> {
    private ParamServerServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ParamServerServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ParamServerServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Retrieve an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse retrieveParamInt(io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRetrieveParamIntMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse provideParamInt(io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getProvideParamIntMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieve a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse retrieveParamFloat(io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRetrieveParamFloatMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse provideParamFloat(io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getProvideParamFloatMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieve all parameters.
     * </pre>
     */
    public io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse retrieveAllParams(io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRetrieveAllParamsMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Provide raw access to retrieve and provide server parameters.
   * </pre>
   */
  public static final class ParamServerServiceFutureStub extends io.grpc.stub.AbstractFutureStub<ParamServerServiceFutureStub> {
    private ParamServerServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ParamServerServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ParamServerServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Retrieve an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse> retrieveParamInt(
        io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRetrieveParamIntMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide an int parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse> provideParamInt(
        io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getProvideParamIntMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieve a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse> retrieveParamFloat(
        io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRetrieveParamFloatMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide a float parameter.
     * If the type is wrong, the result will be `WRONG_TYPE`.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse> provideParamFloat(
        io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getProvideParamFloatMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieve all parameters.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse> retrieveAllParams(
        io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRetrieveAllParamsMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_RETRIEVE_PARAM_INT = 0;
  private static final int METHODID_PROVIDE_PARAM_INT = 1;
  private static final int METHODID_RETRIEVE_PARAM_FLOAT = 2;
  private static final int METHODID_PROVIDE_PARAM_FLOAT = 3;
  private static final int METHODID_RETRIEVE_ALL_PARAMS = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ParamServerServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ParamServerServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_RETRIEVE_PARAM_INT:
          serviceImpl.retrieveParamInt((io.mavsdk.param_server.ParamServerProto.RetrieveParamIntRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveParamIntResponse>) responseObserver);
          break;
        case METHODID_PROVIDE_PARAM_INT:
          serviceImpl.provideParamInt((io.mavsdk.param_server.ParamServerProto.ProvideParamIntRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.ProvideParamIntResponse>) responseObserver);
          break;
        case METHODID_RETRIEVE_PARAM_FLOAT:
          serviceImpl.retrieveParamFloat((io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveParamFloatResponse>) responseObserver);
          break;
        case METHODID_PROVIDE_PARAM_FLOAT:
          serviceImpl.provideParamFloat((io.mavsdk.param_server.ParamServerProto.ProvideParamFloatRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.ProvideParamFloatResponse>) responseObserver);
          break;
        case METHODID_RETRIEVE_ALL_PARAMS:
          serviceImpl.retrieveAllParams((io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.param_server.ParamServerProto.RetrieveAllParamsResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ParamServerServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .addMethod(getRetrieveParamIntMethod())
              .addMethod(getProvideParamIntMethod())
              .addMethod(getRetrieveParamFloatMethod())
              .addMethod(getProvideParamFloatMethod())
              .addMethod(getRetrieveAllParamsMethod())
              .build();
        }
      }
    }
    return result;
  }
}
