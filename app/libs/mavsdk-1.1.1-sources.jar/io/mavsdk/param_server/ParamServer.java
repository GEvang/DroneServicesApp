package io.mavsdk.param_server;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParamServer implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(ParamServer.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ParamServerServiceGrpc.ParamServerServiceStub stub;

  private volatile boolean isInitialized = false;

  public ParamServer(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public ParamServer() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ParamServerServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ParamServerException extends MavsdkException {
    private ParamServerResult.Result code;
    private String description;

    public ParamServerException(ParamServerResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ParamServerResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class IntParam {
      private String name;
      private Integer value;

      public IntParam(String name, Integer value) {
        this.name = name;
        this.value = value;
      }
      public String getName() {
        return name;
      }
      public Integer getValue() {
        return value;
      }

      protected ParamServerProto.IntParam rpcIntParam() {
        return ParamServerProto.IntParam.newBuilder()
          .setName(this.name)
          .setValue(this.value)
          .build();
      }

      protected static IntParam translateFromRpc(ParamServerProto.IntParam rpcIntParam) {
        return new IntParam(
                rpcIntParam.getName(),
                rpcIntParam.getValue());
      }
    }


    public static class FloatParam {
      private String name;
      private Float value;

      public FloatParam(String name, Float value) {
        this.name = name;
        this.value = value;
      }
      public String getName() {
        return name;
      }
      public Float getValue() {
        return value;
      }

      protected ParamServerProto.FloatParam rpcFloatParam() {
        return ParamServerProto.FloatParam.newBuilder()
          .setName(this.name)
          .setValue(this.value)
          .build();
      }

      protected static FloatParam translateFromRpc(ParamServerProto.FloatParam rpcFloatParam) {
        return new FloatParam(
                rpcFloatParam.getName(),
                rpcFloatParam.getValue());
      }
    }


    public static class AllParams {
      private List<IntParam> intParams;
      private List<FloatParam> floatParams;

      public AllParams(List<IntParam> intParams, List<FloatParam> floatParams) {
        this.intParams = intParams;
        this.floatParams = floatParams;
      }
      public List<IntParam> getIntParams() {
        return intParams;
      }
      public List<FloatParam> getFloatParams() {
        return floatParams;
      }

      protected ParamServerProto.AllParams rpcAllParams() {
        return ParamServerProto.AllParams.newBuilder()
          .addAllIntParams(intParams.stream().map(IntParam::rpcIntParam).collect(Collectors.toList()))
          .addAllFloatParams(floatParams.stream().map(FloatParam::rpcFloatParam).collect(Collectors.toList()))
          .build();
      }

      protected static AllParams translateFromRpc(ParamServerProto.AllParams rpcAllParams) {
        return new AllParams(
                    rpcAllParams.getIntParamsList().stream().map(IntParam::translateFromRpc).collect(Collectors.toList()),
                    rpcAllParams.getFloatParamsList().stream().map(FloatParam::translateFromRpc).collect(Collectors.toList()));
      }
    }


    public static class ParamServerResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ParamServerProto.ParamServerResult.Result rpcResult() {
              return ParamServerProto.ParamServerResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ParamServerProto.ParamServerResult.Result rpcResult() {
              return ParamServerProto.ParamServerResult.Result.RESULT_SUCCESS;
            }
          }, 
          NOT_FOUND {
            @Override
            protected ParamServerProto.ParamServerResult.Result rpcResult() {
              return ParamServerProto.ParamServerResult.Result.RESULT_NOT_FOUND;
            }
          }, 
          WRONG_TYPE {
            @Override
            protected ParamServerProto.ParamServerResult.Result rpcResult() {
              return ParamServerProto.ParamServerResult.Result.RESULT_WRONG_TYPE;
            }
          }, 
          PARAM_NAME_TOO_LONG {
            @Override
            protected ParamServerProto.ParamServerResult.Result rpcResult() {
              return ParamServerProto.ParamServerResult.Result.RESULT_PARAM_NAME_TOO_LONG;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ParamServerProto.ParamServerResult.Result rpcResult() {
              return ParamServerProto.ParamServerResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(ParamServerProto.ParamServerResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NOT_FOUND: 
                return Result.NOT_FOUND;
              case RESULT_WRONG_TYPE: 
                return Result.WRONG_TYPE;
              case RESULT_PARAM_NAME_TOO_LONG: 
                return Result.PARAM_NAME_TOO_LONG;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract ParamServerProto.ParamServerResult.Result rpcResult();
        }

      public ParamServerResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ParamServerProto.ParamServerResult rpcParamServerResult() {
        return ParamServerProto.ParamServerResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ParamServerResult translateFromRpc(ParamServerProto.ParamServerResult rpcParamServerResult) {
        return new ParamServerResult(
                Result.translateFromRpc(rpcParamServerResult.getResult()),
                rpcParamServerResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Single<Integer> retrieveParamInt(@NonNull String name) {
      ParamServerProto.RetrieveParamIntRequest request = ParamServerProto.RetrieveParamIntRequest.newBuilder()
        .setName(name)
        .build();

      Single<Integer> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.retrieveParamInt(request, new StreamObserver<ParamServerProto.RetrieveParamIntResponse>() {

          @Override
          public void onNext(ParamServerProto.RetrieveParamIntResponse value) {
            ParamServerResult result = ParamServerResult.translateFromRpc(value.getParamServerResult());

            if (result.result != ParamServerResult.Result.SUCCESS) {
              emitter.onError(new ParamServerException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getValue());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable provideParamInt(@NonNull String name, @NonNull Integer value) {

      ParamServerProto.ProvideParamIntRequest request = ParamServerProto.ProvideParamIntRequest.newBuilder()
        .setName(name)
        .setValue(value)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.provideParamInt(request, new StreamObserver<ParamServerProto.ProvideParamIntResponse>() {

          @Override
          public void onNext(ParamServerProto.ProvideParamIntResponse value) {
            ParamServerResult result = ParamServerResult.translateFromRpc(value.getParamServerResult());

            if (result.result != ParamServerResult.Result.SUCCESS) {
              emitter.onError(new ParamServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Float> retrieveParamFloat(@NonNull String name) {
      ParamServerProto.RetrieveParamFloatRequest request = ParamServerProto.RetrieveParamFloatRequest.newBuilder()
        .setName(name)
        .build();

      Single<Float> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.retrieveParamFloat(request, new StreamObserver<ParamServerProto.RetrieveParamFloatResponse>() {

          @Override
          public void onNext(ParamServerProto.RetrieveParamFloatResponse value) {
            ParamServerResult result = ParamServerResult.translateFromRpc(value.getParamServerResult());

            if (result.result != ParamServerResult.Result.SUCCESS) {
              emitter.onError(new ParamServerException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getValue());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable provideParamFloat(@NonNull String name, @NonNull Float value) {

      ParamServerProto.ProvideParamFloatRequest request = ParamServerProto.ProvideParamFloatRequest.newBuilder()
        .setName(name)
        .setValue(value)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.provideParamFloat(request, new StreamObserver<ParamServerProto.ProvideParamFloatResponse>() {

          @Override
          public void onNext(ParamServerProto.ProvideParamFloatResponse value) {
            ParamServerResult result = ParamServerResult.translateFromRpc(value.getParamServerResult());

            if (result.result != ParamServerResult.Result.SUCCESS) {
              emitter.onError(new ParamServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<ParamServer.AllParams> retrieveAllParams() {
      ParamServerProto.RetrieveAllParamsRequest request = ParamServerProto.RetrieveAllParamsRequest.newBuilder()
        .build();

      Single<ParamServer.AllParams> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.retrieveAllParams(request, new StreamObserver<ParamServerProto.RetrieveAllParamsResponse>() {

          @Override
          public void onNext(ParamServerProto.RetrieveAllParamsResponse value) {
              emitter.onSuccess(AllParams.translateFromRpc(value.getParams()));
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}