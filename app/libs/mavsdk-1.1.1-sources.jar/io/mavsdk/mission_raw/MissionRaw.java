package io.mavsdk.mission_raw;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MissionRaw implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(MissionRaw.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private MissionRawServiceGrpc.MissionRawServiceStub stub;

  private volatile boolean isInitialized = false;

  public MissionRaw(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public MissionRaw() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = MissionRawServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class MissionRawException extends MavsdkException {
    private MissionRawResult.Result code;
    private String description;

    public MissionRawException(MissionRawResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public MissionRawResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class MissionProgress {
      private Integer current;
      private Integer total;

      public MissionProgress(Integer current, Integer total) {
        this.current = current;
        this.total = total;
      }
      public Integer getCurrent() {
        return current;
      }
      public Integer getTotal() {
        return total;
      }

      protected MissionRawProto.MissionProgress rpcMissionProgress() {
        return MissionRawProto.MissionProgress.newBuilder()
          .setCurrent(this.current)
          .setTotal(this.total)
          .build();
      }

      protected static MissionProgress translateFromRpc(MissionRawProto.MissionProgress rpcMissionProgress) {
        return new MissionProgress(
                rpcMissionProgress.getCurrent(),
                rpcMissionProgress.getTotal());
      }
    }


    public static class MissionItem {
      private Integer seq;
      private Integer frame;
      private Integer command;
      private Integer current;
      private Integer autocontinue;
      private Float param1;
      private Float param2;
      private Float param3;
      private Float param4;
      private Integer x;
      private Integer y;
      private Float z;
      private Integer missionType;

      public MissionItem(Integer seq, Integer frame, Integer command, Integer current, Integer autocontinue, Float param1, Float param2, Float param3, Float param4, Integer x, Integer y, Float z, Integer missionType) {
        this.seq = seq;
        this.frame = frame;
        this.command = command;
        this.current = current;
        this.autocontinue = autocontinue;
        this.param1 = param1;
        this.param2 = param2;
        this.param3 = param3;
        this.param4 = param4;
        this.x = x;
        this.y = y;
        this.z = z;
        this.missionType = missionType;
      }
      public Integer getSeq() {
        return seq;
      }
      public Integer getFrame() {
        return frame;
      }
      public Integer getCommand() {
        return command;
      }
      public Integer getCurrent() {
        return current;
      }
      public Integer getAutocontinue() {
        return autocontinue;
      }
      public Float getParam1() {
        return param1;
      }
      public Float getParam2() {
        return param2;
      }
      public Float getParam3() {
        return param3;
      }
      public Float getParam4() {
        return param4;
      }
      public Integer getX() {
        return x;
      }
      public Integer getY() {
        return y;
      }
      public Float getZ() {
        return z;
      }
      public Integer getMissionType() {
        return missionType;
      }

      protected MissionRawProto.MissionItem rpcMissionItem() {
        return MissionRawProto.MissionItem.newBuilder()
          .setSeq(this.seq)
          .setFrame(this.frame)
          .setCommand(this.command)
          .setCurrent(this.current)
          .setAutocontinue(this.autocontinue)
          .setParam1(this.param1)
          .setParam2(this.param2)
          .setParam3(this.param3)
          .setParam4(this.param4)
          .setX(this.x)
          .setY(this.y)
          .setZ(this.z)
          .setMissionType(this.missionType)
          .build();
      }

      protected static MissionItem translateFromRpc(MissionRawProto.MissionItem rpcMissionItem) {
        return new MissionItem(
                rpcMissionItem.getSeq(),
                rpcMissionItem.getFrame(),
                rpcMissionItem.getCommand(),
                rpcMissionItem.getCurrent(),
                rpcMissionItem.getAutocontinue(),
                rpcMissionItem.getParam1(),
                rpcMissionItem.getParam2(),
                rpcMissionItem.getParam3(),
                rpcMissionItem.getParam4(),
                rpcMissionItem.getX(),
                rpcMissionItem.getY(),
                rpcMissionItem.getZ(),
                rpcMissionItem.getMissionType());
      }
    }


    public static class MissionImportData {
      private List<MissionItem> missionItems;
      private List<MissionItem> geofenceItems;
      private List<MissionItem> rallyItems;

      public MissionImportData(List<MissionItem> missionItems, List<MissionItem> geofenceItems, List<MissionItem> rallyItems) {
        this.missionItems = missionItems;
        this.geofenceItems = geofenceItems;
        this.rallyItems = rallyItems;
      }
      public List<MissionItem> getMissionItems() {
        return missionItems;
      }
      public List<MissionItem> getGeofenceItems() {
        return geofenceItems;
      }
      public List<MissionItem> getRallyItems() {
        return rallyItems;
      }

      protected MissionRawProto.MissionImportData rpcMissionImportData() {
        return MissionRawProto.MissionImportData.newBuilder()
          .addAllMissionItems(missionItems.stream().map(MissionItem::rpcMissionItem).collect(Collectors.toList()))
          .addAllGeofenceItems(geofenceItems.stream().map(MissionItem::rpcMissionItem).collect(Collectors.toList()))
          .addAllRallyItems(rallyItems.stream().map(MissionItem::rpcMissionItem).collect(Collectors.toList()))
          .build();
      }

      protected static MissionImportData translateFromRpc(MissionRawProto.MissionImportData rpcMissionImportData) {
        return new MissionImportData(
                    rpcMissionImportData.getMissionItemsList().stream().map(MissionItem::translateFromRpc).collect(Collectors.toList()),
                    rpcMissionImportData.getGeofenceItemsList().stream().map(MissionItem::translateFromRpc).collect(Collectors.toList()),
                    rpcMissionImportData.getRallyItemsList().stream().map(MissionItem::translateFromRpc).collect(Collectors.toList()));
      }
    }


    public static class MissionRawResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_SUCCESS;
            }
          }, 
          ERROR {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_ERROR;
            }
          }, 
          TOO_MANY_MISSION_ITEMS {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_TOO_MANY_MISSION_ITEMS;
            }
          }, 
          BUSY {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_BUSY;
            }
          }, 
          TIMEOUT {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_TIMEOUT;
            }
          }, 
          INVALID_ARGUMENT {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_INVALID_ARGUMENT;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_UNSUPPORTED;
            }
          }, 
          NO_MISSION_AVAILABLE {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_NO_MISSION_AVAILABLE;
            }
          }, 
          TRANSFER_CANCELLED {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_TRANSFER_CANCELLED;
            }
          }, 
          FAILED_TO_OPEN_QGC_PLAN {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_FAILED_TO_OPEN_QGC_PLAN;
            }
          }, 
          FAILED_TO_PARSE_QGC_PLAN {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_FAILED_TO_PARSE_QGC_PLAN;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected MissionRawProto.MissionRawResult.Result rpcResult() {
              return MissionRawProto.MissionRawResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(MissionRawProto.MissionRawResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_TOO_MANY_MISSION_ITEMS: 
                return Result.TOO_MANY_MISSION_ITEMS;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_INVALID_ARGUMENT: 
                return Result.INVALID_ARGUMENT;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
              case RESULT_NO_MISSION_AVAILABLE: 
                return Result.NO_MISSION_AVAILABLE;
              case RESULT_TRANSFER_CANCELLED: 
                return Result.TRANSFER_CANCELLED;
              case RESULT_FAILED_TO_OPEN_QGC_PLAN: 
                return Result.FAILED_TO_OPEN_QGC_PLAN;
              case RESULT_FAILED_TO_PARSE_QGC_PLAN: 
                return Result.FAILED_TO_PARSE_QGC_PLAN;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract MissionRawProto.MissionRawResult.Result rpcResult();
        }

      public MissionRawResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected MissionRawProto.MissionRawResult rpcMissionRawResult() {
        return MissionRawProto.MissionRawResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static MissionRawResult translateFromRpc(MissionRawProto.MissionRawResult rpcMissionRawResult) {
        return new MissionRawResult(
                Result.translateFromRpc(rpcMissionRawResult.getResult()),
                rpcMissionRawResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable uploadMission(@NonNull List<MissionItem> missionItems) {

      MissionRawProto.UploadMissionRequest request = MissionRawProto.UploadMissionRequest.newBuilder()
        .addAllMissionItems(missionItems.stream().map(elem -> elem.rpcMissionItem())::iterator)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.uploadMission(request, new StreamObserver<MissionRawProto.UploadMissionResponse>() {

          @Override
          public void onNext(MissionRawProto.UploadMissionResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable cancelMissionUpload() {

      MissionRawProto.CancelMissionUploadRequest request = MissionRawProto.CancelMissionUploadRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.cancelMissionUpload(request, new StreamObserver<MissionRawProto.CancelMissionUploadResponse>() {

          @Override
          public void onNext(MissionRawProto.CancelMissionUploadResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<List<MissionRaw.MissionItem>> downloadMission() {
      MissionRawProto.DownloadMissionRequest request = MissionRawProto.DownloadMissionRequest.newBuilder()
        .build();

      Single<List<MissionRaw.MissionItem>> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.downloadMission(request, new StreamObserver<MissionRawProto.DownloadMissionResponse>() {

          @Override
          public void onNext(MissionRawProto.DownloadMissionResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getMissionItemsList().stream().map(MissionItem::translateFromRpc).collect(Collectors.toList()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable cancelMissionDownload() {

      MissionRawProto.CancelMissionDownloadRequest request = MissionRawProto.CancelMissionDownloadRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.cancelMissionDownload(request, new StreamObserver<MissionRawProto.CancelMissionDownloadResponse>() {

          @Override
          public void onNext(MissionRawProto.CancelMissionDownloadResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable startMission() {

      MissionRawProto.StartMissionRequest request = MissionRawProto.StartMissionRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startMission(request, new StreamObserver<MissionRawProto.StartMissionResponse>() {

          @Override
          public void onNext(MissionRawProto.StartMissionResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable pauseMission() {

      MissionRawProto.PauseMissionRequest request = MissionRawProto.PauseMissionRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.pauseMission(request, new StreamObserver<MissionRawProto.PauseMissionResponse>() {

          @Override
          public void onNext(MissionRawProto.PauseMissionResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable clearMission() {

      MissionRawProto.ClearMissionRequest request = MissionRawProto.ClearMissionRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.clearMission(request, new StreamObserver<MissionRawProto.ClearMissionResponse>() {

          @Override
          public void onNext(MissionRawProto.ClearMissionResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setCurrentMissionItem(@NonNull Integer index) {

      MissionRawProto.SetCurrentMissionItemRequest request = MissionRawProto.SetCurrentMissionItemRequest.newBuilder()
        .setIndex(index)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setCurrentMissionItem(request, new StreamObserver<MissionRawProto.SetCurrentMissionItemResponse>() {

          @Override
          public void onNext(MissionRawProto.SetCurrentMissionItemResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<MissionRaw.MissionProgress> missionProgressProcessor = PublishProcessor.create();
    private final Flowable<MissionRaw.MissionProgress> missionProgress = missionProgressProcessor.onBackpressureBuffer().share();;
    private volatile boolean isMissionProgressInitialized = false;

    private void processMissionProgress() {
      MissionRawProto.SubscribeMissionProgressRequest request = MissionRawProto.SubscribeMissionProgressRequest.newBuilder()
        .build();

      stub.subscribeMissionProgress(request, new StreamObserver<MissionRawProto.MissionProgressResponse>() {

        @Override
        public void onNext(MissionRawProto.MissionProgressResponse value) {
          missionProgressProcessor.onNext(MissionProgress.translateFromRpc(value.getMissionProgress()));
        }

        @Override
        public void onError(Throwable t) {
          missionProgressProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          missionProgressProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<MissionRaw.MissionProgress> getMissionProgress() {
      if (!isMissionProgressInitialized) {
        synchronized (this) {
          if (!isMissionProgressInitialized) {
            MavsdkEventQueue.executor().execute(() -> processMissionProgress());
            isMissionProgressInitialized = true;
          }
        }
      }
      return missionProgress;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> missionChangedProcessor = PublishProcessor.create();
    private final Flowable<Boolean> missionChanged = missionChangedProcessor.onBackpressureBuffer().share();;
    private volatile boolean isMissionChangedInitialized = false;

    private void processMissionChanged() {
      MissionRawProto.SubscribeMissionChangedRequest request = MissionRawProto.SubscribeMissionChangedRequest.newBuilder()
        .build();

      stub.subscribeMissionChanged(request, new StreamObserver<MissionRawProto.MissionChangedResponse>() {

        @Override
        public void onNext(MissionRawProto.MissionChangedResponse value) {
          missionChangedProcessor.onNext(value.getMissionChanged());
        }

        @Override
        public void onError(Throwable t) {
          missionChangedProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          missionChangedProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getMissionChanged() {
      if (!isMissionChangedInitialized) {
        synchronized (this) {
          if (!isMissionChangedInitialized) {
            MavsdkEventQueue.executor().execute(() -> processMissionChanged());
            isMissionChangedInitialized = true;
          }
        }
      }
      return missionChanged;
    }


    @CheckReturnValue
    public Single<MissionRaw.MissionImportData> importQgroundcontrolMission(@NonNull String qgcPlanPath) {
      MissionRawProto.ImportQgroundcontrolMissionRequest request = MissionRawProto.ImportQgroundcontrolMissionRequest.newBuilder()
        .setQgcPlanPath(qgcPlanPath)
        .build();

      Single<MissionRaw.MissionImportData> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.importQgroundcontrolMission(request, new StreamObserver<MissionRawProto.ImportQgroundcontrolMissionResponse>() {

          @Override
          public void onNext(MissionRawProto.ImportQgroundcontrolMissionResponse value) {
            MissionRawResult result = MissionRawResult.translateFromRpc(value.getMissionRawResult());

            if (result.result != MissionRawResult.Result.SUCCESS) {
              emitter.onError(new MissionRawException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(MissionImportData.translateFromRpc(value.getMissionImportData()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}