package io.mavsdk.ftp;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Ftp implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Ftp.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private FtpServiceGrpc.FtpServiceStub stub;

  private volatile boolean isInitialized = false;

  public Ftp(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Ftp() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = FtpServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class FtpException extends MavsdkException {
    private FtpResult.Result code;
    private String description;

    public FtpException(FtpResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public FtpResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class ProgressData {
      private Integer bytesTransferred;
      private Integer totalBytes;

      public ProgressData(Integer bytesTransferred, Integer totalBytes) {
        this.bytesTransferred = bytesTransferred;
        this.totalBytes = totalBytes;
      }
      public Integer getBytesTransferred() {
        return bytesTransferred;
      }
      public Integer getTotalBytes() {
        return totalBytes;
      }

      protected FtpProto.ProgressData rpcProgressData() {
        return FtpProto.ProgressData.newBuilder()
          .setBytesTransferred(this.bytesTransferred)
          .setTotalBytes(this.totalBytes)
          .build();
      }

      protected static ProgressData translateFromRpc(FtpProto.ProgressData rpcProgressData) {
        return new ProgressData(
                rpcProgressData.getBytesTransferred(),
                rpcProgressData.getTotalBytes());
      }
    }


    public static class FtpResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_SUCCESS;
            }
          }, 
          NEXT {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_NEXT;
            }
          }, 
          TIMEOUT {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_TIMEOUT;
            }
          }, 
          BUSY {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_BUSY;
            }
          }, 
          FILE_IO_ERROR {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_FILE_IO_ERROR;
            }
          }, 
          FILE_EXISTS {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_FILE_EXISTS;
            }
          }, 
          FILE_DOES_NOT_EXIST {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_FILE_DOES_NOT_EXIST;
            }
          }, 
          FILE_PROTECTED {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_FILE_PROTECTED;
            }
          }, 
          INVALID_PARAMETER {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_INVALID_PARAMETER;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_UNSUPPORTED;
            }
          }, 
          PROTOCOL_ERROR {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_PROTOCOL_ERROR;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected FtpProto.FtpResult.Result rpcResult() {
              return FtpProto.FtpResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(FtpProto.FtpResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NEXT: 
                return Result.NEXT;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_FILE_IO_ERROR: 
                return Result.FILE_IO_ERROR;
              case RESULT_FILE_EXISTS: 
                return Result.FILE_EXISTS;
              case RESULT_FILE_DOES_NOT_EXIST: 
                return Result.FILE_DOES_NOT_EXIST;
              case RESULT_FILE_PROTECTED: 
                return Result.FILE_PROTECTED;
              case RESULT_INVALID_PARAMETER: 
                return Result.INVALID_PARAMETER;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
              case RESULT_PROTOCOL_ERROR: 
                return Result.PROTOCOL_ERROR;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract FtpProto.FtpResult.Result rpcResult();
        }

      public FtpResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected FtpProto.FtpResult rpcFtpResult() {
        return FtpProto.FtpResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static FtpResult translateFromRpc(FtpProto.FtpResult rpcFtpResult) {
        return new FtpResult(
                Result.translateFromRpc(rpcFtpResult.getResult()),
                rpcFtpResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable reset() {

      FtpProto.ResetRequest request = FtpProto.ResetRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.reset(request, new StreamObserver<FtpProto.ResetResponse>() {

          @Override
          public void onNext(FtpProto.ResetResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Finite stream
    private Flowable<Ftp.ProgressData> createDownload(String remoteFilePath, String localDir) {
      FtpProto.SubscribeDownloadRequest request = FtpProto.SubscribeDownloadRequest.newBuilder()
        .setRemoteFilePath(remoteFilePath)
        .setLocalDir(localDir)
        .build();

      Flowable<Ftp.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeDownload(request, new StreamObserver<FtpProto.DownloadResponse>() {

          @Override
          public void onNext(FtpProto.DownloadResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new FtpException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Ftp.ProgressData> download(@NonNull String remoteFilePath, @NonNull String localDir) {
      return createDownload(remoteFilePath, localDir);
    }



    // Finite stream
    private Flowable<Ftp.ProgressData> createUpload(String localFilePath, String remoteDir) {
      FtpProto.SubscribeUploadRequest request = FtpProto.SubscribeUploadRequest.newBuilder()
        .setLocalFilePath(localFilePath)
        .setRemoteDir(remoteDir)
        .build();

      Flowable<Ftp.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeUpload(request, new StreamObserver<FtpProto.UploadResponse>() {

          @Override
          public void onNext(FtpProto.UploadResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new FtpException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Ftp.ProgressData> upload(@NonNull String localFilePath, @NonNull String remoteDir) {
      return createUpload(localFilePath, remoteDir);
    }


    @CheckReturnValue
    public Single<List<String>> listDirectory(@NonNull String remoteDir) {
      FtpProto.ListDirectoryRequest request = FtpProto.ListDirectoryRequest.newBuilder()
        .setRemoteDir(remoteDir)
        .build();

      Single<List<String>> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.listDirectory(request, new StreamObserver<FtpProto.ListDirectoryResponse>() {

          @Override
          public void onNext(FtpProto.ListDirectoryResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getPathsList());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable createDirectory(@NonNull String remoteDir) {

      FtpProto.CreateDirectoryRequest request = FtpProto.CreateDirectoryRequest.newBuilder()
        .setRemoteDir(remoteDir)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.createDirectory(request, new StreamObserver<FtpProto.CreateDirectoryResponse>() {

          @Override
          public void onNext(FtpProto.CreateDirectoryResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable removeDirectory(@NonNull String remoteDir) {

      FtpProto.RemoveDirectoryRequest request = FtpProto.RemoveDirectoryRequest.newBuilder()
        .setRemoteDir(remoteDir)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.removeDirectory(request, new StreamObserver<FtpProto.RemoveDirectoryResponse>() {

          @Override
          public void onNext(FtpProto.RemoveDirectoryResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable removeFile(@NonNull String remoteFilePath) {

      FtpProto.RemoveFileRequest request = FtpProto.RemoveFileRequest.newBuilder()
        .setRemoteFilePath(remoteFilePath)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.removeFile(request, new StreamObserver<FtpProto.RemoveFileResponse>() {

          @Override
          public void onNext(FtpProto.RemoveFileResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable rename(@NonNull String remoteFromPath, @NonNull String remoteToPath) {

      FtpProto.RenameRequest request = FtpProto.RenameRequest.newBuilder()
        .setRemoteFromPath(remoteFromPath)
        .setRemoteToPath(remoteToPath)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.rename(request, new StreamObserver<FtpProto.RenameResponse>() {

          @Override
          public void onNext(FtpProto.RenameResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Boolean> areFilesIdentical(@NonNull String localFilePath, @NonNull String remoteFilePath) {
      FtpProto.AreFilesIdenticalRequest request = FtpProto.AreFilesIdenticalRequest.newBuilder()
        .setLocalFilePath(localFilePath)
        .setRemoteFilePath(remoteFilePath)
        .build();

      Single<Boolean> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.areFilesIdentical(request, new StreamObserver<FtpProto.AreFilesIdenticalResponse>() {

          @Override
          public void onNext(FtpProto.AreFilesIdenticalResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getAreIdentical());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRootDirectory(@NonNull String rootDir) {

      FtpProto.SetRootDirectoryRequest request = FtpProto.SetRootDirectoryRequest.newBuilder()
        .setRootDir(rootDir)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRootDirectory(request, new StreamObserver<FtpProto.SetRootDirectoryResponse>() {

          @Override
          public void onNext(FtpProto.SetRootDirectoryResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setTargetCompid(@NonNull Integer compid) {

      FtpProto.SetTargetCompidRequest request = FtpProto.SetTargetCompidRequest.newBuilder()
        .setCompid(compid)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setTargetCompid(request, new StreamObserver<FtpProto.SetTargetCompidResponse>() {

          @Override
          public void onNext(FtpProto.SetTargetCompidResponse value) {
            FtpResult result = FtpResult.translateFromRpc(value.getFtpResult());

            if (result.result != FtpResult.Result.SUCCESS) {
              emitter.onError(new FtpException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Integer> getOurCompid() {
      FtpProto.GetOurCompidRequest request = FtpProto.GetOurCompidRequest.newBuilder()
        .build();

      Single<Integer> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getOurCompid(request, new StreamObserver<FtpProto.GetOurCompidResponse>() {

          @Override
          public void onNext(FtpProto.GetOurCompidResponse value) {
              emitter.onSuccess(value.getCompid());
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}