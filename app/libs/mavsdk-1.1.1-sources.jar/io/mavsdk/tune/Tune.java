package io.mavsdk.tune;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Tune implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Tune.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private TuneServiceGrpc.TuneServiceStub stub;

  private volatile boolean isInitialized = false;

  public Tune(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Tune() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = TuneServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class TuneException extends MavsdkException {
    private TuneResult.Result code;
    private String description;

    public TuneException(TuneResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public TuneResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum SongElement {
      
      STYLE_LEGATO {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_STYLE_LEGATO;
        }
      }, 
      STYLE_NORMAL {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_STYLE_NORMAL;
        }
      }, 
      STYLE_STACCATO {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_STYLE_STACCATO;
        }
      }, 
      DURATION_1 {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_DURATION_1;
        }
      }, 
      DURATION_2 {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_DURATION_2;
        }
      }, 
      DURATION_4 {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_DURATION_4;
        }
      }, 
      DURATION_8 {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_DURATION_8;
        }
      }, 
      DURATION_16 {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_DURATION_16;
        }
      }, 
      DURATION_32 {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_DURATION_32;
        }
      }, 
      NOTE_A {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_A;
        }
      }, 
      NOTE_B {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_B;
        }
      }, 
      NOTE_C {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_C;
        }
      }, 
      NOTE_D {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_D;
        }
      }, 
      NOTE_E {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_E;
        }
      }, 
      NOTE_F {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_F;
        }
      }, 
      NOTE_G {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_G;
        }
      }, 
      NOTE_PAUSE {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_NOTE_PAUSE;
        }
      }, 
      SHARP {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_SHARP;
        }
      }, 
      FLAT {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_FLAT;
        }
      }, 
      OCTAVE_UP {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_OCTAVE_UP;
        }
      }, 
      OCTAVE_DOWN {
        @Override
        protected TuneProto.SongElement rpcSongElement() {
          return TuneProto.SongElement.SONG_ELEMENT_OCTAVE_DOWN;
        }
      };

      protected static SongElement translateFromRpc(TuneProto.SongElement rpcSongElement) {
        switch (rpcSongElement) {
          case SONG_ELEMENT_STYLE_LEGATO: default: 
            return SongElement.STYLE_LEGATO;
          case SONG_ELEMENT_STYLE_NORMAL: 
            return SongElement.STYLE_NORMAL;
          case SONG_ELEMENT_STYLE_STACCATO: 
            return SongElement.STYLE_STACCATO;
          case SONG_ELEMENT_DURATION_1: 
            return SongElement.DURATION_1;
          case SONG_ELEMENT_DURATION_2: 
            return SongElement.DURATION_2;
          case SONG_ELEMENT_DURATION_4: 
            return SongElement.DURATION_4;
          case SONG_ELEMENT_DURATION_8: 
            return SongElement.DURATION_8;
          case SONG_ELEMENT_DURATION_16: 
            return SongElement.DURATION_16;
          case SONG_ELEMENT_DURATION_32: 
            return SongElement.DURATION_32;
          case SONG_ELEMENT_NOTE_A: 
            return SongElement.NOTE_A;
          case SONG_ELEMENT_NOTE_B: 
            return SongElement.NOTE_B;
          case SONG_ELEMENT_NOTE_C: 
            return SongElement.NOTE_C;
          case SONG_ELEMENT_NOTE_D: 
            return SongElement.NOTE_D;
          case SONG_ELEMENT_NOTE_E: 
            return SongElement.NOTE_E;
          case SONG_ELEMENT_NOTE_F: 
            return SongElement.NOTE_F;
          case SONG_ELEMENT_NOTE_G: 
            return SongElement.NOTE_G;
          case SONG_ELEMENT_NOTE_PAUSE: 
            return SongElement.NOTE_PAUSE;
          case SONG_ELEMENT_SHARP: 
            return SongElement.SHARP;
          case SONG_ELEMENT_FLAT: 
            return SongElement.FLAT;
          case SONG_ELEMENT_OCTAVE_UP: 
            return SongElement.OCTAVE_UP;
          case SONG_ELEMENT_OCTAVE_DOWN: 
            return SongElement.OCTAVE_DOWN;
        }
      }

      protected abstract TuneProto.SongElement rpcSongElement();
    }


    public static class TuneDescription {
      private List<SongElement> songElements;
      private Integer tempo;

      public TuneDescription(List<SongElement> songElements, Integer tempo) {
        this.songElements = songElements;
        this.tempo = tempo;
      }
      public List<SongElement> getSongElements() {
        return songElements;
      }
      public Integer getTempo() {
        return tempo;
      }

      protected TuneProto.TuneDescription rpcTuneDescription() {
        return TuneProto.TuneDescription.newBuilder()
          .addAllSongElements(songElements.stream().map(SongElement::rpcSongElement).collect(Collectors.toList()))
          .setTempo(this.tempo)
          .build();
      }

      protected static TuneDescription translateFromRpc(TuneProto.TuneDescription rpcTuneDescription) {
        return new TuneDescription(
                    rpcTuneDescription.getSongElementsList().stream().map(SongElement::translateFromRpc).collect(Collectors.toList()),
                rpcTuneDescription.getTempo());
      }
    }


    public static class TuneResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected TuneProto.TuneResult.Result rpcResult() {
              return TuneProto.TuneResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected TuneProto.TuneResult.Result rpcResult() {
              return TuneProto.TuneResult.Result.RESULT_SUCCESS;
            }
          }, 
          INVALID_TEMPO {
            @Override
            protected TuneProto.TuneResult.Result rpcResult() {
              return TuneProto.TuneResult.Result.RESULT_INVALID_TEMPO;
            }
          }, 
          TUNE_TOO_LONG {
            @Override
            protected TuneProto.TuneResult.Result rpcResult() {
              return TuneProto.TuneResult.Result.RESULT_TUNE_TOO_LONG;
            }
          }, 
          ERROR {
            @Override
            protected TuneProto.TuneResult.Result rpcResult() {
              return TuneProto.TuneResult.Result.RESULT_ERROR;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected TuneProto.TuneResult.Result rpcResult() {
              return TuneProto.TuneResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(TuneProto.TuneResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_INVALID_TEMPO: 
                return Result.INVALID_TEMPO;
              case RESULT_TUNE_TOO_LONG: 
                return Result.TUNE_TOO_LONG;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract TuneProto.TuneResult.Result rpcResult();
        }

      public TuneResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected TuneProto.TuneResult rpcTuneResult() {
        return TuneProto.TuneResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static TuneResult translateFromRpc(TuneProto.TuneResult rpcTuneResult) {
        return new TuneResult(
                Result.translateFromRpc(rpcTuneResult.getResult()),
                rpcTuneResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable playTune(@NonNull TuneDescription tuneDescription) {

      TuneProto.PlayTuneRequest request = TuneProto.PlayTuneRequest.newBuilder()
        .setTuneDescription(tuneDescription.rpcTuneDescription())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.playTune(request, new StreamObserver<TuneProto.PlayTuneResponse>() {

          @Override
          public void onNext(TuneProto.PlayTuneResponse value) {
            TuneResult result = TuneResult.translateFromRpc(value.getTuneResult());

            if (result.result != TuneResult.Result.SUCCESS) {
              emitter.onError(new TuneException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}