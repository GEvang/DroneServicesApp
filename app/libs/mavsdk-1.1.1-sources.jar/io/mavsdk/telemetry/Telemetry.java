package io.mavsdk.telemetry;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Telemetry implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Telemetry.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private TelemetryServiceGrpc.TelemetryServiceStub stub;

  private volatile boolean isInitialized = false;

  public Telemetry(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Telemetry() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = TelemetryServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class TelemetryException extends MavsdkException {
    private TelemetryResult.Result code;
    private String description;

    public TelemetryException(TelemetryResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public TelemetryResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum FixType {
      
      NO_GPS {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_NO_GPS;
        }
      }, 
      NO_FIX {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_NO_FIX;
        }
      }, 
      FIX_2D {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_FIX_2D;
        }
      }, 
      FIX_3D {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_FIX_3D;
        }
      }, 
      FIX_DGPS {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_FIX_DGPS;
        }
      }, 
      RTK_FLOAT {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_RTK_FLOAT;
        }
      }, 
      RTK_FIXED {
        @Override
        protected TelemetryProto.FixType rpcFixType() {
          return TelemetryProto.FixType.FIX_TYPE_RTK_FIXED;
        }
      };

      protected static FixType translateFromRpc(TelemetryProto.FixType rpcFixType) {
        switch (rpcFixType) {
          case FIX_TYPE_NO_GPS: default: 
            return FixType.NO_GPS;
          case FIX_TYPE_NO_FIX: 
            return FixType.NO_FIX;
          case FIX_TYPE_FIX_2D: 
            return FixType.FIX_2D;
          case FIX_TYPE_FIX_3D: 
            return FixType.FIX_3D;
          case FIX_TYPE_FIX_DGPS: 
            return FixType.FIX_DGPS;
          case FIX_TYPE_RTK_FLOAT: 
            return FixType.RTK_FLOAT;
          case FIX_TYPE_RTK_FIXED: 
            return FixType.RTK_FIXED;
        }
      }

      protected abstract TelemetryProto.FixType rpcFixType();
    }
    public enum FlightMode {
      
      UNKNOWN {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_UNKNOWN;
        }
      }, 
      READY {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_READY;
        }
      }, 
      TAKEOFF {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_TAKEOFF;
        }
      }, 
      HOLD {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_HOLD;
        }
      }, 
      MISSION {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_MISSION;
        }
      }, 
      RETURN_TO_LAUNCH {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_RETURN_TO_LAUNCH;
        }
      }, 
      LAND {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_LAND;
        }
      }, 
      OFFBOARD {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_OFFBOARD;
        }
      }, 
      FOLLOW_ME {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_FOLLOW_ME;
        }
      }, 
      MANUAL {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_MANUAL;
        }
      }, 
      ALTCTL {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_ALTCTL;
        }
      }, 
      POSCTL {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_POSCTL;
        }
      }, 
      ACRO {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_ACRO;
        }
      }, 
      STABILIZED {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_STABILIZED;
        }
      }, 
      RATTITUDE {
        @Override
        protected TelemetryProto.FlightMode rpcFlightMode() {
          return TelemetryProto.FlightMode.FLIGHT_MODE_RATTITUDE;
        }
      };

      protected static FlightMode translateFromRpc(TelemetryProto.FlightMode rpcFlightMode) {
        switch (rpcFlightMode) {
          case FLIGHT_MODE_UNKNOWN: default: 
            return FlightMode.UNKNOWN;
          case FLIGHT_MODE_READY: 
            return FlightMode.READY;
          case FLIGHT_MODE_TAKEOFF: 
            return FlightMode.TAKEOFF;
          case FLIGHT_MODE_HOLD: 
            return FlightMode.HOLD;
          case FLIGHT_MODE_MISSION: 
            return FlightMode.MISSION;
          case FLIGHT_MODE_RETURN_TO_LAUNCH: 
            return FlightMode.RETURN_TO_LAUNCH;
          case FLIGHT_MODE_LAND: 
            return FlightMode.LAND;
          case FLIGHT_MODE_OFFBOARD: 
            return FlightMode.OFFBOARD;
          case FLIGHT_MODE_FOLLOW_ME: 
            return FlightMode.FOLLOW_ME;
          case FLIGHT_MODE_MANUAL: 
            return FlightMode.MANUAL;
          case FLIGHT_MODE_ALTCTL: 
            return FlightMode.ALTCTL;
          case FLIGHT_MODE_POSCTL: 
            return FlightMode.POSCTL;
          case FLIGHT_MODE_ACRO: 
            return FlightMode.ACRO;
          case FLIGHT_MODE_STABILIZED: 
            return FlightMode.STABILIZED;
          case FLIGHT_MODE_RATTITUDE: 
            return FlightMode.RATTITUDE;
        }
      }

      protected abstract TelemetryProto.FlightMode rpcFlightMode();
    }
    public enum StatusTextType {
      
      DEBUG {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_DEBUG;
        }
      }, 
      INFO {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_INFO;
        }
      }, 
      NOTICE {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_NOTICE;
        }
      }, 
      WARNING {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_WARNING;
        }
      }, 
      ERROR {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_ERROR;
        }
      }, 
      CRITICAL {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_CRITICAL;
        }
      }, 
      ALERT {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_ALERT;
        }
      }, 
      EMERGENCY {
        @Override
        protected TelemetryProto.StatusTextType rpcStatusTextType() {
          return TelemetryProto.StatusTextType.STATUS_TEXT_TYPE_EMERGENCY;
        }
      };

      protected static StatusTextType translateFromRpc(TelemetryProto.StatusTextType rpcStatusTextType) {
        switch (rpcStatusTextType) {
          case STATUS_TEXT_TYPE_DEBUG: default: 
            return StatusTextType.DEBUG;
          case STATUS_TEXT_TYPE_INFO: 
            return StatusTextType.INFO;
          case STATUS_TEXT_TYPE_NOTICE: 
            return StatusTextType.NOTICE;
          case STATUS_TEXT_TYPE_WARNING: 
            return StatusTextType.WARNING;
          case STATUS_TEXT_TYPE_ERROR: 
            return StatusTextType.ERROR;
          case STATUS_TEXT_TYPE_CRITICAL: 
            return StatusTextType.CRITICAL;
          case STATUS_TEXT_TYPE_ALERT: 
            return StatusTextType.ALERT;
          case STATUS_TEXT_TYPE_EMERGENCY: 
            return StatusTextType.EMERGENCY;
        }
      }

      protected abstract TelemetryProto.StatusTextType rpcStatusTextType();
    }
    public enum LandedState {
      
      UNKNOWN {
        @Override
        protected TelemetryProto.LandedState rpcLandedState() {
          return TelemetryProto.LandedState.LANDED_STATE_UNKNOWN;
        }
      }, 
      ON_GROUND {
        @Override
        protected TelemetryProto.LandedState rpcLandedState() {
          return TelemetryProto.LandedState.LANDED_STATE_ON_GROUND;
        }
      }, 
      IN_AIR {
        @Override
        protected TelemetryProto.LandedState rpcLandedState() {
          return TelemetryProto.LandedState.LANDED_STATE_IN_AIR;
        }
      }, 
      TAKING_OFF {
        @Override
        protected TelemetryProto.LandedState rpcLandedState() {
          return TelemetryProto.LandedState.LANDED_STATE_TAKING_OFF;
        }
      }, 
      LANDING {
        @Override
        protected TelemetryProto.LandedState rpcLandedState() {
          return TelemetryProto.LandedState.LANDED_STATE_LANDING;
        }
      };

      protected static LandedState translateFromRpc(TelemetryProto.LandedState rpcLandedState) {
        switch (rpcLandedState) {
          case LANDED_STATE_UNKNOWN: default: 
            return LandedState.UNKNOWN;
          case LANDED_STATE_ON_GROUND: 
            return LandedState.ON_GROUND;
          case LANDED_STATE_IN_AIR: 
            return LandedState.IN_AIR;
          case LANDED_STATE_TAKING_OFF: 
            return LandedState.TAKING_OFF;
          case LANDED_STATE_LANDING: 
            return LandedState.LANDING;
        }
      }

      protected abstract TelemetryProto.LandedState rpcLandedState();
    }
    public enum VtolState {
      
      UNDEFINED {
        @Override
        protected TelemetryProto.VtolState rpcVtolState() {
          return TelemetryProto.VtolState.VTOL_STATE_UNDEFINED;
        }
      }, 
      TRANSITION_TO_FW {
        @Override
        protected TelemetryProto.VtolState rpcVtolState() {
          return TelemetryProto.VtolState.VTOL_STATE_TRANSITION_TO_FW;
        }
      }, 
      TRANSITION_TO_MC {
        @Override
        protected TelemetryProto.VtolState rpcVtolState() {
          return TelemetryProto.VtolState.VTOL_STATE_TRANSITION_TO_MC;
        }
      }, 
      MC {
        @Override
        protected TelemetryProto.VtolState rpcVtolState() {
          return TelemetryProto.VtolState.VTOL_STATE_MC;
        }
      }, 
      FW {
        @Override
        protected TelemetryProto.VtolState rpcVtolState() {
          return TelemetryProto.VtolState.VTOL_STATE_FW;
        }
      };

      protected static VtolState translateFromRpc(TelemetryProto.VtolState rpcVtolState) {
        switch (rpcVtolState) {
          case VTOL_STATE_UNDEFINED: default: 
            return VtolState.UNDEFINED;
          case VTOL_STATE_TRANSITION_TO_FW: 
            return VtolState.TRANSITION_TO_FW;
          case VTOL_STATE_TRANSITION_TO_MC: 
            return VtolState.TRANSITION_TO_MC;
          case VTOL_STATE_MC: 
            return VtolState.MC;
          case VTOL_STATE_FW: 
            return VtolState.FW;
        }
      }

      protected abstract TelemetryProto.VtolState rpcVtolState();
    }


    public static class Position {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float relativeAltitudeM;

      public Position(Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float relativeAltitudeM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.relativeAltitudeM = relativeAltitudeM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getRelativeAltitudeM() {
        return relativeAltitudeM;
      }

      protected TelemetryProto.Position rpcPosition() {
        return TelemetryProto.Position.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setRelativeAltitudeM(this.relativeAltitudeM)
          .build();
      }

      protected static Position translateFromRpc(TelemetryProto.Position rpcPosition) {
        return new Position(
                rpcPosition.getLatitudeDeg(),
                rpcPosition.getLongitudeDeg(),
                rpcPosition.getAbsoluteAltitudeM(),
                rpcPosition.getRelativeAltitudeM());
      }
    }


    public static class Heading {
      private Double headingDeg;

      public Heading(Double headingDeg) {
        this.headingDeg = headingDeg;
      }
      public Double getHeadingDeg() {
        return headingDeg;
      }

      protected TelemetryProto.Heading rpcHeading() {
        return TelemetryProto.Heading.newBuilder()
          .setHeadingDeg(this.headingDeg)
          .build();
      }

      protected static Heading translateFromRpc(TelemetryProto.Heading rpcHeading) {
        return new Heading(
                rpcHeading.getHeadingDeg());
      }
    }


    public static class Quaternion {
      private Float w;
      private Float x;
      private Float y;
      private Float z;
      private Long timestampUs;

      public Quaternion(Float w, Float x, Float y, Float z, Long timestampUs) {
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.timestampUs = timestampUs;
      }
      public Float getW() {
        return w;
      }
      public Float getX() {
        return x;
      }
      public Float getY() {
        return y;
      }
      public Float getZ() {
        return z;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }

      protected TelemetryProto.Quaternion rpcQuaternion() {
        return TelemetryProto.Quaternion.newBuilder()
          .setW(this.w)
          .setX(this.x)
          .setY(this.y)
          .setZ(this.z)
          .setTimestampUs(this.timestampUs)
          .build();
      }

      protected static Quaternion translateFromRpc(TelemetryProto.Quaternion rpcQuaternion) {
        return new Quaternion(
                rpcQuaternion.getW(),
                rpcQuaternion.getX(),
                rpcQuaternion.getY(),
                rpcQuaternion.getZ(),
                rpcQuaternion.getTimestampUs());
      }
    }


    public static class EulerAngle {
      private Float rollDeg;
      private Float pitchDeg;
      private Float yawDeg;
      private Long timestampUs;

      public EulerAngle(Float rollDeg, Float pitchDeg, Float yawDeg, Long timestampUs) {
        this.rollDeg = rollDeg;
        this.pitchDeg = pitchDeg;
        this.yawDeg = yawDeg;
        this.timestampUs = timestampUs;
      }
      public Float getRollDeg() {
        return rollDeg;
      }
      public Float getPitchDeg() {
        return pitchDeg;
      }
      public Float getYawDeg() {
        return yawDeg;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }

      protected TelemetryProto.EulerAngle rpcEulerAngle() {
        return TelemetryProto.EulerAngle.newBuilder()
          .setRollDeg(this.rollDeg)
          .setPitchDeg(this.pitchDeg)
          .setYawDeg(this.yawDeg)
          .setTimestampUs(this.timestampUs)
          .build();
      }

      protected static EulerAngle translateFromRpc(TelemetryProto.EulerAngle rpcEulerAngle) {
        return new EulerAngle(
                rpcEulerAngle.getRollDeg(),
                rpcEulerAngle.getPitchDeg(),
                rpcEulerAngle.getYawDeg(),
                rpcEulerAngle.getTimestampUs());
      }
    }


    public static class AngularVelocityBody {
      private Float rollRadS;
      private Float pitchRadS;
      private Float yawRadS;

      public AngularVelocityBody(Float rollRadS, Float pitchRadS, Float yawRadS) {
        this.rollRadS = rollRadS;
        this.pitchRadS = pitchRadS;
        this.yawRadS = yawRadS;
      }
      public Float getRollRadS() {
        return rollRadS;
      }
      public Float getPitchRadS() {
        return pitchRadS;
      }
      public Float getYawRadS() {
        return yawRadS;
      }

      protected TelemetryProto.AngularVelocityBody rpcAngularVelocityBody() {
        return TelemetryProto.AngularVelocityBody.newBuilder()
          .setRollRadS(this.rollRadS)
          .setPitchRadS(this.pitchRadS)
          .setYawRadS(this.yawRadS)
          .build();
      }

      protected static AngularVelocityBody translateFromRpc(TelemetryProto.AngularVelocityBody rpcAngularVelocityBody) {
        return new AngularVelocityBody(
                rpcAngularVelocityBody.getRollRadS(),
                rpcAngularVelocityBody.getPitchRadS(),
                rpcAngularVelocityBody.getYawRadS());
      }
    }


    public static class GpsInfo {
      private Integer numSatellites;
      private FixType fixType;

      public GpsInfo(Integer numSatellites, FixType fixType) {
        this.numSatellites = numSatellites;
        this.fixType = fixType;
      }
      public Integer getNumSatellites() {
        return numSatellites;
      }
      public FixType getFixType() {
        return fixType;
      }

      protected TelemetryProto.GpsInfo rpcGpsInfo() {
        return TelemetryProto.GpsInfo.newBuilder()
          .setNumSatellites(this.numSatellites)
          .setFixType(this.fixType.rpcFixType())
          .build();
      }

      protected static GpsInfo translateFromRpc(TelemetryProto.GpsInfo rpcGpsInfo) {
        return new GpsInfo(
                rpcGpsInfo.getNumSatellites(),
                FixType.translateFromRpc(rpcGpsInfo.getFixType()));
      }
    }


    public static class RawGps {
      private Long timestampUs;
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float hdop;
      private Float vdop;
      private Float velocityMS;
      private Float cogDeg;
      private Float altitudeEllipsoidM;
      private Float horizontalUncertaintyM;
      private Float verticalUncertaintyM;
      private Float velocityUncertaintyMS;
      private Float headingUncertaintyDeg;
      private Float yawDeg;

      public RawGps(Long timestampUs, Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float hdop, Float vdop, Float velocityMS, Float cogDeg, Float altitudeEllipsoidM, Float horizontalUncertaintyM, Float verticalUncertaintyM, Float velocityUncertaintyMS, Float headingUncertaintyDeg, Float yawDeg) {
        this.timestampUs = timestampUs;
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.hdop = hdop;
        this.vdop = vdop;
        this.velocityMS = velocityMS;
        this.cogDeg = cogDeg;
        this.altitudeEllipsoidM = altitudeEllipsoidM;
        this.horizontalUncertaintyM = horizontalUncertaintyM;
        this.verticalUncertaintyM = verticalUncertaintyM;
        this.velocityUncertaintyMS = velocityUncertaintyMS;
        this.headingUncertaintyDeg = headingUncertaintyDeg;
        this.yawDeg = yawDeg;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getHdop() {
        return hdop;
      }
      public Float getVdop() {
        return vdop;
      }
      public Float getVelocityMS() {
        return velocityMS;
      }
      public Float getCogDeg() {
        return cogDeg;
      }
      public Float getAltitudeEllipsoidM() {
        return altitudeEllipsoidM;
      }
      public Float getHorizontalUncertaintyM() {
        return horizontalUncertaintyM;
      }
      public Float getVerticalUncertaintyM() {
        return verticalUncertaintyM;
      }
      public Float getVelocityUncertaintyMS() {
        return velocityUncertaintyMS;
      }
      public Float getHeadingUncertaintyDeg() {
        return headingUncertaintyDeg;
      }
      public Float getYawDeg() {
        return yawDeg;
      }

      protected TelemetryProto.RawGps rpcRawGps() {
        return TelemetryProto.RawGps.newBuilder()
          .setTimestampUs(this.timestampUs)
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setHdop(this.hdop)
          .setVdop(this.vdop)
          .setVelocityMS(this.velocityMS)
          .setCogDeg(this.cogDeg)
          .setAltitudeEllipsoidM(this.altitudeEllipsoidM)
          .setHorizontalUncertaintyM(this.horizontalUncertaintyM)
          .setVerticalUncertaintyM(this.verticalUncertaintyM)
          .setVelocityUncertaintyMS(this.velocityUncertaintyMS)
          .setHeadingUncertaintyDeg(this.headingUncertaintyDeg)
          .setYawDeg(this.yawDeg)
          .build();
      }

      protected static RawGps translateFromRpc(TelemetryProto.RawGps rpcRawGps) {
        return new RawGps(
                rpcRawGps.getTimestampUs(),
                rpcRawGps.getLatitudeDeg(),
                rpcRawGps.getLongitudeDeg(),
                rpcRawGps.getAbsoluteAltitudeM(),
                rpcRawGps.getHdop(),
                rpcRawGps.getVdop(),
                rpcRawGps.getVelocityMS(),
                rpcRawGps.getCogDeg(),
                rpcRawGps.getAltitudeEllipsoidM(),
                rpcRawGps.getHorizontalUncertaintyM(),
                rpcRawGps.getVerticalUncertaintyM(),
                rpcRawGps.getVelocityUncertaintyMS(),
                rpcRawGps.getHeadingUncertaintyDeg(),
                rpcRawGps.getYawDeg());
      }
    }


    public static class Battery {
      private Integer id;
      private Float voltageV;
      private Float remainingPercent;

      public Battery(Integer id, Float voltageV, Float remainingPercent) {
        this.id = id;
        this.voltageV = voltageV;
        this.remainingPercent = remainingPercent;
      }
      public Integer getId() {
        return id;
      }
      public Float getVoltageV() {
        return voltageV;
      }
      public Float getRemainingPercent() {
        return remainingPercent;
      }

      protected TelemetryProto.Battery rpcBattery() {
        return TelemetryProto.Battery.newBuilder()
          .setId(this.id)
          .setVoltageV(this.voltageV)
          .setRemainingPercent(this.remainingPercent)
          .build();
      }

      protected static Battery translateFromRpc(TelemetryProto.Battery rpcBattery) {
        return new Battery(
                rpcBattery.getId(),
                rpcBattery.getVoltageV(),
                rpcBattery.getRemainingPercent());
      }
    }


    public static class Health {
      private Boolean isGyrometerCalibrationOk;
      private Boolean isAccelerometerCalibrationOk;
      private Boolean isMagnetometerCalibrationOk;
      private Boolean isLocalPositionOk;
      private Boolean isGlobalPositionOk;
      private Boolean isHomePositionOk;
      private Boolean isArmable;

      public Health(Boolean isGyrometerCalibrationOk, Boolean isAccelerometerCalibrationOk, Boolean isMagnetometerCalibrationOk, Boolean isLocalPositionOk, Boolean isGlobalPositionOk, Boolean isHomePositionOk, Boolean isArmable) {
        this.isGyrometerCalibrationOk = isGyrometerCalibrationOk;
        this.isAccelerometerCalibrationOk = isAccelerometerCalibrationOk;
        this.isMagnetometerCalibrationOk = isMagnetometerCalibrationOk;
        this.isLocalPositionOk = isLocalPositionOk;
        this.isGlobalPositionOk = isGlobalPositionOk;
        this.isHomePositionOk = isHomePositionOk;
        this.isArmable = isArmable;
      }
      public Boolean getIsGyrometerCalibrationOk() {
        return isGyrometerCalibrationOk;
      }
      public Boolean getIsAccelerometerCalibrationOk() {
        return isAccelerometerCalibrationOk;
      }
      public Boolean getIsMagnetometerCalibrationOk() {
        return isMagnetometerCalibrationOk;
      }
      public Boolean getIsLocalPositionOk() {
        return isLocalPositionOk;
      }
      public Boolean getIsGlobalPositionOk() {
        return isGlobalPositionOk;
      }
      public Boolean getIsHomePositionOk() {
        return isHomePositionOk;
      }
      public Boolean getIsArmable() {
        return isArmable;
      }

      protected TelemetryProto.Health rpcHealth() {
        return TelemetryProto.Health.newBuilder()
          .setIsGyrometerCalibrationOk(this.isGyrometerCalibrationOk)
          .setIsAccelerometerCalibrationOk(this.isAccelerometerCalibrationOk)
          .setIsMagnetometerCalibrationOk(this.isMagnetometerCalibrationOk)
          .setIsLocalPositionOk(this.isLocalPositionOk)
          .setIsGlobalPositionOk(this.isGlobalPositionOk)
          .setIsHomePositionOk(this.isHomePositionOk)
          .setIsArmable(this.isArmable)
          .build();
      }

      protected static Health translateFromRpc(TelemetryProto.Health rpcHealth) {
        return new Health(
                rpcHealth.getIsGyrometerCalibrationOk(),
                rpcHealth.getIsAccelerometerCalibrationOk(),
                rpcHealth.getIsMagnetometerCalibrationOk(),
                rpcHealth.getIsLocalPositionOk(),
                rpcHealth.getIsGlobalPositionOk(),
                rpcHealth.getIsHomePositionOk(),
                rpcHealth.getIsArmable());
      }
    }


    public static class RcStatus {
      private Boolean wasAvailableOnce;
      private Boolean isAvailable;
      private Float signalStrengthPercent;

      public RcStatus(Boolean wasAvailableOnce, Boolean isAvailable, Float signalStrengthPercent) {
        this.wasAvailableOnce = wasAvailableOnce;
        this.isAvailable = isAvailable;
        this.signalStrengthPercent = signalStrengthPercent;
      }
      public Boolean getWasAvailableOnce() {
        return wasAvailableOnce;
      }
      public Boolean getIsAvailable() {
        return isAvailable;
      }
      public Float getSignalStrengthPercent() {
        return signalStrengthPercent;
      }

      protected TelemetryProto.RcStatus rpcRcStatus() {
        return TelemetryProto.RcStatus.newBuilder()
          .setWasAvailableOnce(this.wasAvailableOnce)
          .setIsAvailable(this.isAvailable)
          .setSignalStrengthPercent(this.signalStrengthPercent)
          .build();
      }

      protected static RcStatus translateFromRpc(TelemetryProto.RcStatus rpcRcStatus) {
        return new RcStatus(
                rpcRcStatus.getWasAvailableOnce(),
                rpcRcStatus.getIsAvailable(),
                rpcRcStatus.getSignalStrengthPercent());
      }
    }


    public static class StatusText {
      private StatusTextType type;
      private String text;

      public StatusText(StatusTextType type, String text) {
        this.type = type;
        this.text = text;
      }
      public StatusTextType getType() {
        return type;
      }
      public String getText() {
        return text;
      }

      protected TelemetryProto.StatusText rpcStatusText() {
        return TelemetryProto.StatusText.newBuilder()
          .setType(this.type.rpcStatusTextType())
          .setText(this.text)
          .build();
      }

      protected static StatusText translateFromRpc(TelemetryProto.StatusText rpcStatusText) {
        return new StatusText(
                StatusTextType.translateFromRpc(rpcStatusText.getType()),
                rpcStatusText.getText());
      }
    }


    public static class ActuatorControlTarget {
      private Integer group;
      private List<Float> controls;

      public ActuatorControlTarget(Integer group, List<Float> controls) {
        this.group = group;
        this.controls = controls;
      }
      public Integer getGroup() {
        return group;
      }
      public List<Float> getControls() {
        return controls;
      }

      protected TelemetryProto.ActuatorControlTarget rpcActuatorControlTarget() {
        return TelemetryProto.ActuatorControlTarget.newBuilder()
          .setGroup(this.group)
          .addAllControls(controls)
          .build();
      }

      protected static ActuatorControlTarget translateFromRpc(TelemetryProto.ActuatorControlTarget rpcActuatorControlTarget) {
        return new ActuatorControlTarget(
                rpcActuatorControlTarget.getGroup(),
                    rpcActuatorControlTarget.getControlsList());
      }
    }


    public static class ActuatorOutputStatus {
      private Integer active;
      private List<Float> actuator;

      public ActuatorOutputStatus(Integer active, List<Float> actuator) {
        this.active = active;
        this.actuator = actuator;
      }
      public Integer getActive() {
        return active;
      }
      public List<Float> getActuator() {
        return actuator;
      }

      protected TelemetryProto.ActuatorOutputStatus rpcActuatorOutputStatus() {
        return TelemetryProto.ActuatorOutputStatus.newBuilder()
          .setActive(this.active)
          .addAllActuator(actuator)
          .build();
      }

      protected static ActuatorOutputStatus translateFromRpc(TelemetryProto.ActuatorOutputStatus rpcActuatorOutputStatus) {
        return new ActuatorOutputStatus(
                rpcActuatorOutputStatus.getActive(),
                    rpcActuatorOutputStatus.getActuatorList());
      }
    }


    public static class Covariance {
      private List<Float> covarianceMatrix;

      public Covariance(List<Float> covarianceMatrix) {
        this.covarianceMatrix = covarianceMatrix;
      }
      public List<Float> getCovarianceMatrix() {
        return covarianceMatrix;
      }

      protected TelemetryProto.Covariance rpcCovariance() {
        return TelemetryProto.Covariance.newBuilder()
          .addAllCovarianceMatrix(covarianceMatrix)
          .build();
      }

      protected static Covariance translateFromRpc(TelemetryProto.Covariance rpcCovariance) {
        return new Covariance(
                    rpcCovariance.getCovarianceMatrixList());
      }
    }


    public static class VelocityBody {
      private Float xMS;
      private Float yMS;
      private Float zMS;

      public VelocityBody(Float xMS, Float yMS, Float zMS) {
        this.xMS = xMS;
        this.yMS = yMS;
        this.zMS = zMS;
      }
      public Float getXMS() {
        return xMS;
      }
      public Float getYMS() {
        return yMS;
      }
      public Float getZMS() {
        return zMS;
      }

      protected TelemetryProto.VelocityBody rpcVelocityBody() {
        return TelemetryProto.VelocityBody.newBuilder()
          .setXMS(this.xMS)
          .setYMS(this.yMS)
          .setZMS(this.zMS)
          .build();
      }

      protected static VelocityBody translateFromRpc(TelemetryProto.VelocityBody rpcVelocityBody) {
        return new VelocityBody(
                rpcVelocityBody.getXMS(),
                rpcVelocityBody.getYMS(),
                rpcVelocityBody.getZMS());
      }
    }


    public static class PositionBody {
      private Float xM;
      private Float yM;
      private Float zM;

      public PositionBody(Float xM, Float yM, Float zM) {
        this.xM = xM;
        this.yM = yM;
        this.zM = zM;
      }
      public Float getXM() {
        return xM;
      }
      public Float getYM() {
        return yM;
      }
      public Float getZM() {
        return zM;
      }

      protected TelemetryProto.PositionBody rpcPositionBody() {
        return TelemetryProto.PositionBody.newBuilder()
          .setXM(this.xM)
          .setYM(this.yM)
          .setZM(this.zM)
          .build();
      }

      protected static PositionBody translateFromRpc(TelemetryProto.PositionBody rpcPositionBody) {
        return new PositionBody(
                rpcPositionBody.getXM(),
                rpcPositionBody.getYM(),
                rpcPositionBody.getZM());
      }
    }


    public static class Odometry {
      private Long timeUsec;
      private MavFrame frameId;
      private MavFrame childFrameId;
      private PositionBody positionBody;
      private Quaternion q;
      private VelocityBody velocityBody;
      private AngularVelocityBody angularVelocityBody;
      private Covariance poseCovariance;
      private Covariance velocityCovariance;
      
        public enum MavFrame {
          
          UNDEF {
            @Override
            protected TelemetryProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryProto.Odometry.MavFrame.MAV_FRAME_UNDEF;
            }
          }, 
          BODY_NED {
            @Override
            protected TelemetryProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryProto.Odometry.MavFrame.MAV_FRAME_BODY_NED;
            }
          }, 
          VISION_NED {
            @Override
            protected TelemetryProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryProto.Odometry.MavFrame.MAV_FRAME_VISION_NED;
            }
          }, 
          ESTIM_NED {
            @Override
            protected TelemetryProto.Odometry.MavFrame rpcMavFrame() {
              return TelemetryProto.Odometry.MavFrame.MAV_FRAME_ESTIM_NED;
            }
          };

          protected static MavFrame translateFromRpc(TelemetryProto.Odometry.MavFrame rpcMavFrame) {
            switch (rpcMavFrame) {
              case MAV_FRAME_UNDEF: default: 
                return MavFrame.UNDEF;
              case MAV_FRAME_BODY_NED: 
                return MavFrame.BODY_NED;
              case MAV_FRAME_VISION_NED: 
                return MavFrame.VISION_NED;
              case MAV_FRAME_ESTIM_NED: 
                return MavFrame.ESTIM_NED;
            }
          }

          protected abstract TelemetryProto.Odometry.MavFrame rpcMavFrame();
        }

      public Odometry(Long timeUsec, MavFrame frameId, MavFrame childFrameId, PositionBody positionBody, Quaternion q, VelocityBody velocityBody, AngularVelocityBody angularVelocityBody, Covariance poseCovariance, Covariance velocityCovariance) {
        this.timeUsec = timeUsec;
        this.frameId = frameId;
        this.childFrameId = childFrameId;
        this.positionBody = positionBody;
        this.q = q;
        this.velocityBody = velocityBody;
        this.angularVelocityBody = angularVelocityBody;
        this.poseCovariance = poseCovariance;
        this.velocityCovariance = velocityCovariance;
      }
      public Long getTimeUsec() {
        return timeUsec;
      }
      public MavFrame getFrameId() {
        return frameId;
      }
      public MavFrame getChildFrameId() {
        return childFrameId;
      }
      public PositionBody getPositionBody() {
        return positionBody;
      }
      public Quaternion getQ() {
        return q;
      }
      public VelocityBody getVelocityBody() {
        return velocityBody;
      }
      public AngularVelocityBody getAngularVelocityBody() {
        return angularVelocityBody;
      }
      public Covariance getPoseCovariance() {
        return poseCovariance;
      }
      public Covariance getVelocityCovariance() {
        return velocityCovariance;
      }

      protected TelemetryProto.Odometry rpcOdometry() {
        return TelemetryProto.Odometry.newBuilder()
          .setTimeUsec(this.timeUsec)
          .setFrameId(this.frameId.rpcMavFrame())
          .setChildFrameId(this.childFrameId.rpcMavFrame())
          .setPositionBody(this.positionBody.rpcPositionBody())
          .setQ(this.q.rpcQuaternion())
          .setVelocityBody(this.velocityBody.rpcVelocityBody())
          .setAngularVelocityBody(this.angularVelocityBody.rpcAngularVelocityBody())
          .setPoseCovariance(this.poseCovariance.rpcCovariance())
          .setVelocityCovariance(this.velocityCovariance.rpcCovariance())
          .build();
      }

      protected static Odometry translateFromRpc(TelemetryProto.Odometry rpcOdometry) {
        return new Odometry(
                rpcOdometry.getTimeUsec(),
                MavFrame.translateFromRpc(rpcOdometry.getFrameId()),
                MavFrame.translateFromRpc(rpcOdometry.getChildFrameId()),
                PositionBody.translateFromRpc(rpcOdometry.getPositionBody()),
                Quaternion.translateFromRpc(rpcOdometry.getQ()),
                VelocityBody.translateFromRpc(rpcOdometry.getVelocityBody()),
                AngularVelocityBody.translateFromRpc(rpcOdometry.getAngularVelocityBody()),
                Covariance.translateFromRpc(rpcOdometry.getPoseCovariance()),
                Covariance.translateFromRpc(rpcOdometry.getVelocityCovariance()));
      }
    }


    public static class DistanceSensor {
      private Float minimumDistanceM;
      private Float maximumDistanceM;
      private Float currentDistanceM;

      public DistanceSensor(Float minimumDistanceM, Float maximumDistanceM, Float currentDistanceM) {
        this.minimumDistanceM = minimumDistanceM;
        this.maximumDistanceM = maximumDistanceM;
        this.currentDistanceM = currentDistanceM;
      }
      public Float getMinimumDistanceM() {
        return minimumDistanceM;
      }
      public Float getMaximumDistanceM() {
        return maximumDistanceM;
      }
      public Float getCurrentDistanceM() {
        return currentDistanceM;
      }

      protected TelemetryProto.DistanceSensor rpcDistanceSensor() {
        return TelemetryProto.DistanceSensor.newBuilder()
          .setMinimumDistanceM(this.minimumDistanceM)
          .setMaximumDistanceM(this.maximumDistanceM)
          .setCurrentDistanceM(this.currentDistanceM)
          .build();
      }

      protected static DistanceSensor translateFromRpc(TelemetryProto.DistanceSensor rpcDistanceSensor) {
        return new DistanceSensor(
                rpcDistanceSensor.getMinimumDistanceM(),
                rpcDistanceSensor.getMaximumDistanceM(),
                rpcDistanceSensor.getCurrentDistanceM());
      }
    }


    public static class ScaledPressure {
      private Long timestampUs;
      private Float absolutePressureHpa;
      private Float differentialPressureHpa;
      private Float temperatureDeg;
      private Float differentialPressureTemperatureDeg;

      public ScaledPressure(Long timestampUs, Float absolutePressureHpa, Float differentialPressureHpa, Float temperatureDeg, Float differentialPressureTemperatureDeg) {
        this.timestampUs = timestampUs;
        this.absolutePressureHpa = absolutePressureHpa;
        this.differentialPressureHpa = differentialPressureHpa;
        this.temperatureDeg = temperatureDeg;
        this.differentialPressureTemperatureDeg = differentialPressureTemperatureDeg;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }
      public Float getAbsolutePressureHpa() {
        return absolutePressureHpa;
      }
      public Float getDifferentialPressureHpa() {
        return differentialPressureHpa;
      }
      public Float getTemperatureDeg() {
        return temperatureDeg;
      }
      public Float getDifferentialPressureTemperatureDeg() {
        return differentialPressureTemperatureDeg;
      }

      protected TelemetryProto.ScaledPressure rpcScaledPressure() {
        return TelemetryProto.ScaledPressure.newBuilder()
          .setTimestampUs(this.timestampUs)
          .setAbsolutePressureHpa(this.absolutePressureHpa)
          .setDifferentialPressureHpa(this.differentialPressureHpa)
          .setTemperatureDeg(this.temperatureDeg)
          .setDifferentialPressureTemperatureDeg(this.differentialPressureTemperatureDeg)
          .build();
      }

      protected static ScaledPressure translateFromRpc(TelemetryProto.ScaledPressure rpcScaledPressure) {
        return new ScaledPressure(
                rpcScaledPressure.getTimestampUs(),
                rpcScaledPressure.getAbsolutePressureHpa(),
                rpcScaledPressure.getDifferentialPressureHpa(),
                rpcScaledPressure.getTemperatureDeg(),
                rpcScaledPressure.getDifferentialPressureTemperatureDeg());
      }
    }


    public static class PositionNed {
      private Float northM;
      private Float eastM;
      private Float downM;

      public PositionNed(Float northM, Float eastM, Float downM) {
        this.northM = northM;
        this.eastM = eastM;
        this.downM = downM;
      }
      public Float getNorthM() {
        return northM;
      }
      public Float getEastM() {
        return eastM;
      }
      public Float getDownM() {
        return downM;
      }

      protected TelemetryProto.PositionNed rpcPositionNed() {
        return TelemetryProto.PositionNed.newBuilder()
          .setNorthM(this.northM)
          .setEastM(this.eastM)
          .setDownM(this.downM)
          .build();
      }

      protected static PositionNed translateFromRpc(TelemetryProto.PositionNed rpcPositionNed) {
        return new PositionNed(
                rpcPositionNed.getNorthM(),
                rpcPositionNed.getEastM(),
                rpcPositionNed.getDownM());
      }
    }


    public static class VelocityNed {
      private Float northMS;
      private Float eastMS;
      private Float downMS;

      public VelocityNed(Float northMS, Float eastMS, Float downMS) {
        this.northMS = northMS;
        this.eastMS = eastMS;
        this.downMS = downMS;
      }
      public Float getNorthMS() {
        return northMS;
      }
      public Float getEastMS() {
        return eastMS;
      }
      public Float getDownMS() {
        return downMS;
      }

      protected TelemetryProto.VelocityNed rpcVelocityNed() {
        return TelemetryProto.VelocityNed.newBuilder()
          .setNorthMS(this.northMS)
          .setEastMS(this.eastMS)
          .setDownMS(this.downMS)
          .build();
      }

      protected static VelocityNed translateFromRpc(TelemetryProto.VelocityNed rpcVelocityNed) {
        return new VelocityNed(
                rpcVelocityNed.getNorthMS(),
                rpcVelocityNed.getEastMS(),
                rpcVelocityNed.getDownMS());
      }
    }


    public static class PositionVelocityNed {
      private PositionNed position;
      private VelocityNed velocity;

      public PositionVelocityNed(PositionNed position, VelocityNed velocity) {
        this.position = position;
        this.velocity = velocity;
      }
      public PositionNed getPosition() {
        return position;
      }
      public VelocityNed getVelocity() {
        return velocity;
      }

      protected TelemetryProto.PositionVelocityNed rpcPositionVelocityNed() {
        return TelemetryProto.PositionVelocityNed.newBuilder()
          .setPosition(this.position.rpcPositionNed())
          .setVelocity(this.velocity.rpcVelocityNed())
          .build();
      }

      protected static PositionVelocityNed translateFromRpc(TelemetryProto.PositionVelocityNed rpcPositionVelocityNed) {
        return new PositionVelocityNed(
                PositionNed.translateFromRpc(rpcPositionVelocityNed.getPosition()),
                VelocityNed.translateFromRpc(rpcPositionVelocityNed.getVelocity()));
      }
    }


    public static class GroundTruth {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;

      public GroundTruth(Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }

      protected TelemetryProto.GroundTruth rpcGroundTruth() {
        return TelemetryProto.GroundTruth.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .build();
      }

      protected static GroundTruth translateFromRpc(TelemetryProto.GroundTruth rpcGroundTruth) {
        return new GroundTruth(
                rpcGroundTruth.getLatitudeDeg(),
                rpcGroundTruth.getLongitudeDeg(),
                rpcGroundTruth.getAbsoluteAltitudeM());
      }
    }


    public static class FixedwingMetrics {
      private Float airspeedMS;
      private Float throttlePercentage;
      private Float climbRateMS;

      public FixedwingMetrics(Float airspeedMS, Float throttlePercentage, Float climbRateMS) {
        this.airspeedMS = airspeedMS;
        this.throttlePercentage = throttlePercentage;
        this.climbRateMS = climbRateMS;
      }
      public Float getAirspeedMS() {
        return airspeedMS;
      }
      public Float getThrottlePercentage() {
        return throttlePercentage;
      }
      public Float getClimbRateMS() {
        return climbRateMS;
      }

      protected TelemetryProto.FixedwingMetrics rpcFixedwingMetrics() {
        return TelemetryProto.FixedwingMetrics.newBuilder()
          .setAirspeedMS(this.airspeedMS)
          .setThrottlePercentage(this.throttlePercentage)
          .setClimbRateMS(this.climbRateMS)
          .build();
      }

      protected static FixedwingMetrics translateFromRpc(TelemetryProto.FixedwingMetrics rpcFixedwingMetrics) {
        return new FixedwingMetrics(
                rpcFixedwingMetrics.getAirspeedMS(),
                rpcFixedwingMetrics.getThrottlePercentage(),
                rpcFixedwingMetrics.getClimbRateMS());
      }
    }


    public static class AccelerationFrd {
      private Float forwardMS2;
      private Float rightMS2;
      private Float downMS2;

      public AccelerationFrd(Float forwardMS2, Float rightMS2, Float downMS2) {
        this.forwardMS2 = forwardMS2;
        this.rightMS2 = rightMS2;
        this.downMS2 = downMS2;
      }
      public Float getForwardMS2() {
        return forwardMS2;
      }
      public Float getRightMS2() {
        return rightMS2;
      }
      public Float getDownMS2() {
        return downMS2;
      }

      protected TelemetryProto.AccelerationFrd rpcAccelerationFrd() {
        return TelemetryProto.AccelerationFrd.newBuilder()
          .setForwardMS2(this.forwardMS2)
          .setRightMS2(this.rightMS2)
          .setDownMS2(this.downMS2)
          .build();
      }

      protected static AccelerationFrd translateFromRpc(TelemetryProto.AccelerationFrd rpcAccelerationFrd) {
        return new AccelerationFrd(
                rpcAccelerationFrd.getForwardMS2(),
                rpcAccelerationFrd.getRightMS2(),
                rpcAccelerationFrd.getDownMS2());
      }
    }


    public static class AngularVelocityFrd {
      private Float forwardRadS;
      private Float rightRadS;
      private Float downRadS;

      public AngularVelocityFrd(Float forwardRadS, Float rightRadS, Float downRadS) {
        this.forwardRadS = forwardRadS;
        this.rightRadS = rightRadS;
        this.downRadS = downRadS;
      }
      public Float getForwardRadS() {
        return forwardRadS;
      }
      public Float getRightRadS() {
        return rightRadS;
      }
      public Float getDownRadS() {
        return downRadS;
      }

      protected TelemetryProto.AngularVelocityFrd rpcAngularVelocityFrd() {
        return TelemetryProto.AngularVelocityFrd.newBuilder()
          .setForwardRadS(this.forwardRadS)
          .setRightRadS(this.rightRadS)
          .setDownRadS(this.downRadS)
          .build();
      }

      protected static AngularVelocityFrd translateFromRpc(TelemetryProto.AngularVelocityFrd rpcAngularVelocityFrd) {
        return new AngularVelocityFrd(
                rpcAngularVelocityFrd.getForwardRadS(),
                rpcAngularVelocityFrd.getRightRadS(),
                rpcAngularVelocityFrd.getDownRadS());
      }
    }


    public static class MagneticFieldFrd {
      private Float forwardGauss;
      private Float rightGauss;
      private Float downGauss;

      public MagneticFieldFrd(Float forwardGauss, Float rightGauss, Float downGauss) {
        this.forwardGauss = forwardGauss;
        this.rightGauss = rightGauss;
        this.downGauss = downGauss;
      }
      public Float getForwardGauss() {
        return forwardGauss;
      }
      public Float getRightGauss() {
        return rightGauss;
      }
      public Float getDownGauss() {
        return downGauss;
      }

      protected TelemetryProto.MagneticFieldFrd rpcMagneticFieldFrd() {
        return TelemetryProto.MagneticFieldFrd.newBuilder()
          .setForwardGauss(this.forwardGauss)
          .setRightGauss(this.rightGauss)
          .setDownGauss(this.downGauss)
          .build();
      }

      protected static MagneticFieldFrd translateFromRpc(TelemetryProto.MagneticFieldFrd rpcMagneticFieldFrd) {
        return new MagneticFieldFrd(
                rpcMagneticFieldFrd.getForwardGauss(),
                rpcMagneticFieldFrd.getRightGauss(),
                rpcMagneticFieldFrd.getDownGauss());
      }
    }


    public static class Imu {
      private AccelerationFrd accelerationFrd;
      private AngularVelocityFrd angularVelocityFrd;
      private MagneticFieldFrd magneticFieldFrd;
      private Float temperatureDegc;
      private Long timestampUs;

      public Imu(AccelerationFrd accelerationFrd, AngularVelocityFrd angularVelocityFrd, MagneticFieldFrd magneticFieldFrd, Float temperatureDegc, Long timestampUs) {
        this.accelerationFrd = accelerationFrd;
        this.angularVelocityFrd = angularVelocityFrd;
        this.magneticFieldFrd = magneticFieldFrd;
        this.temperatureDegc = temperatureDegc;
        this.timestampUs = timestampUs;
      }
      public AccelerationFrd getAccelerationFrd() {
        return accelerationFrd;
      }
      public AngularVelocityFrd getAngularVelocityFrd() {
        return angularVelocityFrd;
      }
      public MagneticFieldFrd getMagneticFieldFrd() {
        return magneticFieldFrd;
      }
      public Float getTemperatureDegc() {
        return temperatureDegc;
      }
      public Long getTimestampUs() {
        return timestampUs;
      }

      protected TelemetryProto.Imu rpcImu() {
        return TelemetryProto.Imu.newBuilder()
          .setAccelerationFrd(this.accelerationFrd.rpcAccelerationFrd())
          .setAngularVelocityFrd(this.angularVelocityFrd.rpcAngularVelocityFrd())
          .setMagneticFieldFrd(this.magneticFieldFrd.rpcMagneticFieldFrd())
          .setTemperatureDegc(this.temperatureDegc)
          .setTimestampUs(this.timestampUs)
          .build();
      }

      protected static Imu translateFromRpc(TelemetryProto.Imu rpcImu) {
        return new Imu(
                AccelerationFrd.translateFromRpc(rpcImu.getAccelerationFrd()),
                AngularVelocityFrd.translateFromRpc(rpcImu.getAngularVelocityFrd()),
                MagneticFieldFrd.translateFromRpc(rpcImu.getMagneticFieldFrd()),
                rpcImu.getTemperatureDegc(),
                rpcImu.getTimestampUs());
      }
    }


    public static class GpsGlobalOrigin {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float altitudeM;

      public GpsGlobalOrigin(Double latitudeDeg, Double longitudeDeg, Float altitudeM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.altitudeM = altitudeM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAltitudeM() {
        return altitudeM;
      }

      protected TelemetryProto.GpsGlobalOrigin rpcGpsGlobalOrigin() {
        return TelemetryProto.GpsGlobalOrigin.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAltitudeM(this.altitudeM)
          .build();
      }

      protected static GpsGlobalOrigin translateFromRpc(TelemetryProto.GpsGlobalOrigin rpcGpsGlobalOrigin) {
        return new GpsGlobalOrigin(
                rpcGpsGlobalOrigin.getLatitudeDeg(),
                rpcGpsGlobalOrigin.getLongitudeDeg(),
                rpcGpsGlobalOrigin.getAltitudeM());
      }
    }


    public static class TelemetryResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_TIMEOUT;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected TelemetryProto.TelemetryResult.Result rpcResult() {
              return TelemetryProto.TelemetryResult.Result.RESULT_UNSUPPORTED;
            }
          };

          protected static Result translateFromRpc(TelemetryProto.TelemetryResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
            }
          }

          protected abstract TelemetryProto.TelemetryResult.Result rpcResult();
        }

      public TelemetryResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected TelemetryProto.TelemetryResult rpcTelemetryResult() {
        return TelemetryProto.TelemetryResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static TelemetryResult translateFromRpc(TelemetryProto.TelemetryResult rpcTelemetryResult) {
        return new TelemetryResult(
                Result.translateFromRpc(rpcTelemetryResult.getResult()),
                rpcTelemetryResult.getResultStr());
      }
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Position> positionProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Position> position = positionProcessor.onBackpressureBuffer().share();;
    private volatile boolean isPositionInitialized = false;

    private void processPosition() {
      TelemetryProto.SubscribePositionRequest request = TelemetryProto.SubscribePositionRequest.newBuilder()
        .build();

      stub.subscribePosition(request, new StreamObserver<TelemetryProto.PositionResponse>() {

        @Override
        public void onNext(TelemetryProto.PositionResponse value) {
          positionProcessor.onNext(Position.translateFromRpc(value.getPosition()));
        }

        @Override
        public void onError(Throwable t) {
          positionProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          positionProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Position> getPosition() {
      if (!isPositionInitialized) {
        synchronized (this) {
          if (!isPositionInitialized) {
            MavsdkEventQueue.executor().execute(() -> processPosition());
            isPositionInitialized = true;
          }
        }
      }
      return position;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Position> homeProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Position> home = homeProcessor.onBackpressureBuffer().share();;
    private volatile boolean isHomeInitialized = false;

    private void processHome() {
      TelemetryProto.SubscribeHomeRequest request = TelemetryProto.SubscribeHomeRequest.newBuilder()
        .build();

      stub.subscribeHome(request, new StreamObserver<TelemetryProto.HomeResponse>() {

        @Override
        public void onNext(TelemetryProto.HomeResponse value) {
          homeProcessor.onNext(Position.translateFromRpc(value.getHome()));
        }

        @Override
        public void onError(Throwable t) {
          homeProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          homeProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Position> getHome() {
      if (!isHomeInitialized) {
        synchronized (this) {
          if (!isHomeInitialized) {
            MavsdkEventQueue.executor().execute(() -> processHome());
            isHomeInitialized = true;
          }
        }
      }
      return home;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> inAirProcessor = PublishProcessor.create();
    private final Flowable<Boolean> inAir = inAirProcessor.onBackpressureBuffer().share();;
    private volatile boolean isInAirInitialized = false;

    private void processInAir() {
      TelemetryProto.SubscribeInAirRequest request = TelemetryProto.SubscribeInAirRequest.newBuilder()
        .build();

      stub.subscribeInAir(request, new StreamObserver<TelemetryProto.InAirResponse>() {

        @Override
        public void onNext(TelemetryProto.InAirResponse value) {
          inAirProcessor.onNext(value.getIsInAir());
        }

        @Override
        public void onError(Throwable t) {
          inAirProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          inAirProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getInAir() {
      if (!isInAirInitialized) {
        synchronized (this) {
          if (!isInAirInitialized) {
            MavsdkEventQueue.executor().execute(() -> processInAir());
            isInAirInitialized = true;
          }
        }
      }
      return inAir;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.LandedState> landedStateProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.LandedState> landedState = landedStateProcessor.onBackpressureBuffer().share();;
    private volatile boolean isLandedStateInitialized = false;

    private void processLandedState() {
      TelemetryProto.SubscribeLandedStateRequest request = TelemetryProto.SubscribeLandedStateRequest.newBuilder()
        .build();

      stub.subscribeLandedState(request, new StreamObserver<TelemetryProto.LandedStateResponse>() {

        @Override
        public void onNext(TelemetryProto.LandedStateResponse value) {
          landedStateProcessor.onNext(LandedState.translateFromRpc(value.getLandedState()));
        }

        @Override
        public void onError(Throwable t) {
          landedStateProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          landedStateProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.LandedState> getLandedState() {
      if (!isLandedStateInitialized) {
        synchronized (this) {
          if (!isLandedStateInitialized) {
            MavsdkEventQueue.executor().execute(() -> processLandedState());
            isLandedStateInitialized = true;
          }
        }
      }
      return landedState;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> armedProcessor = PublishProcessor.create();
    private final Flowable<Boolean> armed = armedProcessor.onBackpressureBuffer().share();;
    private volatile boolean isArmedInitialized = false;

    private void processArmed() {
      TelemetryProto.SubscribeArmedRequest request = TelemetryProto.SubscribeArmedRequest.newBuilder()
        .build();

      stub.subscribeArmed(request, new StreamObserver<TelemetryProto.ArmedResponse>() {

        @Override
        public void onNext(TelemetryProto.ArmedResponse value) {
          armedProcessor.onNext(value.getIsArmed());
        }

        @Override
        public void onError(Throwable t) {
          armedProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          armedProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getArmed() {
      if (!isArmedInitialized) {
        synchronized (this) {
          if (!isArmedInitialized) {
            MavsdkEventQueue.executor().execute(() -> processArmed());
            isArmedInitialized = true;
          }
        }
      }
      return armed;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.VtolState> vtolStateProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.VtolState> vtolState = vtolStateProcessor.onBackpressureBuffer().share();;
    private volatile boolean isVtolStateInitialized = false;

    private void processVtolState() {
      TelemetryProto.SubscribeVtolStateRequest request = TelemetryProto.SubscribeVtolStateRequest.newBuilder()
        .build();

      stub.subscribeVtolState(request, new StreamObserver<TelemetryProto.VtolStateResponse>() {

        @Override
        public void onNext(TelemetryProto.VtolStateResponse value) {
          vtolStateProcessor.onNext(VtolState.translateFromRpc(value.getVtolState()));
        }

        @Override
        public void onError(Throwable t) {
          vtolStateProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          vtolStateProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.VtolState> getVtolState() {
      if (!isVtolStateInitialized) {
        synchronized (this) {
          if (!isVtolStateInitialized) {
            MavsdkEventQueue.executor().execute(() -> processVtolState());
            isVtolStateInitialized = true;
          }
        }
      }
      return vtolState;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Quaternion> attitudeQuaternionProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Quaternion> attitudeQuaternion = attitudeQuaternionProcessor.onBackpressureBuffer().share();;
    private volatile boolean isAttitudeQuaternionInitialized = false;

    private void processAttitudeQuaternion() {
      TelemetryProto.SubscribeAttitudeQuaternionRequest request = TelemetryProto.SubscribeAttitudeQuaternionRequest.newBuilder()
        .build();

      stub.subscribeAttitudeQuaternion(request, new StreamObserver<TelemetryProto.AttitudeQuaternionResponse>() {

        @Override
        public void onNext(TelemetryProto.AttitudeQuaternionResponse value) {
          attitudeQuaternionProcessor.onNext(Quaternion.translateFromRpc(value.getAttitudeQuaternion()));
        }

        @Override
        public void onError(Throwable t) {
          attitudeQuaternionProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          attitudeQuaternionProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Quaternion> getAttitudeQuaternion() {
      if (!isAttitudeQuaternionInitialized) {
        synchronized (this) {
          if (!isAttitudeQuaternionInitialized) {
            MavsdkEventQueue.executor().execute(() -> processAttitudeQuaternion());
            isAttitudeQuaternionInitialized = true;
          }
        }
      }
      return attitudeQuaternion;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.EulerAngle> attitudeEulerProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.EulerAngle> attitudeEuler = attitudeEulerProcessor.onBackpressureBuffer().share();;
    private volatile boolean isAttitudeEulerInitialized = false;

    private void processAttitudeEuler() {
      TelemetryProto.SubscribeAttitudeEulerRequest request = TelemetryProto.SubscribeAttitudeEulerRequest.newBuilder()
        .build();

      stub.subscribeAttitudeEuler(request, new StreamObserver<TelemetryProto.AttitudeEulerResponse>() {

        @Override
        public void onNext(TelemetryProto.AttitudeEulerResponse value) {
          attitudeEulerProcessor.onNext(EulerAngle.translateFromRpc(value.getAttitudeEuler()));
        }

        @Override
        public void onError(Throwable t) {
          attitudeEulerProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          attitudeEulerProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.EulerAngle> getAttitudeEuler() {
      if (!isAttitudeEulerInitialized) {
        synchronized (this) {
          if (!isAttitudeEulerInitialized) {
            MavsdkEventQueue.executor().execute(() -> processAttitudeEuler());
            isAttitudeEulerInitialized = true;
          }
        }
      }
      return attitudeEuler;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.AngularVelocityBody> attitudeAngularVelocityBodyProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.AngularVelocityBody> attitudeAngularVelocityBody = attitudeAngularVelocityBodyProcessor.onBackpressureBuffer().share();;
    private volatile boolean isAttitudeAngularVelocityBodyInitialized = false;

    private void processAttitudeAngularVelocityBody() {
      TelemetryProto.SubscribeAttitudeAngularVelocityBodyRequest request = TelemetryProto.SubscribeAttitudeAngularVelocityBodyRequest.newBuilder()
        .build();

      stub.subscribeAttitudeAngularVelocityBody(request, new StreamObserver<TelemetryProto.AttitudeAngularVelocityBodyResponse>() {

        @Override
        public void onNext(TelemetryProto.AttitudeAngularVelocityBodyResponse value) {
          attitudeAngularVelocityBodyProcessor.onNext(AngularVelocityBody.translateFromRpc(value.getAttitudeAngularVelocityBody()));
        }

        @Override
        public void onError(Throwable t) {
          attitudeAngularVelocityBodyProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          attitudeAngularVelocityBodyProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.AngularVelocityBody> getAttitudeAngularVelocityBody() {
      if (!isAttitudeAngularVelocityBodyInitialized) {
        synchronized (this) {
          if (!isAttitudeAngularVelocityBodyInitialized) {
            MavsdkEventQueue.executor().execute(() -> processAttitudeAngularVelocityBody());
            isAttitudeAngularVelocityBodyInitialized = true;
          }
        }
      }
      return attitudeAngularVelocityBody;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Quaternion> cameraAttitudeQuaternionProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Quaternion> cameraAttitudeQuaternion = cameraAttitudeQuaternionProcessor.onBackpressureBuffer().share();;
    private volatile boolean isCameraAttitudeQuaternionInitialized = false;

    private void processCameraAttitudeQuaternion() {
      TelemetryProto.SubscribeCameraAttitudeQuaternionRequest request = TelemetryProto.SubscribeCameraAttitudeQuaternionRequest.newBuilder()
        .build();

      stub.subscribeCameraAttitudeQuaternion(request, new StreamObserver<TelemetryProto.CameraAttitudeQuaternionResponse>() {

        @Override
        public void onNext(TelemetryProto.CameraAttitudeQuaternionResponse value) {
          cameraAttitudeQuaternionProcessor.onNext(Quaternion.translateFromRpc(value.getAttitudeQuaternion()));
        }

        @Override
        public void onError(Throwable t) {
          cameraAttitudeQuaternionProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          cameraAttitudeQuaternionProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Quaternion> getCameraAttitudeQuaternion() {
      if (!isCameraAttitudeQuaternionInitialized) {
        synchronized (this) {
          if (!isCameraAttitudeQuaternionInitialized) {
            MavsdkEventQueue.executor().execute(() -> processCameraAttitudeQuaternion());
            isCameraAttitudeQuaternionInitialized = true;
          }
        }
      }
      return cameraAttitudeQuaternion;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.EulerAngle> cameraAttitudeEulerProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.EulerAngle> cameraAttitudeEuler = cameraAttitudeEulerProcessor.onBackpressureBuffer().share();;
    private volatile boolean isCameraAttitudeEulerInitialized = false;

    private void processCameraAttitudeEuler() {
      TelemetryProto.SubscribeCameraAttitudeEulerRequest request = TelemetryProto.SubscribeCameraAttitudeEulerRequest.newBuilder()
        .build();

      stub.subscribeCameraAttitudeEuler(request, new StreamObserver<TelemetryProto.CameraAttitudeEulerResponse>() {

        @Override
        public void onNext(TelemetryProto.CameraAttitudeEulerResponse value) {
          cameraAttitudeEulerProcessor.onNext(EulerAngle.translateFromRpc(value.getAttitudeEuler()));
        }

        @Override
        public void onError(Throwable t) {
          cameraAttitudeEulerProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          cameraAttitudeEulerProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.EulerAngle> getCameraAttitudeEuler() {
      if (!isCameraAttitudeEulerInitialized) {
        synchronized (this) {
          if (!isCameraAttitudeEulerInitialized) {
            MavsdkEventQueue.executor().execute(() -> processCameraAttitudeEuler());
            isCameraAttitudeEulerInitialized = true;
          }
        }
      }
      return cameraAttitudeEuler;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.VelocityNed> velocityNedProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.VelocityNed> velocityNed = velocityNedProcessor.onBackpressureBuffer().share();;
    private volatile boolean isVelocityNedInitialized = false;

    private void processVelocityNed() {
      TelemetryProto.SubscribeVelocityNedRequest request = TelemetryProto.SubscribeVelocityNedRequest.newBuilder()
        .build();

      stub.subscribeVelocityNed(request, new StreamObserver<TelemetryProto.VelocityNedResponse>() {

        @Override
        public void onNext(TelemetryProto.VelocityNedResponse value) {
          velocityNedProcessor.onNext(VelocityNed.translateFromRpc(value.getVelocityNed()));
        }

        @Override
        public void onError(Throwable t) {
          velocityNedProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          velocityNedProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.VelocityNed> getVelocityNed() {
      if (!isVelocityNedInitialized) {
        synchronized (this) {
          if (!isVelocityNedInitialized) {
            MavsdkEventQueue.executor().execute(() -> processVelocityNed());
            isVelocityNedInitialized = true;
          }
        }
      }
      return velocityNed;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.GpsInfo> gpsInfoProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.GpsInfo> gpsInfo = gpsInfoProcessor.onBackpressureBuffer().share();;
    private volatile boolean isGpsInfoInitialized = false;

    private void processGpsInfo() {
      TelemetryProto.SubscribeGpsInfoRequest request = TelemetryProto.SubscribeGpsInfoRequest.newBuilder()
        .build();

      stub.subscribeGpsInfo(request, new StreamObserver<TelemetryProto.GpsInfoResponse>() {

        @Override
        public void onNext(TelemetryProto.GpsInfoResponse value) {
          gpsInfoProcessor.onNext(GpsInfo.translateFromRpc(value.getGpsInfo()));
        }

        @Override
        public void onError(Throwable t) {
          gpsInfoProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          gpsInfoProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.GpsInfo> getGpsInfo() {
      if (!isGpsInfoInitialized) {
        synchronized (this) {
          if (!isGpsInfoInitialized) {
            MavsdkEventQueue.executor().execute(() -> processGpsInfo());
            isGpsInfoInitialized = true;
          }
        }
      }
      return gpsInfo;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.RawGps> rawGpsProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.RawGps> rawGps = rawGpsProcessor.onBackpressureBuffer().share();;
    private volatile boolean isRawGpsInitialized = false;

    private void processRawGps() {
      TelemetryProto.SubscribeRawGpsRequest request = TelemetryProto.SubscribeRawGpsRequest.newBuilder()
        .build();

      stub.subscribeRawGps(request, new StreamObserver<TelemetryProto.RawGpsResponse>() {

        @Override
        public void onNext(TelemetryProto.RawGpsResponse value) {
          rawGpsProcessor.onNext(RawGps.translateFromRpc(value.getRawGps()));
        }

        @Override
        public void onError(Throwable t) {
          rawGpsProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          rawGpsProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.RawGps> getRawGps() {
      if (!isRawGpsInitialized) {
        synchronized (this) {
          if (!isRawGpsInitialized) {
            MavsdkEventQueue.executor().execute(() -> processRawGps());
            isRawGpsInitialized = true;
          }
        }
      }
      return rawGps;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Battery> batteryProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Battery> battery = batteryProcessor.onBackpressureBuffer().share();;
    private volatile boolean isBatteryInitialized = false;

    private void processBattery() {
      TelemetryProto.SubscribeBatteryRequest request = TelemetryProto.SubscribeBatteryRequest.newBuilder()
        .build();

      stub.subscribeBattery(request, new StreamObserver<TelemetryProto.BatteryResponse>() {

        @Override
        public void onNext(TelemetryProto.BatteryResponse value) {
          batteryProcessor.onNext(Battery.translateFromRpc(value.getBattery()));
        }

        @Override
        public void onError(Throwable t) {
          batteryProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          batteryProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Battery> getBattery() {
      if (!isBatteryInitialized) {
        synchronized (this) {
          if (!isBatteryInitialized) {
            MavsdkEventQueue.executor().execute(() -> processBattery());
            isBatteryInitialized = true;
          }
        }
      }
      return battery;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.FlightMode> flightModeProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.FlightMode> flightMode = flightModeProcessor.onBackpressureBuffer().share();;
    private volatile boolean isFlightModeInitialized = false;

    private void processFlightMode() {
      TelemetryProto.SubscribeFlightModeRequest request = TelemetryProto.SubscribeFlightModeRequest.newBuilder()
        .build();

      stub.subscribeFlightMode(request, new StreamObserver<TelemetryProto.FlightModeResponse>() {

        @Override
        public void onNext(TelemetryProto.FlightModeResponse value) {
          flightModeProcessor.onNext(FlightMode.translateFromRpc(value.getFlightMode()));
        }

        @Override
        public void onError(Throwable t) {
          flightModeProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          flightModeProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.FlightMode> getFlightMode() {
      if (!isFlightModeInitialized) {
        synchronized (this) {
          if (!isFlightModeInitialized) {
            MavsdkEventQueue.executor().execute(() -> processFlightMode());
            isFlightModeInitialized = true;
          }
        }
      }
      return flightMode;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Health> healthProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Health> health = healthProcessor.onBackpressureBuffer().share();;
    private volatile boolean isHealthInitialized = false;

    private void processHealth() {
      TelemetryProto.SubscribeHealthRequest request = TelemetryProto.SubscribeHealthRequest.newBuilder()
        .build();

      stub.subscribeHealth(request, new StreamObserver<TelemetryProto.HealthResponse>() {

        @Override
        public void onNext(TelemetryProto.HealthResponse value) {
          healthProcessor.onNext(Health.translateFromRpc(value.getHealth()));
        }

        @Override
        public void onError(Throwable t) {
          healthProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          healthProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Health> getHealth() {
      if (!isHealthInitialized) {
        synchronized (this) {
          if (!isHealthInitialized) {
            MavsdkEventQueue.executor().execute(() -> processHealth());
            isHealthInitialized = true;
          }
        }
      }
      return health;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.RcStatus> rcStatusProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.RcStatus> rcStatus = rcStatusProcessor.onBackpressureBuffer().share();;
    private volatile boolean isRcStatusInitialized = false;

    private void processRcStatus() {
      TelemetryProto.SubscribeRcStatusRequest request = TelemetryProto.SubscribeRcStatusRequest.newBuilder()
        .build();

      stub.subscribeRcStatus(request, new StreamObserver<TelemetryProto.RcStatusResponse>() {

        @Override
        public void onNext(TelemetryProto.RcStatusResponse value) {
          rcStatusProcessor.onNext(RcStatus.translateFromRpc(value.getRcStatus()));
        }

        @Override
        public void onError(Throwable t) {
          rcStatusProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          rcStatusProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.RcStatus> getRcStatus() {
      if (!isRcStatusInitialized) {
        synchronized (this) {
          if (!isRcStatusInitialized) {
            MavsdkEventQueue.executor().execute(() -> processRcStatus());
            isRcStatusInitialized = true;
          }
        }
      }
      return rcStatus;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.StatusText> statusTextProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.StatusText> statusText = statusTextProcessor.onBackpressureBuffer().share();;
    private volatile boolean isStatusTextInitialized = false;

    private void processStatusText() {
      TelemetryProto.SubscribeStatusTextRequest request = TelemetryProto.SubscribeStatusTextRequest.newBuilder()
        .build();

      stub.subscribeStatusText(request, new StreamObserver<TelemetryProto.StatusTextResponse>() {

        @Override
        public void onNext(TelemetryProto.StatusTextResponse value) {
          statusTextProcessor.onNext(StatusText.translateFromRpc(value.getStatusText()));
        }

        @Override
        public void onError(Throwable t) {
          statusTextProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          statusTextProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.StatusText> getStatusText() {
      if (!isStatusTextInitialized) {
        synchronized (this) {
          if (!isStatusTextInitialized) {
            MavsdkEventQueue.executor().execute(() -> processStatusText());
            isStatusTextInitialized = true;
          }
        }
      }
      return statusText;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.ActuatorControlTarget> actuatorControlTargetProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.ActuatorControlTarget> actuatorControlTarget = actuatorControlTargetProcessor.onBackpressureBuffer().share();;
    private volatile boolean isActuatorControlTargetInitialized = false;

    private void processActuatorControlTarget() {
      TelemetryProto.SubscribeActuatorControlTargetRequest request = TelemetryProto.SubscribeActuatorControlTargetRequest.newBuilder()
        .build();

      stub.subscribeActuatorControlTarget(request, new StreamObserver<TelemetryProto.ActuatorControlTargetResponse>() {

        @Override
        public void onNext(TelemetryProto.ActuatorControlTargetResponse value) {
          actuatorControlTargetProcessor.onNext(ActuatorControlTarget.translateFromRpc(value.getActuatorControlTarget()));
        }

        @Override
        public void onError(Throwable t) {
          actuatorControlTargetProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          actuatorControlTargetProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.ActuatorControlTarget> getActuatorControlTarget() {
      if (!isActuatorControlTargetInitialized) {
        synchronized (this) {
          if (!isActuatorControlTargetInitialized) {
            MavsdkEventQueue.executor().execute(() -> processActuatorControlTarget());
            isActuatorControlTargetInitialized = true;
          }
        }
      }
      return actuatorControlTarget;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.ActuatorOutputStatus> actuatorOutputStatusProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.ActuatorOutputStatus> actuatorOutputStatus = actuatorOutputStatusProcessor.onBackpressureBuffer().share();;
    private volatile boolean isActuatorOutputStatusInitialized = false;

    private void processActuatorOutputStatus() {
      TelemetryProto.SubscribeActuatorOutputStatusRequest request = TelemetryProto.SubscribeActuatorOutputStatusRequest.newBuilder()
        .build();

      stub.subscribeActuatorOutputStatus(request, new StreamObserver<TelemetryProto.ActuatorOutputStatusResponse>() {

        @Override
        public void onNext(TelemetryProto.ActuatorOutputStatusResponse value) {
          actuatorOutputStatusProcessor.onNext(ActuatorOutputStatus.translateFromRpc(value.getActuatorOutputStatus()));
        }

        @Override
        public void onError(Throwable t) {
          actuatorOutputStatusProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          actuatorOutputStatusProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.ActuatorOutputStatus> getActuatorOutputStatus() {
      if (!isActuatorOutputStatusInitialized) {
        synchronized (this) {
          if (!isActuatorOutputStatusInitialized) {
            MavsdkEventQueue.executor().execute(() -> processActuatorOutputStatus());
            isActuatorOutputStatusInitialized = true;
          }
        }
      }
      return actuatorOutputStatus;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Odometry> odometryProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Odometry> odometry = odometryProcessor.onBackpressureBuffer().share();;
    private volatile boolean isOdometryInitialized = false;

    private void processOdometry() {
      TelemetryProto.SubscribeOdometryRequest request = TelemetryProto.SubscribeOdometryRequest.newBuilder()
        .build();

      stub.subscribeOdometry(request, new StreamObserver<TelemetryProto.OdometryResponse>() {

        @Override
        public void onNext(TelemetryProto.OdometryResponse value) {
          odometryProcessor.onNext(Odometry.translateFromRpc(value.getOdometry()));
        }

        @Override
        public void onError(Throwable t) {
          odometryProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          odometryProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Odometry> getOdometry() {
      if (!isOdometryInitialized) {
        synchronized (this) {
          if (!isOdometryInitialized) {
            MavsdkEventQueue.executor().execute(() -> processOdometry());
            isOdometryInitialized = true;
          }
        }
      }
      return odometry;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.PositionVelocityNed> positionVelocityNedProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.PositionVelocityNed> positionVelocityNed = positionVelocityNedProcessor.onBackpressureBuffer().share();;
    private volatile boolean isPositionVelocityNedInitialized = false;

    private void processPositionVelocityNed() {
      TelemetryProto.SubscribePositionVelocityNedRequest request = TelemetryProto.SubscribePositionVelocityNedRequest.newBuilder()
        .build();

      stub.subscribePositionVelocityNed(request, new StreamObserver<TelemetryProto.PositionVelocityNedResponse>() {

        @Override
        public void onNext(TelemetryProto.PositionVelocityNedResponse value) {
          positionVelocityNedProcessor.onNext(PositionVelocityNed.translateFromRpc(value.getPositionVelocityNed()));
        }

        @Override
        public void onError(Throwable t) {
          positionVelocityNedProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          positionVelocityNedProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.PositionVelocityNed> getPositionVelocityNed() {
      if (!isPositionVelocityNedInitialized) {
        synchronized (this) {
          if (!isPositionVelocityNedInitialized) {
            MavsdkEventQueue.executor().execute(() -> processPositionVelocityNed());
            isPositionVelocityNedInitialized = true;
          }
        }
      }
      return positionVelocityNed;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.GroundTruth> groundTruthProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.GroundTruth> groundTruth = groundTruthProcessor.onBackpressureBuffer().share();;
    private volatile boolean isGroundTruthInitialized = false;

    private void processGroundTruth() {
      TelemetryProto.SubscribeGroundTruthRequest request = TelemetryProto.SubscribeGroundTruthRequest.newBuilder()
        .build();

      stub.subscribeGroundTruth(request, new StreamObserver<TelemetryProto.GroundTruthResponse>() {

        @Override
        public void onNext(TelemetryProto.GroundTruthResponse value) {
          groundTruthProcessor.onNext(GroundTruth.translateFromRpc(value.getGroundTruth()));
        }

        @Override
        public void onError(Throwable t) {
          groundTruthProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          groundTruthProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.GroundTruth> getGroundTruth() {
      if (!isGroundTruthInitialized) {
        synchronized (this) {
          if (!isGroundTruthInitialized) {
            MavsdkEventQueue.executor().execute(() -> processGroundTruth());
            isGroundTruthInitialized = true;
          }
        }
      }
      return groundTruth;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.FixedwingMetrics> fixedwingMetricsProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.FixedwingMetrics> fixedwingMetrics = fixedwingMetricsProcessor.onBackpressureBuffer().share();;
    private volatile boolean isFixedwingMetricsInitialized = false;

    private void processFixedwingMetrics() {
      TelemetryProto.SubscribeFixedwingMetricsRequest request = TelemetryProto.SubscribeFixedwingMetricsRequest.newBuilder()
        .build();

      stub.subscribeFixedwingMetrics(request, new StreamObserver<TelemetryProto.FixedwingMetricsResponse>() {

        @Override
        public void onNext(TelemetryProto.FixedwingMetricsResponse value) {
          fixedwingMetricsProcessor.onNext(FixedwingMetrics.translateFromRpc(value.getFixedwingMetrics()));
        }

        @Override
        public void onError(Throwable t) {
          fixedwingMetricsProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          fixedwingMetricsProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.FixedwingMetrics> getFixedwingMetrics() {
      if (!isFixedwingMetricsInitialized) {
        synchronized (this) {
          if (!isFixedwingMetricsInitialized) {
            MavsdkEventQueue.executor().execute(() -> processFixedwingMetrics());
            isFixedwingMetricsInitialized = true;
          }
        }
      }
      return fixedwingMetrics;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Imu> imuProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Imu> imu = imuProcessor.onBackpressureBuffer().share();;
    private volatile boolean isImuInitialized = false;

    private void processImu() {
      TelemetryProto.SubscribeImuRequest request = TelemetryProto.SubscribeImuRequest.newBuilder()
        .build();

      stub.subscribeImu(request, new StreamObserver<TelemetryProto.ImuResponse>() {

        @Override
        public void onNext(TelemetryProto.ImuResponse value) {
          imuProcessor.onNext(Imu.translateFromRpc(value.getImu()));
        }

        @Override
        public void onError(Throwable t) {
          imuProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          imuProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Imu> getImu() {
      if (!isImuInitialized) {
        synchronized (this) {
          if (!isImuInitialized) {
            MavsdkEventQueue.executor().execute(() -> processImu());
            isImuInitialized = true;
          }
        }
      }
      return imu;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Imu> scaledImuProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Imu> scaledImu = scaledImuProcessor.onBackpressureBuffer().share();;
    private volatile boolean isScaledImuInitialized = false;

    private void processScaledImu() {
      TelemetryProto.SubscribeScaledImuRequest request = TelemetryProto.SubscribeScaledImuRequest.newBuilder()
        .build();

      stub.subscribeScaledImu(request, new StreamObserver<TelemetryProto.ScaledImuResponse>() {

        @Override
        public void onNext(TelemetryProto.ScaledImuResponse value) {
          scaledImuProcessor.onNext(Imu.translateFromRpc(value.getImu()));
        }

        @Override
        public void onError(Throwable t) {
          scaledImuProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          scaledImuProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Imu> getScaledImu() {
      if (!isScaledImuInitialized) {
        synchronized (this) {
          if (!isScaledImuInitialized) {
            MavsdkEventQueue.executor().execute(() -> processScaledImu());
            isScaledImuInitialized = true;
          }
        }
      }
      return scaledImu;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Imu> rawImuProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Imu> rawImu = rawImuProcessor.onBackpressureBuffer().share();;
    private volatile boolean isRawImuInitialized = false;

    private void processRawImu() {
      TelemetryProto.SubscribeRawImuRequest request = TelemetryProto.SubscribeRawImuRequest.newBuilder()
        .build();

      stub.subscribeRawImu(request, new StreamObserver<TelemetryProto.RawImuResponse>() {

        @Override
        public void onNext(TelemetryProto.RawImuResponse value) {
          rawImuProcessor.onNext(Imu.translateFromRpc(value.getImu()));
        }

        @Override
        public void onError(Throwable t) {
          rawImuProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          rawImuProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Imu> getRawImu() {
      if (!isRawImuInitialized) {
        synchronized (this) {
          if (!isRawImuInitialized) {
            MavsdkEventQueue.executor().execute(() -> processRawImu());
            isRawImuInitialized = true;
          }
        }
      }
      return rawImu;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> healthAllOkProcessor = PublishProcessor.create();
    private final Flowable<Boolean> healthAllOk = healthAllOkProcessor.onBackpressureBuffer().share();;
    private volatile boolean isHealthAllOkInitialized = false;

    private void processHealthAllOk() {
      TelemetryProto.SubscribeHealthAllOkRequest request = TelemetryProto.SubscribeHealthAllOkRequest.newBuilder()
        .build();

      stub.subscribeHealthAllOk(request, new StreamObserver<TelemetryProto.HealthAllOkResponse>() {

        @Override
        public void onNext(TelemetryProto.HealthAllOkResponse value) {
          healthAllOkProcessor.onNext(value.getIsHealthAllOk());
        }

        @Override
        public void onError(Throwable t) {
          healthAllOkProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          healthAllOkProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getHealthAllOk() {
      if (!isHealthAllOkInitialized) {
        synchronized (this) {
          if (!isHealthAllOkInitialized) {
            MavsdkEventQueue.executor().execute(() -> processHealthAllOk());
            isHealthAllOkInitialized = true;
          }
        }
      }
      return healthAllOk;
    }



    // Infinite stream
    private final FlowableProcessor<Long> unixEpochTimeProcessor = PublishProcessor.create();
    private final Flowable<Long> unixEpochTime = unixEpochTimeProcessor.onBackpressureBuffer().share();;
    private volatile boolean isUnixEpochTimeInitialized = false;

    private void processUnixEpochTime() {
      TelemetryProto.SubscribeUnixEpochTimeRequest request = TelemetryProto.SubscribeUnixEpochTimeRequest.newBuilder()
        .build();

      stub.subscribeUnixEpochTime(request, new StreamObserver<TelemetryProto.UnixEpochTimeResponse>() {

        @Override
        public void onNext(TelemetryProto.UnixEpochTimeResponse value) {
          unixEpochTimeProcessor.onNext(value.getTimeUs());
        }

        @Override
        public void onError(Throwable t) {
          unixEpochTimeProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          unixEpochTimeProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Long> getUnixEpochTime() {
      if (!isUnixEpochTimeInitialized) {
        synchronized (this) {
          if (!isUnixEpochTimeInitialized) {
            MavsdkEventQueue.executor().execute(() -> processUnixEpochTime());
            isUnixEpochTimeInitialized = true;
          }
        }
      }
      return unixEpochTime;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.DistanceSensor> distanceSensorProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.DistanceSensor> distanceSensor = distanceSensorProcessor.onBackpressureBuffer().share();;
    private volatile boolean isDistanceSensorInitialized = false;

    private void processDistanceSensor() {
      TelemetryProto.SubscribeDistanceSensorRequest request = TelemetryProto.SubscribeDistanceSensorRequest.newBuilder()
        .build();

      stub.subscribeDistanceSensor(request, new StreamObserver<TelemetryProto.DistanceSensorResponse>() {

        @Override
        public void onNext(TelemetryProto.DistanceSensorResponse value) {
          distanceSensorProcessor.onNext(DistanceSensor.translateFromRpc(value.getDistanceSensor()));
        }

        @Override
        public void onError(Throwable t) {
          distanceSensorProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          distanceSensorProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.DistanceSensor> getDistanceSensor() {
      if (!isDistanceSensorInitialized) {
        synchronized (this) {
          if (!isDistanceSensorInitialized) {
            MavsdkEventQueue.executor().execute(() -> processDistanceSensor());
            isDistanceSensorInitialized = true;
          }
        }
      }
      return distanceSensor;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.ScaledPressure> scaledPressureProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.ScaledPressure> scaledPressure = scaledPressureProcessor.onBackpressureBuffer().share();;
    private volatile boolean isScaledPressureInitialized = false;

    private void processScaledPressure() {
      TelemetryProto.SubscribeScaledPressureRequest request = TelemetryProto.SubscribeScaledPressureRequest.newBuilder()
        .build();

      stub.subscribeScaledPressure(request, new StreamObserver<TelemetryProto.ScaledPressureResponse>() {

        @Override
        public void onNext(TelemetryProto.ScaledPressureResponse value) {
          scaledPressureProcessor.onNext(ScaledPressure.translateFromRpc(value.getScaledPressure()));
        }

        @Override
        public void onError(Throwable t) {
          scaledPressureProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          scaledPressureProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.ScaledPressure> getScaledPressure() {
      if (!isScaledPressureInitialized) {
        synchronized (this) {
          if (!isScaledPressureInitialized) {
            MavsdkEventQueue.executor().execute(() -> processScaledPressure());
            isScaledPressureInitialized = true;
          }
        }
      }
      return scaledPressure;
    }



    // Infinite stream
    private final FlowableProcessor<Telemetry.Heading> headingProcessor = PublishProcessor.create();
    private final Flowable<Telemetry.Heading> heading = headingProcessor.onBackpressureBuffer().share();;
    private volatile boolean isHeadingInitialized = false;

    private void processHeading() {
      TelemetryProto.SubscribeHeadingRequest request = TelemetryProto.SubscribeHeadingRequest.newBuilder()
        .build();

      stub.subscribeHeading(request, new StreamObserver<TelemetryProto.HeadingResponse>() {

        @Override
        public void onNext(TelemetryProto.HeadingResponse value) {
          headingProcessor.onNext(Heading.translateFromRpc(value.getHeadingDeg()));
        }

        @Override
        public void onError(Throwable t) {
          headingProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          headingProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Telemetry.Heading> getHeading() {
      if (!isHeadingInitialized) {
        synchronized (this) {
          if (!isHeadingInitialized) {
            MavsdkEventQueue.executor().execute(() -> processHeading());
            isHeadingInitialized = true;
          }
        }
      }
      return heading;
    }


    @CheckReturnValue
    public Completable setRatePosition(@NonNull Double rateHz) {

      TelemetryProto.SetRatePositionRequest request = TelemetryProto.SetRatePositionRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRatePosition(request, new StreamObserver<TelemetryProto.SetRatePositionResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRatePositionResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateHome(@NonNull Double rateHz) {

      TelemetryProto.SetRateHomeRequest request = TelemetryProto.SetRateHomeRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateHome(request, new StreamObserver<TelemetryProto.SetRateHomeResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateHomeResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateInAir(@NonNull Double rateHz) {

      TelemetryProto.SetRateInAirRequest request = TelemetryProto.SetRateInAirRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateInAir(request, new StreamObserver<TelemetryProto.SetRateInAirResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateInAirResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateLandedState(@NonNull Double rateHz) {

      TelemetryProto.SetRateLandedStateRequest request = TelemetryProto.SetRateLandedStateRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateLandedState(request, new StreamObserver<TelemetryProto.SetRateLandedStateResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateLandedStateResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateVtolState(@NonNull Double rateHz) {

      TelemetryProto.SetRateVtolStateRequest request = TelemetryProto.SetRateVtolStateRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateVtolState(request, new StreamObserver<TelemetryProto.SetRateVtolStateResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateVtolStateResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateAttitude(@NonNull Double rateHz) {

      TelemetryProto.SetRateAttitudeRequest request = TelemetryProto.SetRateAttitudeRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateAttitude(request, new StreamObserver<TelemetryProto.SetRateAttitudeResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateAttitudeResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateCameraAttitude(@NonNull Double rateHz) {

      TelemetryProto.SetRateCameraAttitudeRequest request = TelemetryProto.SetRateCameraAttitudeRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateCameraAttitude(request, new StreamObserver<TelemetryProto.SetRateCameraAttitudeResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateCameraAttitudeResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateVelocityNed(@NonNull Double rateHz) {

      TelemetryProto.SetRateVelocityNedRequest request = TelemetryProto.SetRateVelocityNedRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateVelocityNed(request, new StreamObserver<TelemetryProto.SetRateVelocityNedResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateVelocityNedResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateGpsInfo(@NonNull Double rateHz) {

      TelemetryProto.SetRateGpsInfoRequest request = TelemetryProto.SetRateGpsInfoRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateGpsInfo(request, new StreamObserver<TelemetryProto.SetRateGpsInfoResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateGpsInfoResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateBattery(@NonNull Double rateHz) {

      TelemetryProto.SetRateBatteryRequest request = TelemetryProto.SetRateBatteryRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateBattery(request, new StreamObserver<TelemetryProto.SetRateBatteryResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateBatteryResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateRcStatus(@NonNull Double rateHz) {

      TelemetryProto.SetRateRcStatusRequest request = TelemetryProto.SetRateRcStatusRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateRcStatus(request, new StreamObserver<TelemetryProto.SetRateRcStatusResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateRcStatusResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateActuatorControlTarget(@NonNull Double rateHz) {

      TelemetryProto.SetRateActuatorControlTargetRequest request = TelemetryProto.SetRateActuatorControlTargetRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateActuatorControlTarget(request, new StreamObserver<TelemetryProto.SetRateActuatorControlTargetResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateActuatorControlTargetResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateActuatorOutputStatus(@NonNull Double rateHz) {

      TelemetryProto.SetRateActuatorOutputStatusRequest request = TelemetryProto.SetRateActuatorOutputStatusRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateActuatorOutputStatus(request, new StreamObserver<TelemetryProto.SetRateActuatorOutputStatusResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateActuatorOutputStatusResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateOdometry(@NonNull Double rateHz) {

      TelemetryProto.SetRateOdometryRequest request = TelemetryProto.SetRateOdometryRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateOdometry(request, new StreamObserver<TelemetryProto.SetRateOdometryResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateOdometryResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRatePositionVelocityNed(@NonNull Double rateHz) {

      TelemetryProto.SetRatePositionVelocityNedRequest request = TelemetryProto.SetRatePositionVelocityNedRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRatePositionVelocityNed(request, new StreamObserver<TelemetryProto.SetRatePositionVelocityNedResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRatePositionVelocityNedResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateGroundTruth(@NonNull Double rateHz) {

      TelemetryProto.SetRateGroundTruthRequest request = TelemetryProto.SetRateGroundTruthRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateGroundTruth(request, new StreamObserver<TelemetryProto.SetRateGroundTruthResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateGroundTruthResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateFixedwingMetrics(@NonNull Double rateHz) {

      TelemetryProto.SetRateFixedwingMetricsRequest request = TelemetryProto.SetRateFixedwingMetricsRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateFixedwingMetrics(request, new StreamObserver<TelemetryProto.SetRateFixedwingMetricsResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateFixedwingMetricsResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateImu(@NonNull Double rateHz) {

      TelemetryProto.SetRateImuRequest request = TelemetryProto.SetRateImuRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateImu(request, new StreamObserver<TelemetryProto.SetRateImuResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateImuResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateScaledImu(@NonNull Double rateHz) {

      TelemetryProto.SetRateScaledImuRequest request = TelemetryProto.SetRateScaledImuRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateScaledImu(request, new StreamObserver<TelemetryProto.SetRateScaledImuResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateScaledImuResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateRawImu(@NonNull Double rateHz) {

      TelemetryProto.SetRateRawImuRequest request = TelemetryProto.SetRateRawImuRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateRawImu(request, new StreamObserver<TelemetryProto.SetRateRawImuResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateRawImuResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateUnixEpochTime(@NonNull Double rateHz) {

      TelemetryProto.SetRateUnixEpochTimeRequest request = TelemetryProto.SetRateUnixEpochTimeRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateUnixEpochTime(request, new StreamObserver<TelemetryProto.SetRateUnixEpochTimeResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateUnixEpochTimeResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setRateDistanceSensor(@NonNull Double rateHz) {

      TelemetryProto.SetRateDistanceSensorRequest request = TelemetryProto.SetRateDistanceSensorRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateDistanceSensor(request, new StreamObserver<TelemetryProto.SetRateDistanceSensorResponse>() {

          @Override
          public void onNext(TelemetryProto.SetRateDistanceSensorResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Telemetry.GpsGlobalOrigin> getGpsGlobalOrigin() {
      TelemetryProto.GetGpsGlobalOriginRequest request = TelemetryProto.GetGpsGlobalOriginRequest.newBuilder()
        .build();

      Single<Telemetry.GpsGlobalOrigin> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getGpsGlobalOrigin(request, new StreamObserver<TelemetryProto.GetGpsGlobalOriginResponse>() {

          @Override
          public void onNext(TelemetryProto.GetGpsGlobalOriginResponse value) {
            TelemetryResult result = TelemetryResult.translateFromRpc(value.getTelemetryResult());

            if (result.result != TelemetryResult.Result.SUCCESS) {
              emitter.onError(new TelemetryException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(GpsGlobalOrigin.translateFromRpc(value.getGpsGlobalOrigin()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}