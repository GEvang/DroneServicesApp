package io.mavsdk.offboard;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Offboard implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Offboard.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private OffboardServiceGrpc.OffboardServiceStub stub;

  private volatile boolean isInitialized = false;

  public Offboard(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Offboard() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = OffboardServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class OffboardException extends MavsdkException {
    private OffboardResult.Result code;
    private String description;

    public OffboardException(OffboardResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public OffboardResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class Attitude {
      private Float rollDeg;
      private Float pitchDeg;
      private Float yawDeg;
      private Float thrustValue;

      public Attitude(Float rollDeg, Float pitchDeg, Float yawDeg, Float thrustValue) {
        this.rollDeg = rollDeg;
        this.pitchDeg = pitchDeg;
        this.yawDeg = yawDeg;
        this.thrustValue = thrustValue;
      }
      public Float getRollDeg() {
        return rollDeg;
      }
      public Float getPitchDeg() {
        return pitchDeg;
      }
      public Float getYawDeg() {
        return yawDeg;
      }
      public Float getThrustValue() {
        return thrustValue;
      }

      protected OffboardProto.Attitude rpcAttitude() {
        return OffboardProto.Attitude.newBuilder()
          .setRollDeg(this.rollDeg)
          .setPitchDeg(this.pitchDeg)
          .setYawDeg(this.yawDeg)
          .setThrustValue(this.thrustValue)
          .build();
      }

      protected static Attitude translateFromRpc(OffboardProto.Attitude rpcAttitude) {
        return new Attitude(
                rpcAttitude.getRollDeg(),
                rpcAttitude.getPitchDeg(),
                rpcAttitude.getYawDeg(),
                rpcAttitude.getThrustValue());
      }
    }


    public static class ActuatorControlGroup {
      private List<Float> controls;

      public ActuatorControlGroup(List<Float> controls) {
        this.controls = controls;
      }
      public List<Float> getControls() {
        return controls;
      }

      protected OffboardProto.ActuatorControlGroup rpcActuatorControlGroup() {
        return OffboardProto.ActuatorControlGroup.newBuilder()
          .addAllControls(controls)
          .build();
      }

      protected static ActuatorControlGroup translateFromRpc(OffboardProto.ActuatorControlGroup rpcActuatorControlGroup) {
        return new ActuatorControlGroup(
                    rpcActuatorControlGroup.getControlsList());
      }
    }


    public static class ActuatorControl {
      private List<ActuatorControlGroup> groups;

      public ActuatorControl(List<ActuatorControlGroup> groups) {
        this.groups = groups;
      }
      public List<ActuatorControlGroup> getGroups() {
        return groups;
      }

      protected OffboardProto.ActuatorControl rpcActuatorControl() {
        return OffboardProto.ActuatorControl.newBuilder()
          .addAllGroups(groups.stream().map(ActuatorControlGroup::rpcActuatorControlGroup).collect(Collectors.toList()))
          .build();
      }

      protected static ActuatorControl translateFromRpc(OffboardProto.ActuatorControl rpcActuatorControl) {
        return new ActuatorControl(
                    rpcActuatorControl.getGroupsList().stream().map(ActuatorControlGroup::translateFromRpc).collect(Collectors.toList()));
      }
    }


    public static class AttitudeRate {
      private Float rollDegS;
      private Float pitchDegS;
      private Float yawDegS;
      private Float thrustValue;

      public AttitudeRate(Float rollDegS, Float pitchDegS, Float yawDegS, Float thrustValue) {
        this.rollDegS = rollDegS;
        this.pitchDegS = pitchDegS;
        this.yawDegS = yawDegS;
        this.thrustValue = thrustValue;
      }
      public Float getRollDegS() {
        return rollDegS;
      }
      public Float getPitchDegS() {
        return pitchDegS;
      }
      public Float getYawDegS() {
        return yawDegS;
      }
      public Float getThrustValue() {
        return thrustValue;
      }

      protected OffboardProto.AttitudeRate rpcAttitudeRate() {
        return OffboardProto.AttitudeRate.newBuilder()
          .setRollDegS(this.rollDegS)
          .setPitchDegS(this.pitchDegS)
          .setYawDegS(this.yawDegS)
          .setThrustValue(this.thrustValue)
          .build();
      }

      protected static AttitudeRate translateFromRpc(OffboardProto.AttitudeRate rpcAttitudeRate) {
        return new AttitudeRate(
                rpcAttitudeRate.getRollDegS(),
                rpcAttitudeRate.getPitchDegS(),
                rpcAttitudeRate.getYawDegS(),
                rpcAttitudeRate.getThrustValue());
      }
    }


    public static class PositionNedYaw {
      private Float northM;
      private Float eastM;
      private Float downM;
      private Float yawDeg;

      public PositionNedYaw(Float northM, Float eastM, Float downM, Float yawDeg) {
        this.northM = northM;
        this.eastM = eastM;
        this.downM = downM;
        this.yawDeg = yawDeg;
      }
      public Float getNorthM() {
        return northM;
      }
      public Float getEastM() {
        return eastM;
      }
      public Float getDownM() {
        return downM;
      }
      public Float getYawDeg() {
        return yawDeg;
      }

      protected OffboardProto.PositionNedYaw rpcPositionNedYaw() {
        return OffboardProto.PositionNedYaw.newBuilder()
          .setNorthM(this.northM)
          .setEastM(this.eastM)
          .setDownM(this.downM)
          .setYawDeg(this.yawDeg)
          .build();
      }

      protected static PositionNedYaw translateFromRpc(OffboardProto.PositionNedYaw rpcPositionNedYaw) {
        return new PositionNedYaw(
                rpcPositionNedYaw.getNorthM(),
                rpcPositionNedYaw.getEastM(),
                rpcPositionNedYaw.getDownM(),
                rpcPositionNedYaw.getYawDeg());
      }
    }


    public static class PositionGlobalYaw {
      private Double latDeg;
      private Double lonDeg;
      private Float altM;
      private Float yawDeg;
      private AltitudeType altitudeType;
      
        public enum AltitudeType {
          
          REL_HOME {
            @Override
            protected OffboardProto.PositionGlobalYaw.AltitudeType rpcAltitudeType() {
              return OffboardProto.PositionGlobalYaw.AltitudeType.ALTITUDE_TYPE_REL_HOME;
            }
          }, 
          AMSL {
            @Override
            protected OffboardProto.PositionGlobalYaw.AltitudeType rpcAltitudeType() {
              return OffboardProto.PositionGlobalYaw.AltitudeType.ALTITUDE_TYPE_AMSL;
            }
          }, 
          AGL {
            @Override
            protected OffboardProto.PositionGlobalYaw.AltitudeType rpcAltitudeType() {
              return OffboardProto.PositionGlobalYaw.AltitudeType.ALTITUDE_TYPE_AGL;
            }
          };

          protected static AltitudeType translateFromRpc(OffboardProto.PositionGlobalYaw.AltitudeType rpcAltitudeType) {
            switch (rpcAltitudeType) {
              case ALTITUDE_TYPE_REL_HOME: default: 
                return AltitudeType.REL_HOME;
              case ALTITUDE_TYPE_AMSL: 
                return AltitudeType.AMSL;
              case ALTITUDE_TYPE_AGL: 
                return AltitudeType.AGL;
            }
          }

          protected abstract OffboardProto.PositionGlobalYaw.AltitudeType rpcAltitudeType();
        }

      public PositionGlobalYaw(Double latDeg, Double lonDeg, Float altM, Float yawDeg, AltitudeType altitudeType) {
        this.latDeg = latDeg;
        this.lonDeg = lonDeg;
        this.altM = altM;
        this.yawDeg = yawDeg;
        this.altitudeType = altitudeType;
      }
      public Double getLatDeg() {
        return latDeg;
      }
      public Double getLonDeg() {
        return lonDeg;
      }
      public Float getAltM() {
        return altM;
      }
      public Float getYawDeg() {
        return yawDeg;
      }
      public AltitudeType getAltitudeType() {
        return altitudeType;
      }

      protected OffboardProto.PositionGlobalYaw rpcPositionGlobalYaw() {
        return OffboardProto.PositionGlobalYaw.newBuilder()
          .setLatDeg(this.latDeg)
          .setLonDeg(this.lonDeg)
          .setAltM(this.altM)
          .setYawDeg(this.yawDeg)
          .setAltitudeType(this.altitudeType.rpcAltitudeType())
          .build();
      }

      protected static PositionGlobalYaw translateFromRpc(OffboardProto.PositionGlobalYaw rpcPositionGlobalYaw) {
        return new PositionGlobalYaw(
                rpcPositionGlobalYaw.getLatDeg(),
                rpcPositionGlobalYaw.getLonDeg(),
                rpcPositionGlobalYaw.getAltM(),
                rpcPositionGlobalYaw.getYawDeg(),
                AltitudeType.translateFromRpc(rpcPositionGlobalYaw.getAltitudeType()));
      }
    }


    public static class VelocityBodyYawspeed {
      private Float forwardMS;
      private Float rightMS;
      private Float downMS;
      private Float yawspeedDegS;

      public VelocityBodyYawspeed(Float forwardMS, Float rightMS, Float downMS, Float yawspeedDegS) {
        this.forwardMS = forwardMS;
        this.rightMS = rightMS;
        this.downMS = downMS;
        this.yawspeedDegS = yawspeedDegS;
      }
      public Float getForwardMS() {
        return forwardMS;
      }
      public Float getRightMS() {
        return rightMS;
      }
      public Float getDownMS() {
        return downMS;
      }
      public Float getYawspeedDegS() {
        return yawspeedDegS;
      }

      protected OffboardProto.VelocityBodyYawspeed rpcVelocityBodyYawspeed() {
        return OffboardProto.VelocityBodyYawspeed.newBuilder()
          .setForwardMS(this.forwardMS)
          .setRightMS(this.rightMS)
          .setDownMS(this.downMS)
          .setYawspeedDegS(this.yawspeedDegS)
          .build();
      }

      protected static VelocityBodyYawspeed translateFromRpc(OffboardProto.VelocityBodyYawspeed rpcVelocityBodyYawspeed) {
        return new VelocityBodyYawspeed(
                rpcVelocityBodyYawspeed.getForwardMS(),
                rpcVelocityBodyYawspeed.getRightMS(),
                rpcVelocityBodyYawspeed.getDownMS(),
                rpcVelocityBodyYawspeed.getYawspeedDegS());
      }
    }


    public static class VelocityNedYaw {
      private Float northMS;
      private Float eastMS;
      private Float downMS;
      private Float yawDeg;

      public VelocityNedYaw(Float northMS, Float eastMS, Float downMS, Float yawDeg) {
        this.northMS = northMS;
        this.eastMS = eastMS;
        this.downMS = downMS;
        this.yawDeg = yawDeg;
      }
      public Float getNorthMS() {
        return northMS;
      }
      public Float getEastMS() {
        return eastMS;
      }
      public Float getDownMS() {
        return downMS;
      }
      public Float getYawDeg() {
        return yawDeg;
      }

      protected OffboardProto.VelocityNedYaw rpcVelocityNedYaw() {
        return OffboardProto.VelocityNedYaw.newBuilder()
          .setNorthMS(this.northMS)
          .setEastMS(this.eastMS)
          .setDownMS(this.downMS)
          .setYawDeg(this.yawDeg)
          .build();
      }

      protected static VelocityNedYaw translateFromRpc(OffboardProto.VelocityNedYaw rpcVelocityNedYaw) {
        return new VelocityNedYaw(
                rpcVelocityNedYaw.getNorthMS(),
                rpcVelocityNedYaw.getEastMS(),
                rpcVelocityNedYaw.getDownMS(),
                rpcVelocityNedYaw.getYawDeg());
      }
    }


    public static class AccelerationNed {
      private Float northMS2;
      private Float eastMS2;
      private Float downMS2;

      public AccelerationNed(Float northMS2, Float eastMS2, Float downMS2) {
        this.northMS2 = northMS2;
        this.eastMS2 = eastMS2;
        this.downMS2 = downMS2;
      }
      public Float getNorthMS2() {
        return northMS2;
      }
      public Float getEastMS2() {
        return eastMS2;
      }
      public Float getDownMS2() {
        return downMS2;
      }

      protected OffboardProto.AccelerationNed rpcAccelerationNed() {
        return OffboardProto.AccelerationNed.newBuilder()
          .setNorthMS2(this.northMS2)
          .setEastMS2(this.eastMS2)
          .setDownMS2(this.downMS2)
          .build();
      }

      protected static AccelerationNed translateFromRpc(OffboardProto.AccelerationNed rpcAccelerationNed) {
        return new AccelerationNed(
                rpcAccelerationNed.getNorthMS2(),
                rpcAccelerationNed.getEastMS2(),
                rpcAccelerationNed.getDownMS2());
      }
    }


    public static class OffboardResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_TIMEOUT;
            }
          }, 
          NO_SETPOINT_SET {
            @Override
            protected OffboardProto.OffboardResult.Result rpcResult() {
              return OffboardProto.OffboardResult.Result.RESULT_NO_SETPOINT_SET;
            }
          };

          protected static Result translateFromRpc(OffboardProto.OffboardResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_NO_SETPOINT_SET: 
                return Result.NO_SETPOINT_SET;
            }
          }

          protected abstract OffboardProto.OffboardResult.Result rpcResult();
        }

      public OffboardResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected OffboardProto.OffboardResult rpcOffboardResult() {
        return OffboardProto.OffboardResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static OffboardResult translateFromRpc(OffboardProto.OffboardResult rpcOffboardResult) {
        return new OffboardResult(
                Result.translateFromRpc(rpcOffboardResult.getResult()),
                rpcOffboardResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable start() {

      OffboardProto.StartRequest request = OffboardProto.StartRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.start(request, new StreamObserver<OffboardProto.StartResponse>() {

          @Override
          public void onNext(OffboardProto.StartResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable stop() {

      OffboardProto.StopRequest request = OffboardProto.StopRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.stop(request, new StreamObserver<OffboardProto.StopResponse>() {

          @Override
          public void onNext(OffboardProto.StopResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Boolean> isActive() {
      OffboardProto.IsActiveRequest request = OffboardProto.IsActiveRequest.newBuilder()
        .build();

      Single<Boolean> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.isActive(request, new StreamObserver<OffboardProto.IsActiveResponse>() {

          @Override
          public void onNext(OffboardProto.IsActiveResponse value) {
              emitter.onSuccess(value.getIsActive());
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setAttitude(@NonNull Attitude attitude) {

      OffboardProto.SetAttitudeRequest request = OffboardProto.SetAttitudeRequest.newBuilder()
        .setAttitude(attitude.rpcAttitude())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setAttitude(request, new StreamObserver<OffboardProto.SetAttitudeResponse>() {

          @Override
          public void onNext(OffboardProto.SetAttitudeResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setActuatorControl(@NonNull ActuatorControl actuatorControl) {

      OffboardProto.SetActuatorControlRequest request = OffboardProto.SetActuatorControlRequest.newBuilder()
        .setActuatorControl(actuatorControl.rpcActuatorControl())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setActuatorControl(request, new StreamObserver<OffboardProto.SetActuatorControlResponse>() {

          @Override
          public void onNext(OffboardProto.SetActuatorControlResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setAttitudeRate(@NonNull AttitudeRate attitudeRate) {

      OffboardProto.SetAttitudeRateRequest request = OffboardProto.SetAttitudeRateRequest.newBuilder()
        .setAttitudeRate(attitudeRate.rpcAttitudeRate())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setAttitudeRate(request, new StreamObserver<OffboardProto.SetAttitudeRateResponse>() {

          @Override
          public void onNext(OffboardProto.SetAttitudeRateResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setPositionNed(@NonNull PositionNedYaw positionNedYaw) {

      OffboardProto.SetPositionNedRequest request = OffboardProto.SetPositionNedRequest.newBuilder()
        .setPositionNedYaw(positionNedYaw.rpcPositionNedYaw())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setPositionNed(request, new StreamObserver<OffboardProto.SetPositionNedResponse>() {

          @Override
          public void onNext(OffboardProto.SetPositionNedResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setPositionGlobal(@NonNull PositionGlobalYaw positionGlobalYaw) {

      OffboardProto.SetPositionGlobalRequest request = OffboardProto.SetPositionGlobalRequest.newBuilder()
        .setPositionGlobalYaw(positionGlobalYaw.rpcPositionGlobalYaw())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setPositionGlobal(request, new StreamObserver<OffboardProto.SetPositionGlobalResponse>() {

          @Override
          public void onNext(OffboardProto.SetPositionGlobalResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setVelocityBody(@NonNull VelocityBodyYawspeed velocityBodyYawspeed) {

      OffboardProto.SetVelocityBodyRequest request = OffboardProto.SetVelocityBodyRequest.newBuilder()
        .setVelocityBodyYawspeed(velocityBodyYawspeed.rpcVelocityBodyYawspeed())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setVelocityBody(request, new StreamObserver<OffboardProto.SetVelocityBodyResponse>() {

          @Override
          public void onNext(OffboardProto.SetVelocityBodyResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setVelocityNed(@NonNull VelocityNedYaw velocityNedYaw) {

      OffboardProto.SetVelocityNedRequest request = OffboardProto.SetVelocityNedRequest.newBuilder()
        .setVelocityNedYaw(velocityNedYaw.rpcVelocityNedYaw())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setVelocityNed(request, new StreamObserver<OffboardProto.SetVelocityNedResponse>() {

          @Override
          public void onNext(OffboardProto.SetVelocityNedResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setPositionVelocityNed(@NonNull PositionNedYaw positionNedYaw, @NonNull VelocityNedYaw velocityNedYaw) {

      OffboardProto.SetPositionVelocityNedRequest request = OffboardProto.SetPositionVelocityNedRequest.newBuilder()
        .setPositionNedYaw(positionNedYaw.rpcPositionNedYaw())
        .setVelocityNedYaw(velocityNedYaw.rpcVelocityNedYaw())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setPositionVelocityNed(request, new StreamObserver<OffboardProto.SetPositionVelocityNedResponse>() {

          @Override
          public void onNext(OffboardProto.SetPositionVelocityNedResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setAccelerationNed(@NonNull AccelerationNed accelerationNed) {

      OffboardProto.SetAccelerationNedRequest request = OffboardProto.SetAccelerationNedRequest.newBuilder()
        .setAccelerationNed(accelerationNed.rpcAccelerationNed())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setAccelerationNed(request, new StreamObserver<OffboardProto.SetAccelerationNedResponse>() {

          @Override
          public void onNext(OffboardProto.SetAccelerationNedResponse value) {
            OffboardResult result = OffboardResult.translateFromRpc(value.getOffboardResult());

            if (result.result != OffboardResult.Result.SUCCESS) {
              emitter.onError(new OffboardException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}