package io.mavsdk.tracking_server;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * API for an onboard image tracking software.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.42.1)",
    comments = "Source: tracking_server/tracking_server.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class TrackingServerServiceGrpc {

  private TrackingServerServiceGrpc() {}

  public static final String SERVICE_NAME = "mavsdk.rpc.tracking_server.TrackingServerService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest,
      io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse> getSetTrackingPointStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SetTrackingPointStatus",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest,
      io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse> getSetTrackingPointStatusMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest, io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse> getSetTrackingPointStatusMethod;
    if ((getSetTrackingPointStatusMethod = TrackingServerServiceGrpc.getSetTrackingPointStatusMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getSetTrackingPointStatusMethod = TrackingServerServiceGrpc.getSetTrackingPointStatusMethod) == null) {
          TrackingServerServiceGrpc.getSetTrackingPointStatusMethod = getSetTrackingPointStatusMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest, io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SetTrackingPointStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSetTrackingPointStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest,
      io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse> getSetTrackingRectangleStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SetTrackingRectangleStatus",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest,
      io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse> getSetTrackingRectangleStatusMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest, io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse> getSetTrackingRectangleStatusMethod;
    if ((getSetTrackingRectangleStatusMethod = TrackingServerServiceGrpc.getSetTrackingRectangleStatusMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getSetTrackingRectangleStatusMethod = TrackingServerServiceGrpc.getSetTrackingRectangleStatusMethod) == null) {
          TrackingServerServiceGrpc.getSetTrackingRectangleStatusMethod = getSetTrackingRectangleStatusMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest, io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SetTrackingRectangleStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSetTrackingRectangleStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest,
      io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse> getSetTrackingOffStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SetTrackingOffStatus",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest,
      io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse> getSetTrackingOffStatusMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest, io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse> getSetTrackingOffStatusMethod;
    if ((getSetTrackingOffStatusMethod = TrackingServerServiceGrpc.getSetTrackingOffStatusMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getSetTrackingOffStatusMethod = TrackingServerServiceGrpc.getSetTrackingOffStatusMethod) == null) {
          TrackingServerServiceGrpc.getSetTrackingOffStatusMethod = getSetTrackingOffStatusMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest, io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SetTrackingOffStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSetTrackingOffStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse> getSubscribeTrackingPointCommandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SubscribeTrackingPointCommand",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse> getSubscribeTrackingPointCommandMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse> getSubscribeTrackingPointCommandMethod;
    if ((getSubscribeTrackingPointCommandMethod = TrackingServerServiceGrpc.getSubscribeTrackingPointCommandMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getSubscribeTrackingPointCommandMethod = TrackingServerServiceGrpc.getSubscribeTrackingPointCommandMethod) == null) {
          TrackingServerServiceGrpc.getSubscribeTrackingPointCommandMethod = getSubscribeTrackingPointCommandMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SubscribeTrackingPointCommand"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSubscribeTrackingPointCommandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse> getSubscribeTrackingRectangleCommandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SubscribeTrackingRectangleCommand",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse> getSubscribeTrackingRectangleCommandMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse> getSubscribeTrackingRectangleCommandMethod;
    if ((getSubscribeTrackingRectangleCommandMethod = TrackingServerServiceGrpc.getSubscribeTrackingRectangleCommandMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getSubscribeTrackingRectangleCommandMethod = TrackingServerServiceGrpc.getSubscribeTrackingRectangleCommandMethod) == null) {
          TrackingServerServiceGrpc.getSubscribeTrackingRectangleCommandMethod = getSubscribeTrackingRectangleCommandMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SubscribeTrackingRectangleCommand"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSubscribeTrackingRectangleCommandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse> getSubscribeTrackingOffCommandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SubscribeTrackingOffCommand",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse> getSubscribeTrackingOffCommandMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse> getSubscribeTrackingOffCommandMethod;
    if ((getSubscribeTrackingOffCommandMethod = TrackingServerServiceGrpc.getSubscribeTrackingOffCommandMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getSubscribeTrackingOffCommandMethod = TrackingServerServiceGrpc.getSubscribeTrackingOffCommandMethod) == null) {
          TrackingServerServiceGrpc.getSubscribeTrackingOffCommandMethod = getSubscribeTrackingOffCommandMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SubscribeTrackingOffCommand"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSubscribeTrackingOffCommandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse> getRespondTrackingPointCommandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RespondTrackingPointCommand",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse> getRespondTrackingPointCommandMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse> getRespondTrackingPointCommandMethod;
    if ((getRespondTrackingPointCommandMethod = TrackingServerServiceGrpc.getRespondTrackingPointCommandMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getRespondTrackingPointCommandMethod = TrackingServerServiceGrpc.getRespondTrackingPointCommandMethod) == null) {
          TrackingServerServiceGrpc.getRespondTrackingPointCommandMethod = getRespondTrackingPointCommandMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RespondTrackingPointCommand"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRespondTrackingPointCommandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse> getRespondTrackingRectangleCommandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RespondTrackingRectangleCommand",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse> getRespondTrackingRectangleCommandMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse> getRespondTrackingRectangleCommandMethod;
    if ((getRespondTrackingRectangleCommandMethod = TrackingServerServiceGrpc.getRespondTrackingRectangleCommandMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getRespondTrackingRectangleCommandMethod = TrackingServerServiceGrpc.getRespondTrackingRectangleCommandMethod) == null) {
          TrackingServerServiceGrpc.getRespondTrackingRectangleCommandMethod = getRespondTrackingRectangleCommandMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RespondTrackingRectangleCommand"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRespondTrackingRectangleCommandMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse> getRespondTrackingOffCommandMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RespondTrackingOffCommand",
      requestType = io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest.class,
      responseType = io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest,
      io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse> getRespondTrackingOffCommandMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse> getRespondTrackingOffCommandMethod;
    if ((getRespondTrackingOffCommandMethod = TrackingServerServiceGrpc.getRespondTrackingOffCommandMethod) == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        if ((getRespondTrackingOffCommandMethod = TrackingServerServiceGrpc.getRespondTrackingOffCommandMethod) == null) {
          TrackingServerServiceGrpc.getRespondTrackingOffCommandMethod = getRespondTrackingOffCommandMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest, io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RespondTrackingOffCommand"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRespondTrackingOffCommandMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static TrackingServerServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<TrackingServerServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<TrackingServerServiceStub>() {
        @java.lang.Override
        public TrackingServerServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new TrackingServerServiceStub(channel, callOptions);
        }
      };
    return TrackingServerServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static TrackingServerServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<TrackingServerServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<TrackingServerServiceBlockingStub>() {
        @java.lang.Override
        public TrackingServerServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new TrackingServerServiceBlockingStub(channel, callOptions);
        }
      };
    return TrackingServerServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static TrackingServerServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<TrackingServerServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<TrackingServerServiceFutureStub>() {
        @java.lang.Override
        public TrackingServerServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new TrackingServerServiceFutureStub(channel, callOptions);
        }
      };
    return TrackingServerServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * API for an onboard image tracking software.
   * </pre>
   */
  public static abstract class TrackingServerServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Set/update the current point tracking status.
     * </pre>
     */
    public void setTrackingPointStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSetTrackingPointStatusMethod(), responseObserver);
    }

    /**
     * <pre>
     * Set/update the current rectangle tracking status.
     * </pre>
     */
    public void setTrackingRectangleStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSetTrackingRectangleStatusMethod(), responseObserver);
    }

    /**
     * <pre>
     * Set the current tracking status to off.
     * </pre>
     */
    public void setTrackingOffStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSetTrackingOffStatusMethod(), responseObserver);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking point command.
     * </pre>
     */
    public void subscribeTrackingPointCommand(io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSubscribeTrackingPointCommandMethod(), responseObserver);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking rectangle command.
     * </pre>
     */
    public void subscribeTrackingRectangleCommand(io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSubscribeTrackingRectangleCommandMethod(), responseObserver);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking off command.
     * </pre>
     */
    public void subscribeTrackingOffCommand(io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSubscribeTrackingOffCommandMethod(), responseObserver);
    }

    /**
     * <pre>
     * Respond to an incoming tracking point command.
     * </pre>
     */
    public void respondTrackingPointCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRespondTrackingPointCommandMethod(), responseObserver);
    }

    /**
     * <pre>
     * Respond to an incoming tracking rectangle command.
     * </pre>
     */
    public void respondTrackingRectangleCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRespondTrackingRectangleCommandMethod(), responseObserver);
    }

    /**
     * <pre>
     * Respond to an incoming tracking off command.
     * </pre>
     */
    public void respondTrackingOffCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRespondTrackingOffCommandMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getSetTrackingPointStatusMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest,
                io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse>(
                  this, METHODID_SET_TRACKING_POINT_STATUS)))
          .addMethod(
            getSetTrackingRectangleStatusMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest,
                io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse>(
                  this, METHODID_SET_TRACKING_RECTANGLE_STATUS)))
          .addMethod(
            getSetTrackingOffStatusMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest,
                io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse>(
                  this, METHODID_SET_TRACKING_OFF_STATUS)))
          .addMethod(
            getSubscribeTrackingPointCommandMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest,
                io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse>(
                  this, METHODID_SUBSCRIBE_TRACKING_POINT_COMMAND)))
          .addMethod(
            getSubscribeTrackingRectangleCommandMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest,
                io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse>(
                  this, METHODID_SUBSCRIBE_TRACKING_RECTANGLE_COMMAND)))
          .addMethod(
            getSubscribeTrackingOffCommandMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest,
                io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse>(
                  this, METHODID_SUBSCRIBE_TRACKING_OFF_COMMAND)))
          .addMethod(
            getRespondTrackingPointCommandMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest,
                io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse>(
                  this, METHODID_RESPOND_TRACKING_POINT_COMMAND)))
          .addMethod(
            getRespondTrackingRectangleCommandMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest,
                io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse>(
                  this, METHODID_RESPOND_TRACKING_RECTANGLE_COMMAND)))
          .addMethod(
            getRespondTrackingOffCommandMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest,
                io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse>(
                  this, METHODID_RESPOND_TRACKING_OFF_COMMAND)))
          .build();
    }
  }

  /**
   * <pre>
   * API for an onboard image tracking software.
   * </pre>
   */
  public static final class TrackingServerServiceStub extends io.grpc.stub.AbstractAsyncStub<TrackingServerServiceStub> {
    private TrackingServerServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TrackingServerServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new TrackingServerServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Set/update the current point tracking status.
     * </pre>
     */
    public void setTrackingPointStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSetTrackingPointStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Set/update the current rectangle tracking status.
     * </pre>
     */
    public void setTrackingRectangleStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSetTrackingRectangleStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Set the current tracking status to off.
     * </pre>
     */
    public void setTrackingOffStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSetTrackingOffStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking point command.
     * </pre>
     */
    public void subscribeTrackingPointCommand(io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getSubscribeTrackingPointCommandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking rectangle command.
     * </pre>
     */
    public void subscribeTrackingRectangleCommand(io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getSubscribeTrackingRectangleCommandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking off command.
     * </pre>
     */
    public void subscribeTrackingOffCommand(io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getSubscribeTrackingOffCommandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Respond to an incoming tracking point command.
     * </pre>
     */
    public void respondTrackingPointCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRespondTrackingPointCommandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Respond to an incoming tracking rectangle command.
     * </pre>
     */
    public void respondTrackingRectangleCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRespondTrackingRectangleCommandMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Respond to an incoming tracking off command.
     * </pre>
     */
    public void respondTrackingOffCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRespondTrackingOffCommandMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * API for an onboard image tracking software.
   * </pre>
   */
  public static final class TrackingServerServiceBlockingStub extends io.grpc.stub.AbstractBlockingStub<TrackingServerServiceBlockingStub> {
    private TrackingServerServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TrackingServerServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new TrackingServerServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Set/update the current point tracking status.
     * </pre>
     */
    public io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse setTrackingPointStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSetTrackingPointStatusMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Set/update the current rectangle tracking status.
     * </pre>
     */
    public io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse setTrackingRectangleStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSetTrackingRectangleStatusMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Set the current tracking status to off.
     * </pre>
     */
    public io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse setTrackingOffStatus(io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSetTrackingOffStatusMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking point command.
     * </pre>
     */
    public java.util.Iterator<io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse> subscribeTrackingPointCommand(
        io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getSubscribeTrackingPointCommandMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking rectangle command.
     * </pre>
     */
    public java.util.Iterator<io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse> subscribeTrackingRectangleCommand(
        io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getSubscribeTrackingRectangleCommandMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Subscribe to incoming tracking off command.
     * </pre>
     */
    public java.util.Iterator<io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse> subscribeTrackingOffCommand(
        io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getSubscribeTrackingOffCommandMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Respond to an incoming tracking point command.
     * </pre>
     */
    public io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse respondTrackingPointCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRespondTrackingPointCommandMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Respond to an incoming tracking rectangle command.
     * </pre>
     */
    public io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse respondTrackingRectangleCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRespondTrackingRectangleCommandMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Respond to an incoming tracking off command.
     * </pre>
     */
    public io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse respondTrackingOffCommand(io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRespondTrackingOffCommandMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * API for an onboard image tracking software.
   * </pre>
   */
  public static final class TrackingServerServiceFutureStub extends io.grpc.stub.AbstractFutureStub<TrackingServerServiceFutureStub> {
    private TrackingServerServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TrackingServerServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new TrackingServerServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Set/update the current point tracking status.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse> setTrackingPointStatus(
        io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSetTrackingPointStatusMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Set/update the current rectangle tracking status.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse> setTrackingRectangleStatus(
        io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSetTrackingRectangleStatusMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Set the current tracking status to off.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse> setTrackingOffStatus(
        io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSetTrackingOffStatusMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Respond to an incoming tracking point command.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse> respondTrackingPointCommand(
        io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRespondTrackingPointCommandMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Respond to an incoming tracking rectangle command.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse> respondTrackingRectangleCommand(
        io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRespondTrackingRectangleCommandMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Respond to an incoming tracking off command.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse> respondTrackingOffCommand(
        io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRespondTrackingOffCommandMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_SET_TRACKING_POINT_STATUS = 0;
  private static final int METHODID_SET_TRACKING_RECTANGLE_STATUS = 1;
  private static final int METHODID_SET_TRACKING_OFF_STATUS = 2;
  private static final int METHODID_SUBSCRIBE_TRACKING_POINT_COMMAND = 3;
  private static final int METHODID_SUBSCRIBE_TRACKING_RECTANGLE_COMMAND = 4;
  private static final int METHODID_SUBSCRIBE_TRACKING_OFF_COMMAND = 5;
  private static final int METHODID_RESPOND_TRACKING_POINT_COMMAND = 6;
  private static final int METHODID_RESPOND_TRACKING_RECTANGLE_COMMAND = 7;
  private static final int METHODID_RESPOND_TRACKING_OFF_COMMAND = 8;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final TrackingServerServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(TrackingServerServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_SET_TRACKING_POINT_STATUS:
          serviceImpl.setTrackingPointStatus((io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingPointStatusResponse>) responseObserver);
          break;
        case METHODID_SET_TRACKING_RECTANGLE_STATUS:
          serviceImpl.setTrackingRectangleStatus((io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingRectangleStatusResponse>) responseObserver);
          break;
        case METHODID_SET_TRACKING_OFF_STATUS:
          serviceImpl.setTrackingOffStatus((io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.SetTrackingOffStatusResponse>) responseObserver);
          break;
        case METHODID_SUBSCRIBE_TRACKING_POINT_COMMAND:
          serviceImpl.subscribeTrackingPointCommand((io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingPointCommandRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingPointCommandResponse>) responseObserver);
          break;
        case METHODID_SUBSCRIBE_TRACKING_RECTANGLE_COMMAND:
          serviceImpl.subscribeTrackingRectangleCommand((io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingRectangleCommandRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingRectangleCommandResponse>) responseObserver);
          break;
        case METHODID_SUBSCRIBE_TRACKING_OFF_COMMAND:
          serviceImpl.subscribeTrackingOffCommand((io.mavsdk.tracking_server.TrackingServerProto.SubscribeTrackingOffCommandRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.TrackingOffCommandResponse>) responseObserver);
          break;
        case METHODID_RESPOND_TRACKING_POINT_COMMAND:
          serviceImpl.respondTrackingPointCommand((io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingPointCommandResponse>) responseObserver);
          break;
        case METHODID_RESPOND_TRACKING_RECTANGLE_COMMAND:
          serviceImpl.respondTrackingRectangleCommand((io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingRectangleCommandResponse>) responseObserver);
          break;
        case METHODID_RESPOND_TRACKING_OFF_COMMAND:
          serviceImpl.respondTrackingOffCommand((io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.tracking_server.TrackingServerProto.RespondTrackingOffCommandResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (TrackingServerServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .addMethod(getSetTrackingPointStatusMethod())
              .addMethod(getSetTrackingRectangleStatusMethod())
              .addMethod(getSetTrackingOffStatusMethod())
              .addMethod(getSubscribeTrackingPointCommandMethod())
              .addMethod(getSubscribeTrackingRectangleCommandMethod())
              .addMethod(getSubscribeTrackingOffCommandMethod())
              .addMethod(getRespondTrackingPointCommandMethod())
              .addMethod(getRespondTrackingRectangleCommandMethod())
              .addMethod(getRespondTrackingOffCommandMethod())
              .build();
        }
      }
    }
    return result;
  }
}
