package io.mavsdk.tracking_server;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrackingServer implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(TrackingServer.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private TrackingServerServiceGrpc.TrackingServerServiceStub stub;

  private volatile boolean isInitialized = false;

  public TrackingServer(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public TrackingServer() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = TrackingServerServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class TrackingServerException extends MavsdkException {
    private TrackingServerResult.Result code;
    private String description;

    public TrackingServerException(TrackingServerResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public TrackingServerResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum CommandAnswer {
      
      ACCEPTED {
        @Override
        protected TrackingServerProto.CommandAnswer rpcCommandAnswer() {
          return TrackingServerProto.CommandAnswer.COMMAND_ANSWER_ACCEPTED;
        }
      }, 
      TEMPORARILY_REJECTED {
        @Override
        protected TrackingServerProto.CommandAnswer rpcCommandAnswer() {
          return TrackingServerProto.CommandAnswer.COMMAND_ANSWER_TEMPORARILY_REJECTED;
        }
      }, 
      DENIED {
        @Override
        protected TrackingServerProto.CommandAnswer rpcCommandAnswer() {
          return TrackingServerProto.CommandAnswer.COMMAND_ANSWER_DENIED;
        }
      }, 
      UNSUPPORTED {
        @Override
        protected TrackingServerProto.CommandAnswer rpcCommandAnswer() {
          return TrackingServerProto.CommandAnswer.COMMAND_ANSWER_UNSUPPORTED;
        }
      }, 
      FAILED {
        @Override
        protected TrackingServerProto.CommandAnswer rpcCommandAnswer() {
          return TrackingServerProto.CommandAnswer.COMMAND_ANSWER_FAILED;
        }
      };

      protected static CommandAnswer translateFromRpc(TrackingServerProto.CommandAnswer rpcCommandAnswer) {
        switch (rpcCommandAnswer) {
          case COMMAND_ANSWER_ACCEPTED: default: 
            return CommandAnswer.ACCEPTED;
          case COMMAND_ANSWER_TEMPORARILY_REJECTED: 
            return CommandAnswer.TEMPORARILY_REJECTED;
          case COMMAND_ANSWER_DENIED: 
            return CommandAnswer.DENIED;
          case COMMAND_ANSWER_UNSUPPORTED: 
            return CommandAnswer.UNSUPPORTED;
          case COMMAND_ANSWER_FAILED: 
            return CommandAnswer.FAILED;
        }
      }

      protected abstract TrackingServerProto.CommandAnswer rpcCommandAnswer();
    }


    public static class TrackPoint {
      private Float pointX;
      private Float pointY;
      private Float radius;

      public TrackPoint(Float pointX, Float pointY, Float radius) {
        this.pointX = pointX;
        this.pointY = pointY;
        this.radius = radius;
      }
      public Float getPointX() {
        return pointX;
      }
      public Float getPointY() {
        return pointY;
      }
      public Float getRadius() {
        return radius;
      }

      protected TrackingServerProto.TrackPoint rpcTrackPoint() {
        return TrackingServerProto.TrackPoint.newBuilder()
          .setPointX(this.pointX)
          .setPointY(this.pointY)
          .setRadius(this.radius)
          .build();
      }

      protected static TrackPoint translateFromRpc(TrackingServerProto.TrackPoint rpcTrackPoint) {
        return new TrackPoint(
                rpcTrackPoint.getPointX(),
                rpcTrackPoint.getPointY(),
                rpcTrackPoint.getRadius());
      }
    }


    public static class TrackRectangle {
      private Float topLeftCornerX;
      private Float topLeftCornerY;
      private Float bottomRightCornerX;
      private Float bottomRightCornerY;

      public TrackRectangle(Float topLeftCornerX, Float topLeftCornerY, Float bottomRightCornerX, Float bottomRightCornerY) {
        this.topLeftCornerX = topLeftCornerX;
        this.topLeftCornerY = topLeftCornerY;
        this.bottomRightCornerX = bottomRightCornerX;
        this.bottomRightCornerY = bottomRightCornerY;
      }
      public Float getTopLeftCornerX() {
        return topLeftCornerX;
      }
      public Float getTopLeftCornerY() {
        return topLeftCornerY;
      }
      public Float getBottomRightCornerX() {
        return bottomRightCornerX;
      }
      public Float getBottomRightCornerY() {
        return bottomRightCornerY;
      }

      protected TrackingServerProto.TrackRectangle rpcTrackRectangle() {
        return TrackingServerProto.TrackRectangle.newBuilder()
          .setTopLeftCornerX(this.topLeftCornerX)
          .setTopLeftCornerY(this.topLeftCornerY)
          .setBottomRightCornerX(this.bottomRightCornerX)
          .setBottomRightCornerY(this.bottomRightCornerY)
          .build();
      }

      protected static TrackRectangle translateFromRpc(TrackingServerProto.TrackRectangle rpcTrackRectangle) {
        return new TrackRectangle(
                rpcTrackRectangle.getTopLeftCornerX(),
                rpcTrackRectangle.getTopLeftCornerY(),
                rpcTrackRectangle.getBottomRightCornerX(),
                rpcTrackRectangle.getBottomRightCornerY());
      }
    }


    public static class TrackingServerResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected TrackingServerProto.TrackingServerResult.Result rpcResult() {
              return TrackingServerProto.TrackingServerResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected TrackingServerProto.TrackingServerResult.Result rpcResult() {
              return TrackingServerProto.TrackingServerResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected TrackingServerProto.TrackingServerResult.Result rpcResult() {
              return TrackingServerProto.TrackingServerResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected TrackingServerProto.TrackingServerResult.Result rpcResult() {
              return TrackingServerProto.TrackingServerResult.Result.RESULT_CONNECTION_ERROR;
            }
          };

          protected static Result translateFromRpc(TrackingServerProto.TrackingServerResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
            }
          }

          protected abstract TrackingServerProto.TrackingServerResult.Result rpcResult();
        }

      public TrackingServerResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected TrackingServerProto.TrackingServerResult rpcTrackingServerResult() {
        return TrackingServerProto.TrackingServerResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static TrackingServerResult translateFromRpc(TrackingServerProto.TrackingServerResult rpcTrackingServerResult) {
        return new TrackingServerResult(
                Result.translateFromRpc(rpcTrackingServerResult.getResult()),
                rpcTrackingServerResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable setTrackingPointStatus(@NonNull TrackPoint trackedPoint) {

      TrackingServerProto.SetTrackingPointStatusRequest request = TrackingServerProto.SetTrackingPointStatusRequest.newBuilder()
        .setTrackedPoint(trackedPoint.rpcTrackPoint())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setTrackingPointStatus(request, new StreamObserver<TrackingServerProto.SetTrackingPointStatusResponse>() {

          @Override
          public void onNext(TrackingServerProto.SetTrackingPointStatusResponse value) {
            emitter.onComplete();
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setTrackingRectangleStatus(@NonNull TrackRectangle trackedRectangle) {

      TrackingServerProto.SetTrackingRectangleStatusRequest request = TrackingServerProto.SetTrackingRectangleStatusRequest.newBuilder()
        .setTrackedRectangle(trackedRectangle.rpcTrackRectangle())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setTrackingRectangleStatus(request, new StreamObserver<TrackingServerProto.SetTrackingRectangleStatusResponse>() {

          @Override
          public void onNext(TrackingServerProto.SetTrackingRectangleStatusResponse value) {
            emitter.onComplete();
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setTrackingOffStatus() {

      TrackingServerProto.SetTrackingOffStatusRequest request = TrackingServerProto.SetTrackingOffStatusRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setTrackingOffStatus(request, new StreamObserver<TrackingServerProto.SetTrackingOffStatusResponse>() {

          @Override
          public void onNext(TrackingServerProto.SetTrackingOffStatusResponse value) {
            emitter.onComplete();
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<TrackingServer.TrackPoint> trackingPointCommandProcessor = PublishProcessor.create();
    private final Flowable<TrackingServer.TrackPoint> trackingPointCommand = trackingPointCommandProcessor.onBackpressureBuffer().share();;
    private volatile boolean isTrackingPointCommandInitialized = false;

    private void processTrackingPointCommand() {
      TrackingServerProto.SubscribeTrackingPointCommandRequest request = TrackingServerProto.SubscribeTrackingPointCommandRequest.newBuilder()
        .build();

      stub.subscribeTrackingPointCommand(request, new StreamObserver<TrackingServerProto.TrackingPointCommandResponse>() {

        @Override
        public void onNext(TrackingServerProto.TrackingPointCommandResponse value) {
          trackingPointCommandProcessor.onNext(TrackPoint.translateFromRpc(value.getTrackPoint()));
        }

        @Override
        public void onError(Throwable t) {
          trackingPointCommandProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          trackingPointCommandProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<TrackingServer.TrackPoint> getTrackingPointCommand() {
      if (!isTrackingPointCommandInitialized) {
        synchronized (this) {
          if (!isTrackingPointCommandInitialized) {
            MavsdkEventQueue.executor().execute(() -> processTrackingPointCommand());
            isTrackingPointCommandInitialized = true;
          }
        }
      }
      return trackingPointCommand;
    }



    // Infinite stream
    private final FlowableProcessor<TrackingServer.TrackRectangle> trackingRectangleCommandProcessor = PublishProcessor.create();
    private final Flowable<TrackingServer.TrackRectangle> trackingRectangleCommand = trackingRectangleCommandProcessor.onBackpressureBuffer().share();;
    private volatile boolean isTrackingRectangleCommandInitialized = false;

    private void processTrackingRectangleCommand() {
      TrackingServerProto.SubscribeTrackingRectangleCommandRequest request = TrackingServerProto.SubscribeTrackingRectangleCommandRequest.newBuilder()
        .build();

      stub.subscribeTrackingRectangleCommand(request, new StreamObserver<TrackingServerProto.TrackingRectangleCommandResponse>() {

        @Override
        public void onNext(TrackingServerProto.TrackingRectangleCommandResponse value) {
          trackingRectangleCommandProcessor.onNext(TrackRectangle.translateFromRpc(value.getTrackRectangle()));
        }

        @Override
        public void onError(Throwable t) {
          trackingRectangleCommandProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          trackingRectangleCommandProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<TrackingServer.TrackRectangle> getTrackingRectangleCommand() {
      if (!isTrackingRectangleCommandInitialized) {
        synchronized (this) {
          if (!isTrackingRectangleCommandInitialized) {
            MavsdkEventQueue.executor().execute(() -> processTrackingRectangleCommand());
            isTrackingRectangleCommandInitialized = true;
          }
        }
      }
      return trackingRectangleCommand;
    }



    // Infinite stream
    private final FlowableProcessor<Integer> trackingOffCommandProcessor = PublishProcessor.create();
    private final Flowable<Integer> trackingOffCommand = trackingOffCommandProcessor.onBackpressureBuffer().share();;
    private volatile boolean isTrackingOffCommandInitialized = false;

    private void processTrackingOffCommand() {
      TrackingServerProto.SubscribeTrackingOffCommandRequest request = TrackingServerProto.SubscribeTrackingOffCommandRequest.newBuilder()
        .build();

      stub.subscribeTrackingOffCommand(request, new StreamObserver<TrackingServerProto.TrackingOffCommandResponse>() {

        @Override
        public void onNext(TrackingServerProto.TrackingOffCommandResponse value) {
          trackingOffCommandProcessor.onNext(value.getDummy());
        }

        @Override
        public void onError(Throwable t) {
          trackingOffCommandProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          trackingOffCommandProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Integer> getTrackingOffCommand() {
      if (!isTrackingOffCommandInitialized) {
        synchronized (this) {
          if (!isTrackingOffCommandInitialized) {
            MavsdkEventQueue.executor().execute(() -> processTrackingOffCommand());
            isTrackingOffCommandInitialized = true;
          }
        }
      }
      return trackingOffCommand;
    }


    @CheckReturnValue
    public Completable respondTrackingPointCommand(@NonNull CommandAnswer commandAnswer) {

      TrackingServerProto.RespondTrackingPointCommandRequest request = TrackingServerProto.RespondTrackingPointCommandRequest.newBuilder()
        .setCommandAnswer(commandAnswer.rpcCommandAnswer())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.respondTrackingPointCommand(request, new StreamObserver<TrackingServerProto.RespondTrackingPointCommandResponse>() {

          @Override
          public void onNext(TrackingServerProto.RespondTrackingPointCommandResponse value) {
            TrackingServerResult result = TrackingServerResult.translateFromRpc(value.getTrackingServerResult());

            if (result.result != TrackingServerResult.Result.SUCCESS) {
              emitter.onError(new TrackingServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable respondTrackingRectangleCommand(@NonNull CommandAnswer commandAnswer) {

      TrackingServerProto.RespondTrackingRectangleCommandRequest request = TrackingServerProto.RespondTrackingRectangleCommandRequest.newBuilder()
        .setCommandAnswer(commandAnswer.rpcCommandAnswer())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.respondTrackingRectangleCommand(request, new StreamObserver<TrackingServerProto.RespondTrackingRectangleCommandResponse>() {

          @Override
          public void onNext(TrackingServerProto.RespondTrackingRectangleCommandResponse value) {
            TrackingServerResult result = TrackingServerResult.translateFromRpc(value.getTrackingServerResult());

            if (result.result != TrackingServerResult.Result.SUCCESS) {
              emitter.onError(new TrackingServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable respondTrackingOffCommand(@NonNull CommandAnswer commandAnswer) {

      TrackingServerProto.RespondTrackingOffCommandRequest request = TrackingServerProto.RespondTrackingOffCommandRequest.newBuilder()
        .setCommandAnswer(commandAnswer.rpcCommandAnswer())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.respondTrackingOffCommand(request, new StreamObserver<TrackingServerProto.RespondTrackingOffCommandResponse>() {

          @Override
          public void onNext(TrackingServerProto.RespondTrackingOffCommandResponse value) {
            TrackingServerResult result = TrackingServerResult.translateFromRpc(value.getTrackingServerResult());

            if (result.result != TrackingServerResult.Result.SUCCESS) {
              emitter.onError(new TrackingServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}