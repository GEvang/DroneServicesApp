package io.mavsdk.transponder;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Transponder implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Transponder.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private TransponderServiceGrpc.TransponderServiceStub stub;

  private volatile boolean isInitialized = false;

  public Transponder(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Transponder() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = TransponderServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class TransponderException extends MavsdkException {
    private TransponderResult.Result code;
    private String description;

    public TransponderException(TransponderResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public TransponderResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum AdsbEmitterType {
      
      NO_INFO {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_NO_INFO;
        }
      }, 
      LIGHT {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_LIGHT;
        }
      }, 
      SMALL {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_SMALL;
        }
      }, 
      LARGE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_LARGE;
        }
      }, 
      HIGH_VORTEX_LARGE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_HIGH_VORTEX_LARGE;
        }
      }, 
      HEAVY {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_HEAVY;
        }
      }, 
      HIGHLY_MANUV {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_HIGHLY_MANUV;
        }
      }, 
      ROTOCRAFT {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_ROTOCRAFT;
        }
      }, 
      UNASSIGNED {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_UNASSIGNED;
        }
      }, 
      GLIDER {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_GLIDER;
        }
      }, 
      LIGHTER_AIR {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_LIGHTER_AIR;
        }
      }, 
      PARACHUTE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_PARACHUTE;
        }
      }, 
      ULTRA_LIGHT {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_ULTRA_LIGHT;
        }
      }, 
      UNASSIGNED2 {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_UNASSIGNED2;
        }
      }, 
      UAV {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_UAV;
        }
      }, 
      SPACE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_SPACE;
        }
      }, 
      UNASSGINED3 {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_UNASSGINED3;
        }
      }, 
      EMERGENCY_SURFACE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_EMERGENCY_SURFACE;
        }
      }, 
      SERVICE_SURFACE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_SERVICE_SURFACE;
        }
      }, 
      POINT_OBSTACLE {
        @Override
        protected TransponderProto.AdsbEmitterType rpcAdsbEmitterType() {
          return TransponderProto.AdsbEmitterType.ADSB_EMITTER_TYPE_POINT_OBSTACLE;
        }
      };

      protected static AdsbEmitterType translateFromRpc(TransponderProto.AdsbEmitterType rpcAdsbEmitterType) {
        switch (rpcAdsbEmitterType) {
          case ADSB_EMITTER_TYPE_NO_INFO: default: 
            return AdsbEmitterType.NO_INFO;
          case ADSB_EMITTER_TYPE_LIGHT: 
            return AdsbEmitterType.LIGHT;
          case ADSB_EMITTER_TYPE_SMALL: 
            return AdsbEmitterType.SMALL;
          case ADSB_EMITTER_TYPE_LARGE: 
            return AdsbEmitterType.LARGE;
          case ADSB_EMITTER_TYPE_HIGH_VORTEX_LARGE: 
            return AdsbEmitterType.HIGH_VORTEX_LARGE;
          case ADSB_EMITTER_TYPE_HEAVY: 
            return AdsbEmitterType.HEAVY;
          case ADSB_EMITTER_TYPE_HIGHLY_MANUV: 
            return AdsbEmitterType.HIGHLY_MANUV;
          case ADSB_EMITTER_TYPE_ROTOCRAFT: 
            return AdsbEmitterType.ROTOCRAFT;
          case ADSB_EMITTER_TYPE_UNASSIGNED: 
            return AdsbEmitterType.UNASSIGNED;
          case ADSB_EMITTER_TYPE_GLIDER: 
            return AdsbEmitterType.GLIDER;
          case ADSB_EMITTER_TYPE_LIGHTER_AIR: 
            return AdsbEmitterType.LIGHTER_AIR;
          case ADSB_EMITTER_TYPE_PARACHUTE: 
            return AdsbEmitterType.PARACHUTE;
          case ADSB_EMITTER_TYPE_ULTRA_LIGHT: 
            return AdsbEmitterType.ULTRA_LIGHT;
          case ADSB_EMITTER_TYPE_UNASSIGNED2: 
            return AdsbEmitterType.UNASSIGNED2;
          case ADSB_EMITTER_TYPE_UAV: 
            return AdsbEmitterType.UAV;
          case ADSB_EMITTER_TYPE_SPACE: 
            return AdsbEmitterType.SPACE;
          case ADSB_EMITTER_TYPE_UNASSGINED3: 
            return AdsbEmitterType.UNASSGINED3;
          case ADSB_EMITTER_TYPE_EMERGENCY_SURFACE: 
            return AdsbEmitterType.EMERGENCY_SURFACE;
          case ADSB_EMITTER_TYPE_SERVICE_SURFACE: 
            return AdsbEmitterType.SERVICE_SURFACE;
          case ADSB_EMITTER_TYPE_POINT_OBSTACLE: 
            return AdsbEmitterType.POINT_OBSTACLE;
        }
      }

      protected abstract TransponderProto.AdsbEmitterType rpcAdsbEmitterType();
    }


    public static class AdsbVehicle {
      private Integer icaoAddress;
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float headingDeg;
      private Float horizontalVelocityMS;
      private Float verticalVelocityMS;
      private String callsign;
      private AdsbEmitterType emitterType;
      private Integer squawk;

      public AdsbVehicle(Integer icaoAddress, Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float headingDeg, Float horizontalVelocityMS, Float verticalVelocityMS, String callsign, AdsbEmitterType emitterType, Integer squawk) {
        this.icaoAddress = icaoAddress;
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.headingDeg = headingDeg;
        this.horizontalVelocityMS = horizontalVelocityMS;
        this.verticalVelocityMS = verticalVelocityMS;
        this.callsign = callsign;
        this.emitterType = emitterType;
        this.squawk = squawk;
      }
      public Integer getIcaoAddress() {
        return icaoAddress;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getHeadingDeg() {
        return headingDeg;
      }
      public Float getHorizontalVelocityMS() {
        return horizontalVelocityMS;
      }
      public Float getVerticalVelocityMS() {
        return verticalVelocityMS;
      }
      public String getCallsign() {
        return callsign;
      }
      public AdsbEmitterType getEmitterType() {
        return emitterType;
      }
      public Integer getSquawk() {
        return squawk;
      }

      protected TransponderProto.AdsbVehicle rpcAdsbVehicle() {
        return TransponderProto.AdsbVehicle.newBuilder()
          .setIcaoAddress(this.icaoAddress)
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setHeadingDeg(this.headingDeg)
          .setHorizontalVelocityMS(this.horizontalVelocityMS)
          .setVerticalVelocityMS(this.verticalVelocityMS)
          .setCallsign(this.callsign)
          .setEmitterType(this.emitterType.rpcAdsbEmitterType())
          .setSquawk(this.squawk)
          .build();
      }

      protected static AdsbVehicle translateFromRpc(TransponderProto.AdsbVehicle rpcAdsbVehicle) {
        return new AdsbVehicle(
                rpcAdsbVehicle.getIcaoAddress(),
                rpcAdsbVehicle.getLatitudeDeg(),
                rpcAdsbVehicle.getLongitudeDeg(),
                rpcAdsbVehicle.getAbsoluteAltitudeM(),
                rpcAdsbVehicle.getHeadingDeg(),
                rpcAdsbVehicle.getHorizontalVelocityMS(),
                rpcAdsbVehicle.getVerticalVelocityMS(),
                rpcAdsbVehicle.getCallsign(),
                AdsbEmitterType.translateFromRpc(rpcAdsbVehicle.getEmitterType()),
                rpcAdsbVehicle.getSquawk());
      }
    }


    public static class TransponderResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected TransponderProto.TransponderResult.Result rpcResult() {
              return TransponderProto.TransponderResult.Result.RESULT_TIMEOUT;
            }
          };

          protected static Result translateFromRpc(TransponderProto.TransponderResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
            }
          }

          protected abstract TransponderProto.TransponderResult.Result rpcResult();
        }

      public TransponderResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected TransponderProto.TransponderResult rpcTransponderResult() {
        return TransponderProto.TransponderResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static TransponderResult translateFromRpc(TransponderProto.TransponderResult rpcTransponderResult) {
        return new TransponderResult(
                Result.translateFromRpc(rpcTransponderResult.getResult()),
                rpcTransponderResult.getResultStr());
      }
    }



    // Infinite stream
    private final FlowableProcessor<Transponder.AdsbVehicle> transponderProcessor = PublishProcessor.create();
    private final Flowable<Transponder.AdsbVehicle> transponder = transponderProcessor.onBackpressureBuffer().share();;
    private volatile boolean isTransponderInitialized = false;

    private void processTransponder() {
      TransponderProto.SubscribeTransponderRequest request = TransponderProto.SubscribeTransponderRequest.newBuilder()
        .build();

      stub.subscribeTransponder(request, new StreamObserver<TransponderProto.TransponderResponse>() {

        @Override
        public void onNext(TransponderProto.TransponderResponse value) {
          transponderProcessor.onNext(AdsbVehicle.translateFromRpc(value.getTransponder()));
        }

        @Override
        public void onError(Throwable t) {
          transponderProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          transponderProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Transponder.AdsbVehicle> getTransponder() {
      if (!isTransponderInitialized) {
        synchronized (this) {
          if (!isTransponderInitialized) {
            MavsdkEventQueue.executor().execute(() -> processTransponder());
            isTransponderInitialized = true;
          }
        }
      }
      return transponder;
    }


    @CheckReturnValue
    public Completable setRateTransponder(@NonNull Double rateHz) {

      TransponderProto.SetRateTransponderRequest request = TransponderProto.SetRateTransponderRequest.newBuilder()
        .setRateHz(rateHz)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setRateTransponder(request, new StreamObserver<TransponderProto.SetRateTransponderResponse>() {

          @Override
          public void onNext(TransponderProto.SetRateTransponderResponse value) {
            TransponderResult result = TransponderResult.translateFromRpc(value.getTransponderResult());

            if (result.result != TransponderResult.Result.SUCCESS) {
              emitter.onError(new TransponderException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}