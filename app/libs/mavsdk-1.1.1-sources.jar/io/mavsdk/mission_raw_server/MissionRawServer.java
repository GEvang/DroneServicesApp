package io.mavsdk.mission_raw_server;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MissionRawServer implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(MissionRawServer.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private MissionRawServerServiceGrpc.MissionRawServerServiceStub stub;

  private volatile boolean isInitialized = false;

  public MissionRawServer(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public MissionRawServer() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = MissionRawServerServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class MissionRawServerException extends MavsdkException {
    private MissionRawServerResult.Result code;
    private String description;

    public MissionRawServerException(MissionRawServerResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public MissionRawServerResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class MissionItem {
      private Integer seq;
      private Integer frame;
      private Integer command;
      private Integer current;
      private Integer autocontinue;
      private Float param1;
      private Float param2;
      private Float param3;
      private Float param4;
      private Integer x;
      private Integer y;
      private Float z;
      private Integer missionType;

      public MissionItem(Integer seq, Integer frame, Integer command, Integer current, Integer autocontinue, Float param1, Float param2, Float param3, Float param4, Integer x, Integer y, Float z, Integer missionType) {
        this.seq = seq;
        this.frame = frame;
        this.command = command;
        this.current = current;
        this.autocontinue = autocontinue;
        this.param1 = param1;
        this.param2 = param2;
        this.param3 = param3;
        this.param4 = param4;
        this.x = x;
        this.y = y;
        this.z = z;
        this.missionType = missionType;
      }
      public Integer getSeq() {
        return seq;
      }
      public Integer getFrame() {
        return frame;
      }
      public Integer getCommand() {
        return command;
      }
      public Integer getCurrent() {
        return current;
      }
      public Integer getAutocontinue() {
        return autocontinue;
      }
      public Float getParam1() {
        return param1;
      }
      public Float getParam2() {
        return param2;
      }
      public Float getParam3() {
        return param3;
      }
      public Float getParam4() {
        return param4;
      }
      public Integer getX() {
        return x;
      }
      public Integer getY() {
        return y;
      }
      public Float getZ() {
        return z;
      }
      public Integer getMissionType() {
        return missionType;
      }

      protected MissionRawServerProto.MissionItem rpcMissionItem() {
        return MissionRawServerProto.MissionItem.newBuilder()
          .setSeq(this.seq)
          .setFrame(this.frame)
          .setCommand(this.command)
          .setCurrent(this.current)
          .setAutocontinue(this.autocontinue)
          .setParam1(this.param1)
          .setParam2(this.param2)
          .setParam3(this.param3)
          .setParam4(this.param4)
          .setX(this.x)
          .setY(this.y)
          .setZ(this.z)
          .setMissionType(this.missionType)
          .build();
      }

      protected static MissionItem translateFromRpc(MissionRawServerProto.MissionItem rpcMissionItem) {
        return new MissionItem(
                rpcMissionItem.getSeq(),
                rpcMissionItem.getFrame(),
                rpcMissionItem.getCommand(),
                rpcMissionItem.getCurrent(),
                rpcMissionItem.getAutocontinue(),
                rpcMissionItem.getParam1(),
                rpcMissionItem.getParam2(),
                rpcMissionItem.getParam3(),
                rpcMissionItem.getParam4(),
                rpcMissionItem.getX(),
                rpcMissionItem.getY(),
                rpcMissionItem.getZ(),
                rpcMissionItem.getMissionType());
      }
    }


    public static class MissionPlan {
      private List<MissionItem> missionItems;

      public MissionPlan(List<MissionItem> missionItems) {
        this.missionItems = missionItems;
      }
      public List<MissionItem> getMissionItems() {
        return missionItems;
      }

      protected MissionRawServerProto.MissionPlan rpcMissionPlan() {
        return MissionRawServerProto.MissionPlan.newBuilder()
          .addAllMissionItems(missionItems.stream().map(MissionItem::rpcMissionItem).collect(Collectors.toList()))
          .build();
      }

      protected static MissionPlan translateFromRpc(MissionRawServerProto.MissionPlan rpcMissionPlan) {
        return new MissionPlan(
                    rpcMissionPlan.getMissionItemsList().stream().map(MissionItem::translateFromRpc).collect(Collectors.toList()));
      }
    }


    public static class MissionProgress {
      private Integer current;
      private Integer total;

      public MissionProgress(Integer current, Integer total) {
        this.current = current;
        this.total = total;
      }
      public Integer getCurrent() {
        return current;
      }
      public Integer getTotal() {
        return total;
      }

      protected MissionRawServerProto.MissionProgress rpcMissionProgress() {
        return MissionRawServerProto.MissionProgress.newBuilder()
          .setCurrent(this.current)
          .setTotal(this.total)
          .build();
      }

      protected static MissionProgress translateFromRpc(MissionRawServerProto.MissionProgress rpcMissionProgress) {
        return new MissionProgress(
                rpcMissionProgress.getCurrent(),
                rpcMissionProgress.getTotal());
      }
    }


    public static class MissionRawServerResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_SUCCESS;
            }
          }, 
          ERROR {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_ERROR;
            }
          }, 
          TOO_MANY_MISSION_ITEMS {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_TOO_MANY_MISSION_ITEMS;
            }
          }, 
          BUSY {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_BUSY;
            }
          }, 
          TIMEOUT {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_TIMEOUT;
            }
          }, 
          INVALID_ARGUMENT {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_INVALID_ARGUMENT;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_UNSUPPORTED;
            }
          }, 
          NO_MISSION_AVAILABLE {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_NO_MISSION_AVAILABLE;
            }
          }, 
          UNSUPPORTED_MISSION_CMD {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_UNSUPPORTED_MISSION_CMD;
            }
          }, 
          TRANSFER_CANCELLED {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_TRANSFER_CANCELLED;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          NEXT {
            @Override
            protected MissionRawServerProto.MissionRawServerResult.Result rpcResult() {
              return MissionRawServerProto.MissionRawServerResult.Result.RESULT_NEXT;
            }
          };

          protected static Result translateFromRpc(MissionRawServerProto.MissionRawServerResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_TOO_MANY_MISSION_ITEMS: 
                return Result.TOO_MANY_MISSION_ITEMS;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_INVALID_ARGUMENT: 
                return Result.INVALID_ARGUMENT;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
              case RESULT_NO_MISSION_AVAILABLE: 
                return Result.NO_MISSION_AVAILABLE;
              case RESULT_UNSUPPORTED_MISSION_CMD: 
                return Result.UNSUPPORTED_MISSION_CMD;
              case RESULT_TRANSFER_CANCELLED: 
                return Result.TRANSFER_CANCELLED;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_NEXT: 
                return Result.NEXT;
            }
          }

          protected abstract MissionRawServerProto.MissionRawServerResult.Result rpcResult();
        }

      public MissionRawServerResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected MissionRawServerProto.MissionRawServerResult rpcMissionRawServerResult() {
        return MissionRawServerProto.MissionRawServerResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static MissionRawServerResult translateFromRpc(MissionRawServerProto.MissionRawServerResult rpcMissionRawServerResult) {
        return new MissionRawServerResult(
                Result.translateFromRpc(rpcMissionRawServerResult.getResult()),
                rpcMissionRawServerResult.getResultStr());
      }
    }



    // Infinite stream
    private final FlowableProcessor<MissionRawServer.MissionPlan> incomingMissionProcessor = PublishProcessor.create();
    private final Flowable<MissionRawServer.MissionPlan> incomingMission = incomingMissionProcessor.onBackpressureBuffer().share();;
    private volatile boolean isIncomingMissionInitialized = false;

    private void processIncomingMission() {
      MissionRawServerProto.SubscribeIncomingMissionRequest request = MissionRawServerProto.SubscribeIncomingMissionRequest.newBuilder()
        .build();

      stub.subscribeIncomingMission(request, new StreamObserver<MissionRawServerProto.IncomingMissionResponse>() {

        @Override
        public void onNext(MissionRawServerProto.IncomingMissionResponse value) {
          incomingMissionProcessor.onNext(MissionPlan.translateFromRpc(value.getMissionPlan()));
        }

        @Override
        public void onError(Throwable t) {
          incomingMissionProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          incomingMissionProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<MissionRawServer.MissionPlan> getIncomingMission() {
      if (!isIncomingMissionInitialized) {
        synchronized (this) {
          if (!isIncomingMissionInitialized) {
            MavsdkEventQueue.executor().execute(() -> processIncomingMission());
            isIncomingMissionInitialized = true;
          }
        }
      }
      return incomingMission;
    }



    // Infinite stream
    private final FlowableProcessor<MissionRawServer.MissionItem> currentItemChangedProcessor = PublishProcessor.create();
    private final Flowable<MissionRawServer.MissionItem> currentItemChanged = currentItemChangedProcessor.onBackpressureBuffer().share();;
    private volatile boolean isCurrentItemChangedInitialized = false;

    private void processCurrentItemChanged() {
      MissionRawServerProto.SubscribeCurrentItemChangedRequest request = MissionRawServerProto.SubscribeCurrentItemChangedRequest.newBuilder()
        .build();

      stub.subscribeCurrentItemChanged(request, new StreamObserver<MissionRawServerProto.CurrentItemChangedResponse>() {

        @Override
        public void onNext(MissionRawServerProto.CurrentItemChangedResponse value) {
          currentItemChangedProcessor.onNext(MissionItem.translateFromRpc(value.getMissionItem()));
        }

        @Override
        public void onError(Throwable t) {
          currentItemChangedProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          currentItemChangedProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<MissionRawServer.MissionItem> getCurrentItemChanged() {
      if (!isCurrentItemChangedInitialized) {
        synchronized (this) {
          if (!isCurrentItemChangedInitialized) {
            MavsdkEventQueue.executor().execute(() -> processCurrentItemChanged());
            isCurrentItemChangedInitialized = true;
          }
        }
      }
      return currentItemChanged;
    }


    @CheckReturnValue
    public Completable setCurrentItemComplete() {

      MissionRawServerProto.SetCurrentItemCompleteRequest request = MissionRawServerProto.SetCurrentItemCompleteRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setCurrentItemComplete(request, new StreamObserver<MissionRawServerProto.SetCurrentItemCompleteResponse>() {

          @Override
          public void onNext(MissionRawServerProto.SetCurrentItemCompleteResponse value) {
            emitter.onComplete();
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<Integer> clearAllProcessor = PublishProcessor.create();
    private final Flowable<Integer> clearAll = clearAllProcessor.onBackpressureBuffer().share();;
    private volatile boolean isClearAllInitialized = false;

    private void processClearAll() {
      MissionRawServerProto.SubscribeClearAllRequest request = MissionRawServerProto.SubscribeClearAllRequest.newBuilder()
        .build();

      stub.subscribeClearAll(request, new StreamObserver<MissionRawServerProto.ClearAllResponse>() {

        @Override
        public void onNext(MissionRawServerProto.ClearAllResponse value) {
          clearAllProcessor.onNext(value.getClearType());
        }

        @Override
        public void onError(Throwable t) {
          clearAllProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          clearAllProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Integer> getClearAll() {
      if (!isClearAllInitialized) {
        synchronized (this) {
          if (!isClearAllInitialized) {
            MavsdkEventQueue.executor().execute(() -> processClearAll());
            isClearAllInitialized = true;
          }
        }
      }
      return clearAll;
    }


}