package io.mavsdk.failure;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Failure implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Failure.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private FailureServiceGrpc.FailureServiceStub stub;

  private volatile boolean isInitialized = false;

  public Failure(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Failure() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = FailureServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class FailureException extends MavsdkException {
    private FailureResult.Result code;
    private String description;

    public FailureException(FailureResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public FailureResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum FailureUnit {
      
      SENSOR_GYRO {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_GYRO;
        }
      }, 
      SENSOR_ACCEL {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_ACCEL;
        }
      }, 
      SENSOR_MAG {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_MAG;
        }
      }, 
      SENSOR_BARO {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_BARO;
        }
      }, 
      SENSOR_GPS {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_GPS;
        }
      }, 
      SENSOR_OPTICAL_FLOW {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_OPTICAL_FLOW;
        }
      }, 
      SENSOR_VIO {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_VIO;
        }
      }, 
      SENSOR_DISTANCE_SENSOR {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_DISTANCE_SENSOR;
        }
      }, 
      SENSOR_AIRSPEED {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SENSOR_AIRSPEED;
        }
      }, 
      SYSTEM_BATTERY {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SYSTEM_BATTERY;
        }
      }, 
      SYSTEM_MOTOR {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SYSTEM_MOTOR;
        }
      }, 
      SYSTEM_SERVO {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SYSTEM_SERVO;
        }
      }, 
      SYSTEM_AVOIDANCE {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SYSTEM_AVOIDANCE;
        }
      }, 
      SYSTEM_RC_SIGNAL {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SYSTEM_RC_SIGNAL;
        }
      }, 
      SYSTEM_MAVLINK_SIGNAL {
        @Override
        protected FailureProto.FailureUnit rpcFailureUnit() {
          return FailureProto.FailureUnit.FAILURE_UNIT_SYSTEM_MAVLINK_SIGNAL;
        }
      };

      protected static FailureUnit translateFromRpc(FailureProto.FailureUnit rpcFailureUnit) {
        switch (rpcFailureUnit) {
          case FAILURE_UNIT_SENSOR_GYRO: default: 
            return FailureUnit.SENSOR_GYRO;
          case FAILURE_UNIT_SENSOR_ACCEL: 
            return FailureUnit.SENSOR_ACCEL;
          case FAILURE_UNIT_SENSOR_MAG: 
            return FailureUnit.SENSOR_MAG;
          case FAILURE_UNIT_SENSOR_BARO: 
            return FailureUnit.SENSOR_BARO;
          case FAILURE_UNIT_SENSOR_GPS: 
            return FailureUnit.SENSOR_GPS;
          case FAILURE_UNIT_SENSOR_OPTICAL_FLOW: 
            return FailureUnit.SENSOR_OPTICAL_FLOW;
          case FAILURE_UNIT_SENSOR_VIO: 
            return FailureUnit.SENSOR_VIO;
          case FAILURE_UNIT_SENSOR_DISTANCE_SENSOR: 
            return FailureUnit.SENSOR_DISTANCE_SENSOR;
          case FAILURE_UNIT_SENSOR_AIRSPEED: 
            return FailureUnit.SENSOR_AIRSPEED;
          case FAILURE_UNIT_SYSTEM_BATTERY: 
            return FailureUnit.SYSTEM_BATTERY;
          case FAILURE_UNIT_SYSTEM_MOTOR: 
            return FailureUnit.SYSTEM_MOTOR;
          case FAILURE_UNIT_SYSTEM_SERVO: 
            return FailureUnit.SYSTEM_SERVO;
          case FAILURE_UNIT_SYSTEM_AVOIDANCE: 
            return FailureUnit.SYSTEM_AVOIDANCE;
          case FAILURE_UNIT_SYSTEM_RC_SIGNAL: 
            return FailureUnit.SYSTEM_RC_SIGNAL;
          case FAILURE_UNIT_SYSTEM_MAVLINK_SIGNAL: 
            return FailureUnit.SYSTEM_MAVLINK_SIGNAL;
        }
      }

      protected abstract FailureProto.FailureUnit rpcFailureUnit();
    }
    public enum FailureType {
      
      OK {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_OK;
        }
      }, 
      OFF {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_OFF;
        }
      }, 
      STUCK {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_STUCK;
        }
      }, 
      GARBAGE {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_GARBAGE;
        }
      }, 
      WRONG {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_WRONG;
        }
      }, 
      SLOW {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_SLOW;
        }
      }, 
      DELAYED {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_DELAYED;
        }
      }, 
      INTERMITTENT {
        @Override
        protected FailureProto.FailureType rpcFailureType() {
          return FailureProto.FailureType.FAILURE_TYPE_INTERMITTENT;
        }
      };

      protected static FailureType translateFromRpc(FailureProto.FailureType rpcFailureType) {
        switch (rpcFailureType) {
          case FAILURE_TYPE_OK: default: 
            return FailureType.OK;
          case FAILURE_TYPE_OFF: 
            return FailureType.OFF;
          case FAILURE_TYPE_STUCK: 
            return FailureType.STUCK;
          case FAILURE_TYPE_GARBAGE: 
            return FailureType.GARBAGE;
          case FAILURE_TYPE_WRONG: 
            return FailureType.WRONG;
          case FAILURE_TYPE_SLOW: 
            return FailureType.SLOW;
          case FAILURE_TYPE_DELAYED: 
            return FailureType.DELAYED;
          case FAILURE_TYPE_INTERMITTENT: 
            return FailureType.INTERMITTENT;
        }
      }

      protected abstract FailureProto.FailureType rpcFailureType();
    }


    public static class FailureResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_UNSUPPORTED;
            }
          }, 
          DENIED {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_DENIED;
            }
          }, 
          DISABLED {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_DISABLED;
            }
          }, 
          TIMEOUT {
            @Override
            protected FailureProto.FailureResult.Result rpcResult() {
              return FailureProto.FailureResult.Result.RESULT_TIMEOUT;
            }
          };

          protected static Result translateFromRpc(FailureProto.FailureResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
              case RESULT_DENIED: 
                return Result.DENIED;
              case RESULT_DISABLED: 
                return Result.DISABLED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
            }
          }

          protected abstract FailureProto.FailureResult.Result rpcResult();
        }

      public FailureResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected FailureProto.FailureResult rpcFailureResult() {
        return FailureProto.FailureResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static FailureResult translateFromRpc(FailureProto.FailureResult rpcFailureResult) {
        return new FailureResult(
                Result.translateFromRpc(rpcFailureResult.getResult()),
                rpcFailureResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable inject(@NonNull FailureUnit failureUnit, @NonNull FailureType failureType, @NonNull Integer instance) {

      FailureProto.InjectRequest request = FailureProto.InjectRequest.newBuilder()
        .setFailureUnit(failureUnit.rpcFailureUnit())
        .setFailureType(failureType.rpcFailureType())
        .setInstance(instance)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.inject(request, new StreamObserver<FailureProto.InjectResponse>() {

          @Override
          public void onNext(FailureProto.InjectResponse value) {
            FailureResult result = FailureResult.translateFromRpc(value.getFailureResult());

            if (result.result != FailureResult.Result.SUCCESS) {
              emitter.onError(new FailureException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}