package io.mavsdk.param;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Param implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Param.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ParamServiceGrpc.ParamServiceStub stub;

  private volatile boolean isInitialized = false;

  public Param(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Param() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ParamServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ParamException extends MavsdkException {
    private ParamResult.Result code;
    private String description;

    public ParamException(ParamResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ParamResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class IntParam {
      private String name;
      private Integer value;

      public IntParam(String name, Integer value) {
        this.name = name;
        this.value = value;
      }
      public String getName() {
        return name;
      }
      public Integer getValue() {
        return value;
      }

      protected ParamProto.IntParam rpcIntParam() {
        return ParamProto.IntParam.newBuilder()
          .setName(this.name)
          .setValue(this.value)
          .build();
      }

      protected static IntParam translateFromRpc(ParamProto.IntParam rpcIntParam) {
        return new IntParam(
                rpcIntParam.getName(),
                rpcIntParam.getValue());
      }
    }


    public static class FloatParam {
      private String name;
      private Float value;

      public FloatParam(String name, Float value) {
        this.name = name;
        this.value = value;
      }
      public String getName() {
        return name;
      }
      public Float getValue() {
        return value;
      }

      protected ParamProto.FloatParam rpcFloatParam() {
        return ParamProto.FloatParam.newBuilder()
          .setName(this.name)
          .setValue(this.value)
          .build();
      }

      protected static FloatParam translateFromRpc(ParamProto.FloatParam rpcFloatParam) {
        return new FloatParam(
                rpcFloatParam.getName(),
                rpcFloatParam.getValue());
      }
    }


    public static class AllParams {
      private List<IntParam> intParams;
      private List<FloatParam> floatParams;

      public AllParams(List<IntParam> intParams, List<FloatParam> floatParams) {
        this.intParams = intParams;
        this.floatParams = floatParams;
      }
      public List<IntParam> getIntParams() {
        return intParams;
      }
      public List<FloatParam> getFloatParams() {
        return floatParams;
      }

      protected ParamProto.AllParams rpcAllParams() {
        return ParamProto.AllParams.newBuilder()
          .addAllIntParams(intParams.stream().map(IntParam::rpcIntParam).collect(Collectors.toList()))
          .addAllFloatParams(floatParams.stream().map(FloatParam::rpcFloatParam).collect(Collectors.toList()))
          .build();
      }

      protected static AllParams translateFromRpc(ParamProto.AllParams rpcAllParams) {
        return new AllParams(
                    rpcAllParams.getIntParamsList().stream().map(IntParam::translateFromRpc).collect(Collectors.toList()),
                    rpcAllParams.getFloatParamsList().stream().map(FloatParam::translateFromRpc).collect(Collectors.toList()));
      }
    }


    public static class ParamResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_SUCCESS;
            }
          }, 
          TIMEOUT {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_TIMEOUT;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          WRONG_TYPE {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_WRONG_TYPE;
            }
          }, 
          PARAM_NAME_TOO_LONG {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_PARAM_NAME_TOO_LONG;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ParamProto.ParamResult.Result rpcResult() {
              return ParamProto.ParamResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(ParamProto.ParamResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_WRONG_TYPE: 
                return Result.WRONG_TYPE;
              case RESULT_PARAM_NAME_TOO_LONG: 
                return Result.PARAM_NAME_TOO_LONG;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract ParamProto.ParamResult.Result rpcResult();
        }

      public ParamResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ParamProto.ParamResult rpcParamResult() {
        return ParamProto.ParamResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ParamResult translateFromRpc(ParamProto.ParamResult rpcParamResult) {
        return new ParamResult(
                Result.translateFromRpc(rpcParamResult.getResult()),
                rpcParamResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Single<Integer> getParamInt(@NonNull String name) {
      ParamProto.GetParamIntRequest request = ParamProto.GetParamIntRequest.newBuilder()
        .setName(name)
        .build();

      Single<Integer> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getParamInt(request, new StreamObserver<ParamProto.GetParamIntResponse>() {

          @Override
          public void onNext(ParamProto.GetParamIntResponse value) {
            ParamResult result = ParamResult.translateFromRpc(value.getParamResult());

            if (result.result != ParamResult.Result.SUCCESS) {
              emitter.onError(new ParamException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getValue());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setParamInt(@NonNull String name, @NonNull Integer value) {

      ParamProto.SetParamIntRequest request = ParamProto.SetParamIntRequest.newBuilder()
        .setName(name)
        .setValue(value)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setParamInt(request, new StreamObserver<ParamProto.SetParamIntResponse>() {

          @Override
          public void onNext(ParamProto.SetParamIntResponse value) {
            ParamResult result = ParamResult.translateFromRpc(value.getParamResult());

            if (result.result != ParamResult.Result.SUCCESS) {
              emitter.onError(new ParamException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Float> getParamFloat(@NonNull String name) {
      ParamProto.GetParamFloatRequest request = ParamProto.GetParamFloatRequest.newBuilder()
        .setName(name)
        .build();

      Single<Float> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getParamFloat(request, new StreamObserver<ParamProto.GetParamFloatResponse>() {

          @Override
          public void onNext(ParamProto.GetParamFloatResponse value) {
            ParamResult result = ParamResult.translateFromRpc(value.getParamResult());

            if (result.result != ParamResult.Result.SUCCESS) {
              emitter.onError(new ParamException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getValue());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setParamFloat(@NonNull String name, @NonNull Float value) {

      ParamProto.SetParamFloatRequest request = ParamProto.SetParamFloatRequest.newBuilder()
        .setName(name)
        .setValue(value)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setParamFloat(request, new StreamObserver<ParamProto.SetParamFloatResponse>() {

          @Override
          public void onNext(ParamProto.SetParamFloatResponse value) {
            ParamResult result = ParamResult.translateFromRpc(value.getParamResult());

            if (result.result != ParamResult.Result.SUCCESS) {
              emitter.onError(new ParamException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Param.AllParams> getAllParams() {
      ParamProto.GetAllParamsRequest request = ParamProto.GetAllParamsRequest.newBuilder()
        .build();

      Single<Param.AllParams> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getAllParams(request, new StreamObserver<ParamProto.GetAllParamsResponse>() {

          @Override
          public void onNext(ParamProto.GetAllParamsResponse value) {
              emitter.onSuccess(AllParams.translateFromRpc(value.getParams()));
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}