package io.mavsdk.mission;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Mission implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Mission.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private MissionServiceGrpc.MissionServiceStub stub;

  private volatile boolean isInitialized = false;

  public Mission(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Mission() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = MissionServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class MissionException extends MavsdkException {
    private MissionResult.Result code;
    private String description;

    public MissionException(MissionResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public MissionResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class MissionItem {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float relativeAltitudeM;
      private Float speedMS;
      private Boolean isFlyThrough;
      private Float gimbalPitchDeg;
      private Float gimbalYawDeg;
      private CameraAction cameraAction;
      private Float loiterTimeS;
      private Double cameraPhotoIntervalS;
      private Float acceptanceRadiusM;
      private Float yawDeg;
      private Float cameraPhotoDistanceM;
      
        public enum CameraAction {
          
          NONE {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_NONE;
            }
          }, 
          TAKE_PHOTO {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_TAKE_PHOTO;
            }
          }, 
          START_PHOTO_INTERVAL {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_START_PHOTO_INTERVAL;
            }
          }, 
          STOP_PHOTO_INTERVAL {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_STOP_PHOTO_INTERVAL;
            }
          }, 
          START_VIDEO {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_START_VIDEO;
            }
          }, 
          STOP_VIDEO {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_STOP_VIDEO;
            }
          }, 
          START_PHOTO_DISTANCE {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_START_PHOTO_DISTANCE;
            }
          }, 
          STOP_PHOTO_DISTANCE {
            @Override
            protected MissionProto.MissionItem.CameraAction rpcCameraAction() {
              return MissionProto.MissionItem.CameraAction.CAMERA_ACTION_STOP_PHOTO_DISTANCE;
            }
          };

          protected static CameraAction translateFromRpc(MissionProto.MissionItem.CameraAction rpcCameraAction) {
            switch (rpcCameraAction) {
              case CAMERA_ACTION_NONE: default: 
                return CameraAction.NONE;
              case CAMERA_ACTION_TAKE_PHOTO: 
                return CameraAction.TAKE_PHOTO;
              case CAMERA_ACTION_START_PHOTO_INTERVAL: 
                return CameraAction.START_PHOTO_INTERVAL;
              case CAMERA_ACTION_STOP_PHOTO_INTERVAL: 
                return CameraAction.STOP_PHOTO_INTERVAL;
              case CAMERA_ACTION_START_VIDEO: 
                return CameraAction.START_VIDEO;
              case CAMERA_ACTION_STOP_VIDEO: 
                return CameraAction.STOP_VIDEO;
              case CAMERA_ACTION_START_PHOTO_DISTANCE: 
                return CameraAction.START_PHOTO_DISTANCE;
              case CAMERA_ACTION_STOP_PHOTO_DISTANCE: 
                return CameraAction.STOP_PHOTO_DISTANCE;
            }
          }

          protected abstract MissionProto.MissionItem.CameraAction rpcCameraAction();
        }

      public MissionItem(Double latitudeDeg, Double longitudeDeg, Float relativeAltitudeM, Float speedMS, Boolean isFlyThrough, Float gimbalPitchDeg, Float gimbalYawDeg, CameraAction cameraAction, Float loiterTimeS, Double cameraPhotoIntervalS, Float acceptanceRadiusM, Float yawDeg, Float cameraPhotoDistanceM) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.relativeAltitudeM = relativeAltitudeM;
        this.speedMS = speedMS;
        this.isFlyThrough = isFlyThrough;
        this.gimbalPitchDeg = gimbalPitchDeg;
        this.gimbalYawDeg = gimbalYawDeg;
        this.cameraAction = cameraAction;
        this.loiterTimeS = loiterTimeS;
        this.cameraPhotoIntervalS = cameraPhotoIntervalS;
        this.acceptanceRadiusM = acceptanceRadiusM;
        this.yawDeg = yawDeg;
        this.cameraPhotoDistanceM = cameraPhotoDistanceM;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getRelativeAltitudeM() {
        return relativeAltitudeM;
      }
      public Float getSpeedMS() {
        return speedMS;
      }
      public Boolean getIsFlyThrough() {
        return isFlyThrough;
      }
      public Float getGimbalPitchDeg() {
        return gimbalPitchDeg;
      }
      public Float getGimbalYawDeg() {
        return gimbalYawDeg;
      }
      public CameraAction getCameraAction() {
        return cameraAction;
      }
      public Float getLoiterTimeS() {
        return loiterTimeS;
      }
      public Double getCameraPhotoIntervalS() {
        return cameraPhotoIntervalS;
      }
      public Float getAcceptanceRadiusM() {
        return acceptanceRadiusM;
      }
      public Float getYawDeg() {
        return yawDeg;
      }
      public Float getCameraPhotoDistanceM() {
        return cameraPhotoDistanceM;
      }

      protected MissionProto.MissionItem rpcMissionItem() {
        return MissionProto.MissionItem.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setRelativeAltitudeM(this.relativeAltitudeM)
          .setSpeedMS(this.speedMS)
          .setIsFlyThrough(this.isFlyThrough)
          .setGimbalPitchDeg(this.gimbalPitchDeg)
          .setGimbalYawDeg(this.gimbalYawDeg)
          .setCameraAction(this.cameraAction.rpcCameraAction())
          .setLoiterTimeS(this.loiterTimeS)
          .setCameraPhotoIntervalS(this.cameraPhotoIntervalS)
          .setAcceptanceRadiusM(this.acceptanceRadiusM)
          .setYawDeg(this.yawDeg)
          .setCameraPhotoDistanceM(this.cameraPhotoDistanceM)
          .build();
      }

      protected static MissionItem translateFromRpc(MissionProto.MissionItem rpcMissionItem) {
        return new MissionItem(
                rpcMissionItem.getLatitudeDeg(),
                rpcMissionItem.getLongitudeDeg(),
                rpcMissionItem.getRelativeAltitudeM(),
                rpcMissionItem.getSpeedMS(),
                rpcMissionItem.getIsFlyThrough(),
                rpcMissionItem.getGimbalPitchDeg(),
                rpcMissionItem.getGimbalYawDeg(),
                CameraAction.translateFromRpc(rpcMissionItem.getCameraAction()),
                rpcMissionItem.getLoiterTimeS(),
                rpcMissionItem.getCameraPhotoIntervalS(),
                rpcMissionItem.getAcceptanceRadiusM(),
                rpcMissionItem.getYawDeg(),
                rpcMissionItem.getCameraPhotoDistanceM());
      }
    }


    public static class MissionPlan {
      private List<MissionItem> missionItems;

      public MissionPlan(List<MissionItem> missionItems) {
        this.missionItems = missionItems;
      }
      public List<MissionItem> getMissionItems() {
        return missionItems;
      }

      protected MissionProto.MissionPlan rpcMissionPlan() {
        return MissionProto.MissionPlan.newBuilder()
          .addAllMissionItems(missionItems.stream().map(MissionItem::rpcMissionItem).collect(Collectors.toList()))
          .build();
      }

      protected static MissionPlan translateFromRpc(MissionProto.MissionPlan rpcMissionPlan) {
        return new MissionPlan(
                    rpcMissionPlan.getMissionItemsList().stream().map(MissionItem::translateFromRpc).collect(Collectors.toList()));
      }
    }


    public static class MissionProgress {
      private Integer current;
      private Integer total;

      public MissionProgress(Integer current, Integer total) {
        this.current = current;
        this.total = total;
      }
      public Integer getCurrent() {
        return current;
      }
      public Integer getTotal() {
        return total;
      }

      protected MissionProto.MissionProgress rpcMissionProgress() {
        return MissionProto.MissionProgress.newBuilder()
          .setCurrent(this.current)
          .setTotal(this.total)
          .build();
      }

      protected static MissionProgress translateFromRpc(MissionProto.MissionProgress rpcMissionProgress) {
        return new MissionProgress(
                rpcMissionProgress.getCurrent(),
                rpcMissionProgress.getTotal());
      }
    }


    public static class MissionResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_SUCCESS;
            }
          }, 
          ERROR {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_ERROR;
            }
          }, 
          TOO_MANY_MISSION_ITEMS {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_TOO_MANY_MISSION_ITEMS;
            }
          }, 
          BUSY {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_BUSY;
            }
          }, 
          TIMEOUT {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_TIMEOUT;
            }
          }, 
          INVALID_ARGUMENT {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_INVALID_ARGUMENT;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_UNSUPPORTED;
            }
          }, 
          NO_MISSION_AVAILABLE {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_NO_MISSION_AVAILABLE;
            }
          }, 
          UNSUPPORTED_MISSION_CMD {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_UNSUPPORTED_MISSION_CMD;
            }
          }, 
          TRANSFER_CANCELLED {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_TRANSFER_CANCELLED;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          NEXT {
            @Override
            protected MissionProto.MissionResult.Result rpcResult() {
              return MissionProto.MissionResult.Result.RESULT_NEXT;
            }
          };

          protected static Result translateFromRpc(MissionProto.MissionResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_TOO_MANY_MISSION_ITEMS: 
                return Result.TOO_MANY_MISSION_ITEMS;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_INVALID_ARGUMENT: 
                return Result.INVALID_ARGUMENT;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
              case RESULT_NO_MISSION_AVAILABLE: 
                return Result.NO_MISSION_AVAILABLE;
              case RESULT_UNSUPPORTED_MISSION_CMD: 
                return Result.UNSUPPORTED_MISSION_CMD;
              case RESULT_TRANSFER_CANCELLED: 
                return Result.TRANSFER_CANCELLED;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_NEXT: 
                return Result.NEXT;
            }
          }

          protected abstract MissionProto.MissionResult.Result rpcResult();
        }

      public MissionResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected MissionProto.MissionResult rpcMissionResult() {
        return MissionProto.MissionResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static MissionResult translateFromRpc(MissionProto.MissionResult rpcMissionResult) {
        return new MissionResult(
                Result.translateFromRpc(rpcMissionResult.getResult()),
                rpcMissionResult.getResultStr());
      }
    }


    public static class ProgressData {
      private Float progress;

      public ProgressData(Float progress) {
        this.progress = progress;
      }
      public Float getProgress() {
        return progress;
      }

      protected MissionProto.ProgressData rpcProgressData() {
        return MissionProto.ProgressData.newBuilder()
          .setProgress(this.progress)
          .build();
      }

      protected static ProgressData translateFromRpc(MissionProto.ProgressData rpcProgressData) {
        return new ProgressData(
                rpcProgressData.getProgress());
      }
    }


    public static class ProgressDataOrMission {
      private Boolean hasProgress;
      private Float progress;
      private Boolean hasMission;
      private MissionPlan missionPlan;

      public ProgressDataOrMission(Boolean hasProgress, Float progress, Boolean hasMission, MissionPlan missionPlan) {
        this.hasProgress = hasProgress;
        this.progress = progress;
        this.hasMission = hasMission;
        this.missionPlan = missionPlan;
      }
      public Boolean getHasProgress() {
        return hasProgress;
      }
      public Float getProgress() {
        return progress;
      }
      public Boolean getHasMission() {
        return hasMission;
      }
      public MissionPlan getMissionPlan() {
        return missionPlan;
      }

      protected MissionProto.ProgressDataOrMission rpcProgressDataOrMission() {
        return MissionProto.ProgressDataOrMission.newBuilder()
          .setHasProgress(this.hasProgress)
          .setProgress(this.progress)
          .setHasMission(this.hasMission)
          .setMissionPlan(this.missionPlan.rpcMissionPlan())
          .build();
      }

      protected static ProgressDataOrMission translateFromRpc(MissionProto.ProgressDataOrMission rpcProgressDataOrMission) {
        return new ProgressDataOrMission(
                rpcProgressDataOrMission.getHasProgress(),
                rpcProgressDataOrMission.getProgress(),
                rpcProgressDataOrMission.getHasMission(),
                MissionPlan.translateFromRpc(rpcProgressDataOrMission.getMissionPlan()));
      }
    }


    @CheckReturnValue
    public Completable uploadMission(@NonNull MissionPlan missionPlan) {

      MissionProto.UploadMissionRequest request = MissionProto.UploadMissionRequest.newBuilder()
        .setMissionPlan(missionPlan.rpcMissionPlan())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.uploadMission(request, new StreamObserver<MissionProto.UploadMissionResponse>() {

          @Override
          public void onNext(MissionProto.UploadMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Finite stream
    private Flowable<Mission.ProgressData> createUploadMissionWithProgress(MissionPlan missionPlan) {
      MissionProto.SubscribeUploadMissionWithProgressRequest request = MissionProto.SubscribeUploadMissionWithProgressRequest.newBuilder()
        .setMissionPlan(missionPlan.rpcMissionPlan())
        .build();

      Flowable<Mission.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeUploadMissionWithProgress(request, new StreamObserver<MissionProto.UploadMissionWithProgressResponse>() {

          @Override
          public void onNext(MissionProto.UploadMissionWithProgressResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new MissionException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Mission.ProgressData> uploadMissionWithProgress(@NonNull MissionPlan missionPlan) {
      return createUploadMissionWithProgress(missionPlan);
    }


    @CheckReturnValue
    public Completable cancelMissionUpload() {

      MissionProto.CancelMissionUploadRequest request = MissionProto.CancelMissionUploadRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.cancelMissionUpload(request, new StreamObserver<MissionProto.CancelMissionUploadResponse>() {

          @Override
          public void onNext(MissionProto.CancelMissionUploadResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Mission.MissionPlan> downloadMission() {
      MissionProto.DownloadMissionRequest request = MissionProto.DownloadMissionRequest.newBuilder()
        .build();

      Single<Mission.MissionPlan> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.downloadMission(request, new StreamObserver<MissionProto.DownloadMissionResponse>() {

          @Override
          public void onNext(MissionProto.DownloadMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(MissionPlan.translateFromRpc(value.getMissionPlan()));
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }

    // Finite stream
    private Flowable<Mission.ProgressDataOrMission> createDownloadMissionWithProgress() {
      MissionProto.SubscribeDownloadMissionWithProgressRequest request = MissionProto.SubscribeDownloadMissionWithProgressRequest.newBuilder()
        .build();

      Flowable<Mission.ProgressDataOrMission> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeDownloadMissionWithProgress(request, new StreamObserver<MissionProto.DownloadMissionWithProgressResponse>() {

          @Override
          public void onNext(MissionProto.DownloadMissionWithProgressResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressDataOrMission.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new MissionException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Mission.ProgressDataOrMission> downloadMissionWithProgress() {
      return createDownloadMissionWithProgress();
    }


    @CheckReturnValue
    public Completable cancelMissionDownload() {

      MissionProto.CancelMissionDownloadRequest request = MissionProto.CancelMissionDownloadRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.cancelMissionDownload(request, new StreamObserver<MissionProto.CancelMissionDownloadResponse>() {

          @Override
          public void onNext(MissionProto.CancelMissionDownloadResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable startMission() {

      MissionProto.StartMissionRequest request = MissionProto.StartMissionRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.startMission(request, new StreamObserver<MissionProto.StartMissionResponse>() {

          @Override
          public void onNext(MissionProto.StartMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable pauseMission() {

      MissionProto.PauseMissionRequest request = MissionProto.PauseMissionRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.pauseMission(request, new StreamObserver<MissionProto.PauseMissionResponse>() {

          @Override
          public void onNext(MissionProto.PauseMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable clearMission() {

      MissionProto.ClearMissionRequest request = MissionProto.ClearMissionRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.clearMission(request, new StreamObserver<MissionProto.ClearMissionResponse>() {

          @Override
          public void onNext(MissionProto.ClearMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setCurrentMissionItem(@NonNull Integer index) {

      MissionProto.SetCurrentMissionItemRequest request = MissionProto.SetCurrentMissionItemRequest.newBuilder()
        .setIndex(index)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setCurrentMissionItem(request, new StreamObserver<MissionProto.SetCurrentMissionItemResponse>() {

          @Override
          public void onNext(MissionProto.SetCurrentMissionItemResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Boolean> isMissionFinished() {
      MissionProto.IsMissionFinishedRequest request = MissionProto.IsMissionFinishedRequest.newBuilder()
        .build();

      Single<Boolean> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.isMissionFinished(request, new StreamObserver<MissionProto.IsMissionFinishedResponse>() {

          @Override
          public void onNext(MissionProto.IsMissionFinishedResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getIsFinished());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<Mission.MissionProgress> missionProgressProcessor = PublishProcessor.create();
    private final Flowable<Mission.MissionProgress> missionProgress = missionProgressProcessor.onBackpressureBuffer().share();;
    private volatile boolean isMissionProgressInitialized = false;

    private void processMissionProgress() {
      MissionProto.SubscribeMissionProgressRequest request = MissionProto.SubscribeMissionProgressRequest.newBuilder()
        .build();

      stub.subscribeMissionProgress(request, new StreamObserver<MissionProto.MissionProgressResponse>() {

        @Override
        public void onNext(MissionProto.MissionProgressResponse value) {
          missionProgressProcessor.onNext(MissionProgress.translateFromRpc(value.getMissionProgress()));
        }

        @Override
        public void onError(Throwable t) {
          missionProgressProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          missionProgressProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Mission.MissionProgress> getMissionProgress() {
      if (!isMissionProgressInitialized) {
        synchronized (this) {
          if (!isMissionProgressInitialized) {
            MavsdkEventQueue.executor().execute(() -> processMissionProgress());
            isMissionProgressInitialized = true;
          }
        }
      }
      return missionProgress;
    }


    @CheckReturnValue
    public Single<Boolean> getReturnToLaunchAfterMission() {
      MissionProto.GetReturnToLaunchAfterMissionRequest request = MissionProto.GetReturnToLaunchAfterMissionRequest.newBuilder()
        .build();

      Single<Boolean> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getReturnToLaunchAfterMission(request, new StreamObserver<MissionProto.GetReturnToLaunchAfterMissionResponse>() {

          @Override
          public void onNext(MissionProto.GetReturnToLaunchAfterMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onSuccess(value.getEnable());
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setReturnToLaunchAfterMission(@NonNull Boolean enable) {

      MissionProto.SetReturnToLaunchAfterMissionRequest request = MissionProto.SetReturnToLaunchAfterMissionRequest.newBuilder()
        .setEnable(enable)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setReturnToLaunchAfterMission(request, new StreamObserver<MissionProto.SetReturnToLaunchAfterMissionResponse>() {

          @Override
          public void onNext(MissionProto.SetReturnToLaunchAfterMissionResponse value) {
            MissionResult result = MissionResult.translateFromRpc(value.getMissionResult());

            if (result.result != MissionResult.Result.SUCCESS) {
              emitter.onError(new MissionException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}