package io.mavsdk.follow_me;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FollowMe implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(FollowMe.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private FollowMeServiceGrpc.FollowMeServiceStub stub;

  private volatile boolean isInitialized = false;

  public FollowMe(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public FollowMe() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = FollowMeServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class FollowMeException extends MavsdkException {
    private FollowMeResult.Result code;
    private String description;

    public FollowMeException(FollowMeResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public FollowMeResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class Config {
      private Float minHeightM;
      private Float followDistanceM;
      private FollowDirection followDirection;
      private Float responsiveness;
      
        public enum FollowDirection {
          
          NONE {
            @Override
            protected FollowMeProto.Config.FollowDirection rpcFollowDirection() {
              return FollowMeProto.Config.FollowDirection.FOLLOW_DIRECTION_NONE;
            }
          }, 
          BEHIND {
            @Override
            protected FollowMeProto.Config.FollowDirection rpcFollowDirection() {
              return FollowMeProto.Config.FollowDirection.FOLLOW_DIRECTION_BEHIND;
            }
          }, 
          FRONT {
            @Override
            protected FollowMeProto.Config.FollowDirection rpcFollowDirection() {
              return FollowMeProto.Config.FollowDirection.FOLLOW_DIRECTION_FRONT;
            }
          }, 
          FRONT_RIGHT {
            @Override
            protected FollowMeProto.Config.FollowDirection rpcFollowDirection() {
              return FollowMeProto.Config.FollowDirection.FOLLOW_DIRECTION_FRONT_RIGHT;
            }
          }, 
          FRONT_LEFT {
            @Override
            protected FollowMeProto.Config.FollowDirection rpcFollowDirection() {
              return FollowMeProto.Config.FollowDirection.FOLLOW_DIRECTION_FRONT_LEFT;
            }
          };

          protected static FollowDirection translateFromRpc(FollowMeProto.Config.FollowDirection rpcFollowDirection) {
            switch (rpcFollowDirection) {
              case FOLLOW_DIRECTION_NONE: default: 
                return FollowDirection.NONE;
              case FOLLOW_DIRECTION_BEHIND: 
                return FollowDirection.BEHIND;
              case FOLLOW_DIRECTION_FRONT: 
                return FollowDirection.FRONT;
              case FOLLOW_DIRECTION_FRONT_RIGHT: 
                return FollowDirection.FRONT_RIGHT;
              case FOLLOW_DIRECTION_FRONT_LEFT: 
                return FollowDirection.FRONT_LEFT;
            }
          }

          protected abstract FollowMeProto.Config.FollowDirection rpcFollowDirection();
        }

      public Config(Float minHeightM, Float followDistanceM, FollowDirection followDirection, Float responsiveness) {
        this.minHeightM = minHeightM;
        this.followDistanceM = followDistanceM;
        this.followDirection = followDirection;
        this.responsiveness = responsiveness;
      }
      public Float getMinHeightM() {
        return minHeightM;
      }
      public Float getFollowDistanceM() {
        return followDistanceM;
      }
      public FollowDirection getFollowDirection() {
        return followDirection;
      }
      public Float getResponsiveness() {
        return responsiveness;
      }

      protected FollowMeProto.Config rpcConfig() {
        return FollowMeProto.Config.newBuilder()
          .setMinHeightM(this.minHeightM)
          .setFollowDistanceM(this.followDistanceM)
          .setFollowDirection(this.followDirection.rpcFollowDirection())
          .setResponsiveness(this.responsiveness)
          .build();
      }

      protected static Config translateFromRpc(FollowMeProto.Config rpcConfig) {
        return new Config(
                rpcConfig.getMinHeightM(),
                rpcConfig.getFollowDistanceM(),
                FollowDirection.translateFromRpc(rpcConfig.getFollowDirection()),
                rpcConfig.getResponsiveness());
      }
    }


    public static class TargetLocation {
      private Double latitudeDeg;
      private Double longitudeDeg;
      private Float absoluteAltitudeM;
      private Float velocityXMS;
      private Float velocityYMS;
      private Float velocityZMS;

      public TargetLocation(Double latitudeDeg, Double longitudeDeg, Float absoluteAltitudeM, Float velocityXMS, Float velocityYMS, Float velocityZMS) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.absoluteAltitudeM = absoluteAltitudeM;
        this.velocityXMS = velocityXMS;
        this.velocityYMS = velocityYMS;
        this.velocityZMS = velocityZMS;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }
      public Float getAbsoluteAltitudeM() {
        return absoluteAltitudeM;
      }
      public Float getVelocityXMS() {
        return velocityXMS;
      }
      public Float getVelocityYMS() {
        return velocityYMS;
      }
      public Float getVelocityZMS() {
        return velocityZMS;
      }

      protected FollowMeProto.TargetLocation rpcTargetLocation() {
        return FollowMeProto.TargetLocation.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .setAbsoluteAltitudeM(this.absoluteAltitudeM)
          .setVelocityXMS(this.velocityXMS)
          .setVelocityYMS(this.velocityYMS)
          .setVelocityZMS(this.velocityZMS)
          .build();
      }

      protected static TargetLocation translateFromRpc(FollowMeProto.TargetLocation rpcTargetLocation) {
        return new TargetLocation(
                rpcTargetLocation.getLatitudeDeg(),
                rpcTargetLocation.getLongitudeDeg(),
                rpcTargetLocation.getAbsoluteAltitudeM(),
                rpcTargetLocation.getVelocityXMS(),
                rpcTargetLocation.getVelocityYMS(),
                rpcTargetLocation.getVelocityZMS());
      }
    }


    public static class FollowMeResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_TIMEOUT;
            }
          }, 
          NOT_ACTIVE {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_NOT_ACTIVE;
            }
          }, 
          SET_CONFIG_FAILED {
            @Override
            protected FollowMeProto.FollowMeResult.Result rpcResult() {
              return FollowMeProto.FollowMeResult.Result.RESULT_SET_CONFIG_FAILED;
            }
          };

          protected static Result translateFromRpc(FollowMeProto.FollowMeResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_NOT_ACTIVE: 
                return Result.NOT_ACTIVE;
              case RESULT_SET_CONFIG_FAILED: 
                return Result.SET_CONFIG_FAILED;
            }
          }

          protected abstract FollowMeProto.FollowMeResult.Result rpcResult();
        }

      public FollowMeResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected FollowMeProto.FollowMeResult rpcFollowMeResult() {
        return FollowMeProto.FollowMeResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static FollowMeResult translateFromRpc(FollowMeProto.FollowMeResult rpcFollowMeResult) {
        return new FollowMeResult(
                Result.translateFromRpc(rpcFollowMeResult.getResult()),
                rpcFollowMeResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Single<FollowMe.Config> getConfig() {
      FollowMeProto.GetConfigRequest request = FollowMeProto.GetConfigRequest.newBuilder()
        .build();

      Single<FollowMe.Config> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getConfig(request, new StreamObserver<FollowMeProto.GetConfigResponse>() {

          @Override
          public void onNext(FollowMeProto.GetConfigResponse value) {
              emitter.onSuccess(Config.translateFromRpc(value.getConfig()));
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setConfig(@NonNull Config config) {

      FollowMeProto.SetConfigRequest request = FollowMeProto.SetConfigRequest.newBuilder()
        .setConfig(config.rpcConfig())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setConfig(request, new StreamObserver<FollowMeProto.SetConfigResponse>() {

          @Override
          public void onNext(FollowMeProto.SetConfigResponse value) {
            FollowMeResult result = FollowMeResult.translateFromRpc(value.getFollowMeResult());

            if (result.result != FollowMeResult.Result.SUCCESS) {
              emitter.onError(new FollowMeException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<Boolean> isActive() {
      FollowMeProto.IsActiveRequest request = FollowMeProto.IsActiveRequest.newBuilder()
        .build();

      Single<Boolean> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.isActive(request, new StreamObserver<FollowMeProto.IsActiveResponse>() {

          @Override
          public void onNext(FollowMeProto.IsActiveResponse value) {
              emitter.onSuccess(value.getIsActive());
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setTargetLocation(@NonNull TargetLocation location) {

      FollowMeProto.SetTargetLocationRequest request = FollowMeProto.SetTargetLocationRequest.newBuilder()
        .setLocation(location.rpcTargetLocation())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setTargetLocation(request, new StreamObserver<FollowMeProto.SetTargetLocationResponse>() {

          @Override
          public void onNext(FollowMeProto.SetTargetLocationResponse value) {
            FollowMeResult result = FollowMeResult.translateFromRpc(value.getFollowMeResult());

            if (result.result != FollowMeResult.Result.SUCCESS) {
              emitter.onError(new FollowMeException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<FollowMe.TargetLocation> getLastLocation() {
      FollowMeProto.GetLastLocationRequest request = FollowMeProto.GetLastLocationRequest.newBuilder()
        .build();

      Single<FollowMe.TargetLocation> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getLastLocation(request, new StreamObserver<FollowMeProto.GetLastLocationResponse>() {

          @Override
          public void onNext(FollowMeProto.GetLastLocationResponse value) {
              emitter.onSuccess(TargetLocation.translateFromRpc(value.getLocation()));
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable start() {

      FollowMeProto.StartRequest request = FollowMeProto.StartRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.start(request, new StreamObserver<FollowMeProto.StartResponse>() {

          @Override
          public void onNext(FollowMeProto.StartResponse value) {
            FollowMeResult result = FollowMeResult.translateFromRpc(value.getFollowMeResult());

            if (result.result != FollowMeResult.Result.SUCCESS) {
              emitter.onError(new FollowMeException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable stop() {

      FollowMeProto.StopRequest request = FollowMeProto.StopRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.stop(request, new StreamObserver<FollowMeProto.StopResponse>() {

          @Override
          public void onNext(FollowMeProto.StopResponse value) {
            FollowMeResult result = FollowMeResult.translateFromRpc(value.getFollowMeResult());

            if (result.result != FollowMeResult.Result.SUCCESS) {
              emitter.onError(new FollowMeException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}