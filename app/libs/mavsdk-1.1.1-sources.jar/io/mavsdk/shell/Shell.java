package io.mavsdk.shell;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Shell implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Shell.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ShellServiceGrpc.ShellServiceStub stub;

  private volatile boolean isInitialized = false;

  public Shell(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Shell() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ShellServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ShellException extends MavsdkException {
    private ShellResult.Result code;
    private String description;

    public ShellException(ShellResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ShellResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class ShellResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ShellProto.ShellResult.Result rpcResult() {
              return ShellProto.ShellResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ShellProto.ShellResult.Result rpcResult() {
              return ShellProto.ShellResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ShellProto.ShellResult.Result rpcResult() {
              return ShellProto.ShellResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected ShellProto.ShellResult.Result rpcResult() {
              return ShellProto.ShellResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          NO_RESPONSE {
            @Override
            protected ShellProto.ShellResult.Result rpcResult() {
              return ShellProto.ShellResult.Result.RESULT_NO_RESPONSE;
            }
          }, 
          BUSY {
            @Override
            protected ShellProto.ShellResult.Result rpcResult() {
              return ShellProto.ShellResult.Result.RESULT_BUSY;
            }
          };

          protected static Result translateFromRpc(ShellProto.ShellResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_NO_RESPONSE: 
                return Result.NO_RESPONSE;
              case RESULT_BUSY: 
                return Result.BUSY;
            }
          }

          protected abstract ShellProto.ShellResult.Result rpcResult();
        }

      public ShellResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ShellProto.ShellResult rpcShellResult() {
        return ShellProto.ShellResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ShellResult translateFromRpc(ShellProto.ShellResult rpcShellResult) {
        return new ShellResult(
                Result.translateFromRpc(rpcShellResult.getResult()),
                rpcShellResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable send(@NonNull String command) {

      ShellProto.SendRequest request = ShellProto.SendRequest.newBuilder()
        .setCommand(command)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.send(request, new StreamObserver<ShellProto.SendResponse>() {

          @Override
          public void onNext(ShellProto.SendResponse value) {
            ShellResult result = ShellResult.translateFromRpc(value.getShellResult());

            if (result.result != ShellResult.Result.SUCCESS) {
              emitter.onError(new ShellException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }

    // Infinite stream
    private final FlowableProcessor<String> receiveProcessor = PublishProcessor.create();
    private final Flowable<String> receive = receiveProcessor.onBackpressureBuffer().share();;
    private volatile boolean isReceiveInitialized = false;

    private void processReceive() {
      ShellProto.SubscribeReceiveRequest request = ShellProto.SubscribeReceiveRequest.newBuilder()
        .build();

      stub.subscribeReceive(request, new StreamObserver<ShellProto.ReceiveResponse>() {

        @Override
        public void onNext(ShellProto.ReceiveResponse value) {
          receiveProcessor.onNext(value.getData());
        }

        @Override
        public void onError(Throwable t) {
          receiveProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          receiveProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<String> getReceive() {
      if (!isReceiveInitialized) {
        synchronized (this) {
          if (!isReceiveInitialized) {
            MavsdkEventQueue.executor().execute(() -> processReceive());
            isReceiveInitialized = true;
          }
        }
      }
      return receive;
    }


}