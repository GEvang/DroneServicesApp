package io.mavsdk.component_information;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Access component information such as parameters.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.42.1)",
    comments = "Source: component_information/component_information.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ComponentInformationServiceGrpc {

  private ComponentInformationServiceGrpc() {}

  public static final String SERVICE_NAME = "mavsdk.rpc.component_information.ComponentInformationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest,
      io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse> getAccessFloatParamsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AccessFloatParams",
      requestType = io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest.class,
      responseType = io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest,
      io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse> getAccessFloatParamsMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest, io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse> getAccessFloatParamsMethod;
    if ((getAccessFloatParamsMethod = ComponentInformationServiceGrpc.getAccessFloatParamsMethod) == null) {
      synchronized (ComponentInformationServiceGrpc.class) {
        if ((getAccessFloatParamsMethod = ComponentInformationServiceGrpc.getAccessFloatParamsMethod) == null) {
          ComponentInformationServiceGrpc.getAccessFloatParamsMethod = getAccessFloatParamsMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest, io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AccessFloatParams"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getAccessFloatParamsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest,
      io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse> getSubscribeFloatParamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SubscribeFloatParam",
      requestType = io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest.class,
      responseType = io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest,
      io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse> getSubscribeFloatParamMethod() {
    io.grpc.MethodDescriptor<io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest, io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse> getSubscribeFloatParamMethod;
    if ((getSubscribeFloatParamMethod = ComponentInformationServiceGrpc.getSubscribeFloatParamMethod) == null) {
      synchronized (ComponentInformationServiceGrpc.class) {
        if ((getSubscribeFloatParamMethod = ComponentInformationServiceGrpc.getSubscribeFloatParamMethod) == null) {
          ComponentInformationServiceGrpc.getSubscribeFloatParamMethod = getSubscribeFloatParamMethod =
              io.grpc.MethodDescriptor.<io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest, io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SubscribeFloatParam"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSubscribeFloatParamMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ComponentInformationServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServiceStub>() {
        @java.lang.Override
        public ComponentInformationServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ComponentInformationServiceStub(channel, callOptions);
        }
      };
    return ComponentInformationServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ComponentInformationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServiceBlockingStub>() {
        @java.lang.Override
        public ComponentInformationServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ComponentInformationServiceBlockingStub(channel, callOptions);
        }
      };
    return ComponentInformationServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ComponentInformationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ComponentInformationServiceFutureStub>() {
        @java.lang.Override
        public ComponentInformationServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ComponentInformationServiceFutureStub(channel, callOptions);
        }
      };
    return ComponentInformationServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Access component information such as parameters.
   * </pre>
   */
  public static abstract class ComponentInformationServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * List available float params.
     * </pre>
     */
    public void accessFloatParams(io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAccessFloatParamsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Subscribe to float param changes/updates.
     * </pre>
     */
    public void subscribeFloatParam(io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSubscribeFloatParamMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getAccessFloatParamsMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest,
                io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse>(
                  this, METHODID_ACCESS_FLOAT_PARAMS)))
          .addMethod(
            getSubscribeFloatParamMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest,
                io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse>(
                  this, METHODID_SUBSCRIBE_FLOAT_PARAM)))
          .build();
    }
  }

  /**
   * <pre>
   * Access component information such as parameters.
   * </pre>
   */
  public static final class ComponentInformationServiceStub extends io.grpc.stub.AbstractAsyncStub<ComponentInformationServiceStub> {
    private ComponentInformationServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ComponentInformationServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ComponentInformationServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * List available float params.
     * </pre>
     */
    public void accessFloatParams(io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAccessFloatParamsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Subscribe to float param changes/updates.
     * </pre>
     */
    public void subscribeFloatParam(io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest request,
        io.grpc.stub.StreamObserver<io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getSubscribeFloatParamMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Access component information such as parameters.
   * </pre>
   */
  public static final class ComponentInformationServiceBlockingStub extends io.grpc.stub.AbstractBlockingStub<ComponentInformationServiceBlockingStub> {
    private ComponentInformationServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ComponentInformationServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ComponentInformationServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * List available float params.
     * </pre>
     */
    public io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse accessFloatParams(io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAccessFloatParamsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Subscribe to float param changes/updates.
     * </pre>
     */
    public java.util.Iterator<io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse> subscribeFloatParam(
        io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getSubscribeFloatParamMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Access component information such as parameters.
   * </pre>
   */
  public static final class ComponentInformationServiceFutureStub extends io.grpc.stub.AbstractFutureStub<ComponentInformationServiceFutureStub> {
    private ComponentInformationServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ComponentInformationServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ComponentInformationServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * List available float params.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse> accessFloatParams(
        io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAccessFloatParamsMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_ACCESS_FLOAT_PARAMS = 0;
  private static final int METHODID_SUBSCRIBE_FLOAT_PARAM = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ComponentInformationServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ComponentInformationServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_ACCESS_FLOAT_PARAMS:
          serviceImpl.accessFloatParams((io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.component_information.ComponentInformationProto.AccessFloatParamsResponse>) responseObserver);
          break;
        case METHODID_SUBSCRIBE_FLOAT_PARAM:
          serviceImpl.subscribeFloatParam((io.mavsdk.component_information.ComponentInformationProto.SubscribeFloatParamRequest) request,
              (io.grpc.stub.StreamObserver<io.mavsdk.component_information.ComponentInformationProto.FloatParamResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ComponentInformationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .addMethod(getAccessFloatParamsMethod())
              .addMethod(getSubscribeFloatParamMethod())
              .build();
        }
      }
    }
    return result;
  }
}
