package io.mavsdk.core;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Core implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Core.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private CoreServiceGrpc.CoreServiceStub stub;

  private volatile boolean isInitialized = false;

  public Core(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Core() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = CoreServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  


    public static class ConnectionState {
      private Boolean isConnected;

      public ConnectionState(Boolean isConnected) {
        this.isConnected = isConnected;
      }
      public Boolean getIsConnected() {
        return isConnected;
      }

      protected CoreProto.ConnectionState rpcConnectionState() {
        return CoreProto.ConnectionState.newBuilder()
          .setIsConnected(this.isConnected)
          .build();
      }

      protected static ConnectionState translateFromRpc(CoreProto.ConnectionState rpcConnectionState) {
        return new ConnectionState(
                rpcConnectionState.getIsConnected());
      }
    }



    // Infinite stream
    private final FlowableProcessor<Core.ConnectionState> connectionStateProcessor = PublishProcessor.create();
    private final Flowable<Core.ConnectionState> connectionState = connectionStateProcessor.onBackpressureBuffer().share();;
    private volatile boolean isConnectionStateInitialized = false;

    private void processConnectionState() {
      CoreProto.SubscribeConnectionStateRequest request = CoreProto.SubscribeConnectionStateRequest.newBuilder()
        .build();

      stub.subscribeConnectionState(request, new StreamObserver<CoreProto.ConnectionStateResponse>() {

        @Override
        public void onNext(CoreProto.ConnectionStateResponse value) {
          connectionStateProcessor.onNext(ConnectionState.translateFromRpc(value.getConnectionState()));
        }

        @Override
        public void onError(Throwable t) {
          connectionStateProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          connectionStateProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Core.ConnectionState> getConnectionState() {
      if (!isConnectionStateInitialized) {
        synchronized (this) {
          if (!isConnectionStateInitialized) {
            MavsdkEventQueue.executor().execute(() -> processConnectionState());
            isConnectionStateInitialized = true;
          }
        }
      }
      return connectionState;
    }


    @CheckReturnValue
    public Completable setMavlinkTimeout(@NonNull Double timeoutS) {

      CoreProto.SetMavlinkTimeoutRequest request = CoreProto.SetMavlinkTimeoutRequest.newBuilder()
        .setTimeoutS(timeoutS)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setMavlinkTimeout(request, new StreamObserver<CoreProto.SetMavlinkTimeoutResponse>() {

          @Override
          public void onNext(CoreProto.SetMavlinkTimeoutResponse value) {
            emitter.onComplete();
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}