package io.mavsdk.geofence;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Geofence implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Geofence.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private GeofenceServiceGrpc.GeofenceServiceStub stub;

  private volatile boolean isInitialized = false;

  public Geofence(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Geofence() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = GeofenceServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class GeofenceException extends MavsdkException {
    private GeofenceResult.Result code;
    private String description;

    public GeofenceException(GeofenceResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public GeofenceResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class Point {
      private Double latitudeDeg;
      private Double longitudeDeg;

      public Point(Double latitudeDeg, Double longitudeDeg) {
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
      }
      public Double getLatitudeDeg() {
        return latitudeDeg;
      }
      public Double getLongitudeDeg() {
        return longitudeDeg;
      }

      protected GeofenceProto.Point rpcPoint() {
        return GeofenceProto.Point.newBuilder()
          .setLatitudeDeg(this.latitudeDeg)
          .setLongitudeDeg(this.longitudeDeg)
          .build();
      }

      protected static Point translateFromRpc(GeofenceProto.Point rpcPoint) {
        return new Point(
                rpcPoint.getLatitudeDeg(),
                rpcPoint.getLongitudeDeg());
      }
    }


    public static class Polygon {
      private List<Point> points;
      private FenceType fenceType;
      
        public enum FenceType {
          
          INCLUSION {
            @Override
            protected GeofenceProto.Polygon.FenceType rpcFenceType() {
              return GeofenceProto.Polygon.FenceType.FENCE_TYPE_INCLUSION;
            }
          }, 
          EXCLUSION {
            @Override
            protected GeofenceProto.Polygon.FenceType rpcFenceType() {
              return GeofenceProto.Polygon.FenceType.FENCE_TYPE_EXCLUSION;
            }
          };

          protected static FenceType translateFromRpc(GeofenceProto.Polygon.FenceType rpcFenceType) {
            switch (rpcFenceType) {
              case FENCE_TYPE_INCLUSION: default: 
                return FenceType.INCLUSION;
              case FENCE_TYPE_EXCLUSION: 
                return FenceType.EXCLUSION;
            }
          }

          protected abstract GeofenceProto.Polygon.FenceType rpcFenceType();
        }

      public Polygon(List<Point> points, FenceType fenceType) {
        this.points = points;
        this.fenceType = fenceType;
      }
      public List<Point> getPoints() {
        return points;
      }
      public FenceType getFenceType() {
        return fenceType;
      }

      protected GeofenceProto.Polygon rpcPolygon() {
        return GeofenceProto.Polygon.newBuilder()
          .addAllPoints(points.stream().map(Point::rpcPoint).collect(Collectors.toList()))
          .setFenceType(this.fenceType.rpcFenceType())
          .build();
      }

      protected static Polygon translateFromRpc(GeofenceProto.Polygon rpcPolygon) {
        return new Polygon(
                    rpcPolygon.getPointsList().stream().map(Point::translateFromRpc).collect(Collectors.toList()),
                FenceType.translateFromRpc(rpcPolygon.getFenceType()));
      }
    }


    public static class GeofenceResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_SUCCESS;
            }
          }, 
          ERROR {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_ERROR;
            }
          }, 
          TOO_MANY_GEOFENCE_ITEMS {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_TOO_MANY_GEOFENCE_ITEMS;
            }
          }, 
          BUSY {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_BUSY;
            }
          }, 
          TIMEOUT {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_TIMEOUT;
            }
          }, 
          INVALID_ARGUMENT {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_INVALID_ARGUMENT;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected GeofenceProto.GeofenceResult.Result rpcResult() {
              return GeofenceProto.GeofenceResult.Result.RESULT_NO_SYSTEM;
            }
          };

          protected static Result translateFromRpc(GeofenceProto.GeofenceResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_ERROR: 
                return Result.ERROR;
              case RESULT_TOO_MANY_GEOFENCE_ITEMS: 
                return Result.TOO_MANY_GEOFENCE_ITEMS;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_INVALID_ARGUMENT: 
                return Result.INVALID_ARGUMENT;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
            }
          }

          protected abstract GeofenceProto.GeofenceResult.Result rpcResult();
        }

      public GeofenceResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected GeofenceProto.GeofenceResult rpcGeofenceResult() {
        return GeofenceProto.GeofenceResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static GeofenceResult translateFromRpc(GeofenceProto.GeofenceResult rpcGeofenceResult) {
        return new GeofenceResult(
                Result.translateFromRpc(rpcGeofenceResult.getResult()),
                rpcGeofenceResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable uploadGeofence(@NonNull List<Polygon> polygons) {

      GeofenceProto.UploadGeofenceRequest request = GeofenceProto.UploadGeofenceRequest.newBuilder()
        .addAllPolygons(polygons.stream().map(elem -> elem.rpcPolygon())::iterator)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.uploadGeofence(request, new StreamObserver<GeofenceProto.UploadGeofenceResponse>() {

          @Override
          public void onNext(GeofenceProto.UploadGeofenceResponse value) {
            GeofenceResult result = GeofenceResult.translateFromRpc(value.getGeofenceResult());

            if (result.result != GeofenceResult.Result.SUCCESS) {
              emitter.onError(new GeofenceException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable clearGeofence() {

      GeofenceProto.ClearGeofenceRequest request = GeofenceProto.ClearGeofenceRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.clearGeofence(request, new StreamObserver<GeofenceProto.ClearGeofenceResponse>() {

          @Override
          public void onNext(GeofenceProto.ClearGeofenceResponse value) {
            GeofenceResult result = GeofenceResult.translateFromRpc(value.getGeofenceResult());

            if (result.result != GeofenceResult.Result.SUCCESS) {
              emitter.onError(new GeofenceException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}