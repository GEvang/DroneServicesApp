package io.mavsdk.mocap;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Mocap implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Mocap.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private MocapServiceGrpc.MocapServiceStub stub;

  private volatile boolean isInitialized = false;

  public Mocap(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Mocap() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = MocapServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class MocapException extends MavsdkException {
    private MocapResult.Result code;
    private String description;

    public MocapException(MocapResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public MocapResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class PositionBody {
      private Float xM;
      private Float yM;
      private Float zM;

      public PositionBody(Float xM, Float yM, Float zM) {
        this.xM = xM;
        this.yM = yM;
        this.zM = zM;
      }
      public Float getXM() {
        return xM;
      }
      public Float getYM() {
        return yM;
      }
      public Float getZM() {
        return zM;
      }

      protected MocapProto.PositionBody rpcPositionBody() {
        return MocapProto.PositionBody.newBuilder()
          .setXM(this.xM)
          .setYM(this.yM)
          .setZM(this.zM)
          .build();
      }

      protected static PositionBody translateFromRpc(MocapProto.PositionBody rpcPositionBody) {
        return new PositionBody(
                rpcPositionBody.getXM(),
                rpcPositionBody.getYM(),
                rpcPositionBody.getZM());
      }
    }


    public static class AngleBody {
      private Float rollRad;
      private Float pitchRad;
      private Float yawRad;

      public AngleBody(Float rollRad, Float pitchRad, Float yawRad) {
        this.rollRad = rollRad;
        this.pitchRad = pitchRad;
        this.yawRad = yawRad;
      }
      public Float getRollRad() {
        return rollRad;
      }
      public Float getPitchRad() {
        return pitchRad;
      }
      public Float getYawRad() {
        return yawRad;
      }

      protected MocapProto.AngleBody rpcAngleBody() {
        return MocapProto.AngleBody.newBuilder()
          .setRollRad(this.rollRad)
          .setPitchRad(this.pitchRad)
          .setYawRad(this.yawRad)
          .build();
      }

      protected static AngleBody translateFromRpc(MocapProto.AngleBody rpcAngleBody) {
        return new AngleBody(
                rpcAngleBody.getRollRad(),
                rpcAngleBody.getPitchRad(),
                rpcAngleBody.getYawRad());
      }
    }


    public static class SpeedBody {
      private Float xMS;
      private Float yMS;
      private Float zMS;

      public SpeedBody(Float xMS, Float yMS, Float zMS) {
        this.xMS = xMS;
        this.yMS = yMS;
        this.zMS = zMS;
      }
      public Float getXMS() {
        return xMS;
      }
      public Float getYMS() {
        return yMS;
      }
      public Float getZMS() {
        return zMS;
      }

      protected MocapProto.SpeedBody rpcSpeedBody() {
        return MocapProto.SpeedBody.newBuilder()
          .setXMS(this.xMS)
          .setYMS(this.yMS)
          .setZMS(this.zMS)
          .build();
      }

      protected static SpeedBody translateFromRpc(MocapProto.SpeedBody rpcSpeedBody) {
        return new SpeedBody(
                rpcSpeedBody.getXMS(),
                rpcSpeedBody.getYMS(),
                rpcSpeedBody.getZMS());
      }
    }


    public static class AngularVelocityBody {
      private Float rollRadS;
      private Float pitchRadS;
      private Float yawRadS;

      public AngularVelocityBody(Float rollRadS, Float pitchRadS, Float yawRadS) {
        this.rollRadS = rollRadS;
        this.pitchRadS = pitchRadS;
        this.yawRadS = yawRadS;
      }
      public Float getRollRadS() {
        return rollRadS;
      }
      public Float getPitchRadS() {
        return pitchRadS;
      }
      public Float getYawRadS() {
        return yawRadS;
      }

      protected MocapProto.AngularVelocityBody rpcAngularVelocityBody() {
        return MocapProto.AngularVelocityBody.newBuilder()
          .setRollRadS(this.rollRadS)
          .setPitchRadS(this.pitchRadS)
          .setYawRadS(this.yawRadS)
          .build();
      }

      protected static AngularVelocityBody translateFromRpc(MocapProto.AngularVelocityBody rpcAngularVelocityBody) {
        return new AngularVelocityBody(
                rpcAngularVelocityBody.getRollRadS(),
                rpcAngularVelocityBody.getPitchRadS(),
                rpcAngularVelocityBody.getYawRadS());
      }
    }


    public static class Covariance {
      private List<Float> covarianceMatrix;

      public Covariance(List<Float> covarianceMatrix) {
        this.covarianceMatrix = covarianceMatrix;
      }
      public List<Float> getCovarianceMatrix() {
        return covarianceMatrix;
      }

      protected MocapProto.Covariance rpcCovariance() {
        return MocapProto.Covariance.newBuilder()
          .addAllCovarianceMatrix(covarianceMatrix)
          .build();
      }

      protected static Covariance translateFromRpc(MocapProto.Covariance rpcCovariance) {
        return new Covariance(
                    rpcCovariance.getCovarianceMatrixList());
      }
    }


    public static class Quaternion {
      private Float w;
      private Float x;
      private Float y;
      private Float z;

      public Quaternion(Float w, Float x, Float y, Float z) {
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
      }
      public Float getW() {
        return w;
      }
      public Float getX() {
        return x;
      }
      public Float getY() {
        return y;
      }
      public Float getZ() {
        return z;
      }

      protected MocapProto.Quaternion rpcQuaternion() {
        return MocapProto.Quaternion.newBuilder()
          .setW(this.w)
          .setX(this.x)
          .setY(this.y)
          .setZ(this.z)
          .build();
      }

      protected static Quaternion translateFromRpc(MocapProto.Quaternion rpcQuaternion) {
        return new Quaternion(
                rpcQuaternion.getW(),
                rpcQuaternion.getX(),
                rpcQuaternion.getY(),
                rpcQuaternion.getZ());
      }
    }


    public static class VisionPositionEstimate {
      private Long timeUsec;
      private PositionBody positionBody;
      private AngleBody angleBody;
      private Covariance poseCovariance;

      public VisionPositionEstimate(Long timeUsec, PositionBody positionBody, AngleBody angleBody, Covariance poseCovariance) {
        this.timeUsec = timeUsec;
        this.positionBody = positionBody;
        this.angleBody = angleBody;
        this.poseCovariance = poseCovariance;
      }
      public Long getTimeUsec() {
        return timeUsec;
      }
      public PositionBody getPositionBody() {
        return positionBody;
      }
      public AngleBody getAngleBody() {
        return angleBody;
      }
      public Covariance getPoseCovariance() {
        return poseCovariance;
      }

      protected MocapProto.VisionPositionEstimate rpcVisionPositionEstimate() {
        return MocapProto.VisionPositionEstimate.newBuilder()
          .setTimeUsec(this.timeUsec)
          .setPositionBody(this.positionBody.rpcPositionBody())
          .setAngleBody(this.angleBody.rpcAngleBody())
          .setPoseCovariance(this.poseCovariance.rpcCovariance())
          .build();
      }

      protected static VisionPositionEstimate translateFromRpc(MocapProto.VisionPositionEstimate rpcVisionPositionEstimate) {
        return new VisionPositionEstimate(
                rpcVisionPositionEstimate.getTimeUsec(),
                PositionBody.translateFromRpc(rpcVisionPositionEstimate.getPositionBody()),
                AngleBody.translateFromRpc(rpcVisionPositionEstimate.getAngleBody()),
                Covariance.translateFromRpc(rpcVisionPositionEstimate.getPoseCovariance()));
      }
    }


    public static class AttitudePositionMocap {
      private Long timeUsec;
      private Quaternion q;
      private PositionBody positionBody;
      private Covariance poseCovariance;

      public AttitudePositionMocap(Long timeUsec, Quaternion q, PositionBody positionBody, Covariance poseCovariance) {
        this.timeUsec = timeUsec;
        this.q = q;
        this.positionBody = positionBody;
        this.poseCovariance = poseCovariance;
      }
      public Long getTimeUsec() {
        return timeUsec;
      }
      public Quaternion getQ() {
        return q;
      }
      public PositionBody getPositionBody() {
        return positionBody;
      }
      public Covariance getPoseCovariance() {
        return poseCovariance;
      }

      protected MocapProto.AttitudePositionMocap rpcAttitudePositionMocap() {
        return MocapProto.AttitudePositionMocap.newBuilder()
          .setTimeUsec(this.timeUsec)
          .setQ(this.q.rpcQuaternion())
          .setPositionBody(this.positionBody.rpcPositionBody())
          .setPoseCovariance(this.poseCovariance.rpcCovariance())
          .build();
      }

      protected static AttitudePositionMocap translateFromRpc(MocapProto.AttitudePositionMocap rpcAttitudePositionMocap) {
        return new AttitudePositionMocap(
                rpcAttitudePositionMocap.getTimeUsec(),
                Quaternion.translateFromRpc(rpcAttitudePositionMocap.getQ()),
                PositionBody.translateFromRpc(rpcAttitudePositionMocap.getPositionBody()),
                Covariance.translateFromRpc(rpcAttitudePositionMocap.getPoseCovariance()));
      }
    }


    public static class Odometry {
      private Long timeUsec;
      private MavFrame frameId;
      private PositionBody positionBody;
      private Quaternion q;
      private SpeedBody speedBody;
      private AngularVelocityBody angularVelocityBody;
      private Covariance poseCovariance;
      private Covariance velocityCovariance;
      
        public enum MavFrame {
          
          MOCAP_NED {
            @Override
            protected MocapProto.Odometry.MavFrame rpcMavFrame() {
              return MocapProto.Odometry.MavFrame.MAV_FRAME_MOCAP_NED;
            }
          }, 
          LOCAL_FRD {
            @Override
            protected MocapProto.Odometry.MavFrame rpcMavFrame() {
              return MocapProto.Odometry.MavFrame.MAV_FRAME_LOCAL_FRD;
            }
          };

          protected static MavFrame translateFromRpc(MocapProto.Odometry.MavFrame rpcMavFrame) {
            switch (rpcMavFrame) {
              case MAV_FRAME_MOCAP_NED: default: 
                return MavFrame.MOCAP_NED;
              case MAV_FRAME_LOCAL_FRD: 
                return MavFrame.LOCAL_FRD;
            }
          }

          protected abstract MocapProto.Odometry.MavFrame rpcMavFrame();
        }

      public Odometry(Long timeUsec, MavFrame frameId, PositionBody positionBody, Quaternion q, SpeedBody speedBody, AngularVelocityBody angularVelocityBody, Covariance poseCovariance, Covariance velocityCovariance) {
        this.timeUsec = timeUsec;
        this.frameId = frameId;
        this.positionBody = positionBody;
        this.q = q;
        this.speedBody = speedBody;
        this.angularVelocityBody = angularVelocityBody;
        this.poseCovariance = poseCovariance;
        this.velocityCovariance = velocityCovariance;
      }
      public Long getTimeUsec() {
        return timeUsec;
      }
      public MavFrame getFrameId() {
        return frameId;
      }
      public PositionBody getPositionBody() {
        return positionBody;
      }
      public Quaternion getQ() {
        return q;
      }
      public SpeedBody getSpeedBody() {
        return speedBody;
      }
      public AngularVelocityBody getAngularVelocityBody() {
        return angularVelocityBody;
      }
      public Covariance getPoseCovariance() {
        return poseCovariance;
      }
      public Covariance getVelocityCovariance() {
        return velocityCovariance;
      }

      protected MocapProto.Odometry rpcOdometry() {
        return MocapProto.Odometry.newBuilder()
          .setTimeUsec(this.timeUsec)
          .setFrameId(this.frameId.rpcMavFrame())
          .setPositionBody(this.positionBody.rpcPositionBody())
          .setQ(this.q.rpcQuaternion())
          .setSpeedBody(this.speedBody.rpcSpeedBody())
          .setAngularVelocityBody(this.angularVelocityBody.rpcAngularVelocityBody())
          .setPoseCovariance(this.poseCovariance.rpcCovariance())
          .setVelocityCovariance(this.velocityCovariance.rpcCovariance())
          .build();
      }

      protected static Odometry translateFromRpc(MocapProto.Odometry rpcOdometry) {
        return new Odometry(
                rpcOdometry.getTimeUsec(),
                MavFrame.translateFromRpc(rpcOdometry.getFrameId()),
                PositionBody.translateFromRpc(rpcOdometry.getPositionBody()),
                Quaternion.translateFromRpc(rpcOdometry.getQ()),
                SpeedBody.translateFromRpc(rpcOdometry.getSpeedBody()),
                AngularVelocityBody.translateFromRpc(rpcOdometry.getAngularVelocityBody()),
                Covariance.translateFromRpc(rpcOdometry.getPoseCovariance()),
                Covariance.translateFromRpc(rpcOdometry.getVelocityCovariance()));
      }
    }


    public static class MocapResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected MocapProto.MocapResult.Result rpcResult() {
              return MocapProto.MocapResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected MocapProto.MocapResult.Result rpcResult() {
              return MocapProto.MocapResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected MocapProto.MocapResult.Result rpcResult() {
              return MocapProto.MocapResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected MocapProto.MocapResult.Result rpcResult() {
              return MocapProto.MocapResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          INVALID_REQUEST_DATA {
            @Override
            protected MocapProto.MocapResult.Result rpcResult() {
              return MocapProto.MocapResult.Result.RESULT_INVALID_REQUEST_DATA;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected MocapProto.MocapResult.Result rpcResult() {
              return MocapProto.MocapResult.Result.RESULT_UNSUPPORTED;
            }
          };

          protected static Result translateFromRpc(MocapProto.MocapResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_INVALID_REQUEST_DATA: 
                return Result.INVALID_REQUEST_DATA;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
            }
          }

          protected abstract MocapProto.MocapResult.Result rpcResult();
        }

      public MocapResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected MocapProto.MocapResult rpcMocapResult() {
        return MocapProto.MocapResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static MocapResult translateFromRpc(MocapProto.MocapResult rpcMocapResult) {
        return new MocapResult(
                Result.translateFromRpc(rpcMocapResult.getResult()),
                rpcMocapResult.getResultStr());
      }
    }


    @CheckReturnValue
    public Completable setVisionPositionEstimate(@NonNull VisionPositionEstimate visionPositionEstimate) {

      MocapProto.SetVisionPositionEstimateRequest request = MocapProto.SetVisionPositionEstimateRequest.newBuilder()
        .setVisionPositionEstimate(visionPositionEstimate.rpcVisionPositionEstimate())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setVisionPositionEstimate(request, new StreamObserver<MocapProto.SetVisionPositionEstimateResponse>() {

          @Override
          public void onNext(MocapProto.SetVisionPositionEstimateResponse value) {
            MocapResult result = MocapResult.translateFromRpc(value.getMocapResult());

            if (result.result != MocapResult.Result.SUCCESS) {
              emitter.onError(new MocapException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setAttitudePositionMocap(@NonNull AttitudePositionMocap attitudePositionMocap) {

      MocapProto.SetAttitudePositionMocapRequest request = MocapProto.SetAttitudePositionMocapRequest.newBuilder()
        .setAttitudePositionMocap(attitudePositionMocap.rpcAttitudePositionMocap())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setAttitudePositionMocap(request, new StreamObserver<MocapProto.SetAttitudePositionMocapResponse>() {

          @Override
          public void onNext(MocapProto.SetAttitudePositionMocapResponse value) {
            MocapResult result = MocapResult.translateFromRpc(value.getMocapResult());

            if (result.result != MocapResult.Result.SUCCESS) {
              emitter.onError(new MocapException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setOdometry(@NonNull Odometry odometry) {

      MocapProto.SetOdometryRequest request = MocapProto.SetOdometryRequest.newBuilder()
        .setOdometry(odometry.rpcOdometry())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setOdometry(request, new StreamObserver<MocapProto.SetOdometryResponse>() {

          @Override
          public void onNext(MocapProto.SetOdometryResponse value) {
            MocapResult result = MocapResult.translateFromRpc(value.getMocapResult());

            if (result.result != MocapResult.Result.SUCCESS) {
              emitter.onError(new MocapException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}