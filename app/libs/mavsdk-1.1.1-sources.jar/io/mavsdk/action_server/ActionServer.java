package io.mavsdk.action_server;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ActionServer implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(ActionServer.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private ActionServerServiceGrpc.ActionServerServiceStub stub;

  private volatile boolean isInitialized = false;

  public ActionServer(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public ActionServer() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = ActionServerServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class ActionServerException extends MavsdkException {
    private ActionServerResult.Result code;
    private String description;

    public ActionServerException(ActionServerResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public ActionServerResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  
    public enum FlightMode {
      
      UNKNOWN {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_UNKNOWN;
        }
      }, 
      READY {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_READY;
        }
      }, 
      TAKEOFF {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_TAKEOFF;
        }
      }, 
      HOLD {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_HOLD;
        }
      }, 
      MISSION {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_MISSION;
        }
      }, 
      RETURN_TO_LAUNCH {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_RETURN_TO_LAUNCH;
        }
      }, 
      LAND {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_LAND;
        }
      }, 
      OFFBOARD {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_OFFBOARD;
        }
      }, 
      FOLLOW_ME {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_FOLLOW_ME;
        }
      }, 
      MANUAL {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_MANUAL;
        }
      }, 
      ALTCTL {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_ALTCTL;
        }
      }, 
      POSCTL {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_POSCTL;
        }
      }, 
      ACRO {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_ACRO;
        }
      }, 
      STABILIZED {
        @Override
        protected ActionServerProto.FlightMode rpcFlightMode() {
          return ActionServerProto.FlightMode.FLIGHT_MODE_STABILIZED;
        }
      };

      protected static FlightMode translateFromRpc(ActionServerProto.FlightMode rpcFlightMode) {
        switch (rpcFlightMode) {
          case FLIGHT_MODE_UNKNOWN: default: 
            return FlightMode.UNKNOWN;
          case FLIGHT_MODE_READY: 
            return FlightMode.READY;
          case FLIGHT_MODE_TAKEOFF: 
            return FlightMode.TAKEOFF;
          case FLIGHT_MODE_HOLD: 
            return FlightMode.HOLD;
          case FLIGHT_MODE_MISSION: 
            return FlightMode.MISSION;
          case FLIGHT_MODE_RETURN_TO_LAUNCH: 
            return FlightMode.RETURN_TO_LAUNCH;
          case FLIGHT_MODE_LAND: 
            return FlightMode.LAND;
          case FLIGHT_MODE_OFFBOARD: 
            return FlightMode.OFFBOARD;
          case FLIGHT_MODE_FOLLOW_ME: 
            return FlightMode.FOLLOW_ME;
          case FLIGHT_MODE_MANUAL: 
            return FlightMode.MANUAL;
          case FLIGHT_MODE_ALTCTL: 
            return FlightMode.ALTCTL;
          case FLIGHT_MODE_POSCTL: 
            return FlightMode.POSCTL;
          case FLIGHT_MODE_ACRO: 
            return FlightMode.ACRO;
          case FLIGHT_MODE_STABILIZED: 
            return FlightMode.STABILIZED;
        }
      }

      protected abstract ActionServerProto.FlightMode rpcFlightMode();
    }


    public static class AllowableFlightModes {
      private Boolean canAutoMode;
      private Boolean canGuidedMode;
      private Boolean canStabilizeMode;

      public AllowableFlightModes(Boolean canAutoMode, Boolean canGuidedMode, Boolean canStabilizeMode) {
        this.canAutoMode = canAutoMode;
        this.canGuidedMode = canGuidedMode;
        this.canStabilizeMode = canStabilizeMode;
      }
      public Boolean getCanAutoMode() {
        return canAutoMode;
      }
      public Boolean getCanGuidedMode() {
        return canGuidedMode;
      }
      public Boolean getCanStabilizeMode() {
        return canStabilizeMode;
      }

      protected ActionServerProto.AllowableFlightModes rpcAllowableFlightModes() {
        return ActionServerProto.AllowableFlightModes.newBuilder()
          .setCanAutoMode(this.canAutoMode)
          .setCanGuidedMode(this.canGuidedMode)
          .setCanStabilizeMode(this.canStabilizeMode)
          .build();
      }

      protected static AllowableFlightModes translateFromRpc(ActionServerProto.AllowableFlightModes rpcAllowableFlightModes) {
        return new AllowableFlightModes(
                rpcAllowableFlightModes.getCanAutoMode(),
                rpcAllowableFlightModes.getCanGuidedMode(),
                rpcAllowableFlightModes.getCanStabilizeMode());
      }
    }


    public static class ArmDisarm {
      private Boolean arm;
      private Boolean force;

      public ArmDisarm(Boolean arm, Boolean force) {
        this.arm = arm;
        this.force = force;
      }
      public Boolean getArm() {
        return arm;
      }
      public Boolean getForce() {
        return force;
      }

      protected ActionServerProto.ArmDisarm rpcArmDisarm() {
        return ActionServerProto.ArmDisarm.newBuilder()
          .setArm(this.arm)
          .setForce(this.force)
          .build();
      }

      protected static ArmDisarm translateFromRpc(ActionServerProto.ArmDisarm rpcArmDisarm) {
        return new ArmDisarm(
                rpcArmDisarm.getArm(),
                rpcArmDisarm.getForce());
      }
    }


    public static class ActionServerResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_SUCCESS;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          COMMAND_DENIED_LANDED_STATE_UNKNOWN {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_COMMAND_DENIED_LANDED_STATE_UNKNOWN;
            }
          }, 
          COMMAND_DENIED_NOT_LANDED {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_COMMAND_DENIED_NOT_LANDED;
            }
          }, 
          TIMEOUT {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_TIMEOUT;
            }
          }, 
          VTOL_TRANSITION_SUPPORT_UNKNOWN {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_VTOL_TRANSITION_SUPPORT_UNKNOWN;
            }
          }, 
          NO_VTOL_TRANSITION_SUPPORT {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_NO_VTOL_TRANSITION_SUPPORT;
            }
          }, 
          PARAMETER_ERROR {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_PARAMETER_ERROR;
            }
          }, 
          NEXT {
            @Override
            protected ActionServerProto.ActionServerResult.Result rpcResult() {
              return ActionServerProto.ActionServerResult.Result.RESULT_NEXT;
            }
          };

          protected static Result translateFromRpc(ActionServerProto.ActionServerResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_COMMAND_DENIED_LANDED_STATE_UNKNOWN: 
                return Result.COMMAND_DENIED_LANDED_STATE_UNKNOWN;
              case RESULT_COMMAND_DENIED_NOT_LANDED: 
                return Result.COMMAND_DENIED_NOT_LANDED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_VTOL_TRANSITION_SUPPORT_UNKNOWN: 
                return Result.VTOL_TRANSITION_SUPPORT_UNKNOWN;
              case RESULT_NO_VTOL_TRANSITION_SUPPORT: 
                return Result.NO_VTOL_TRANSITION_SUPPORT;
              case RESULT_PARAMETER_ERROR: 
                return Result.PARAMETER_ERROR;
              case RESULT_NEXT: 
                return Result.NEXT;
            }
          }

          protected abstract ActionServerProto.ActionServerResult.Result rpcResult();
        }

      public ActionServerResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected ActionServerProto.ActionServerResult rpcActionServerResult() {
        return ActionServerProto.ActionServerResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static ActionServerResult translateFromRpc(ActionServerProto.ActionServerResult rpcActionServerResult) {
        return new ActionServerResult(
                Result.translateFromRpc(rpcActionServerResult.getResult()),
                rpcActionServerResult.getResultStr());
      }
    }



    // Infinite stream
    private final FlowableProcessor<ActionServer.ArmDisarm> armDisarmProcessor = PublishProcessor.create();
    private final Flowable<ActionServer.ArmDisarm> armDisarm = armDisarmProcessor.onBackpressureBuffer().share();;
    private volatile boolean isArmDisarmInitialized = false;

    private void processArmDisarm() {
      ActionServerProto.SubscribeArmDisarmRequest request = ActionServerProto.SubscribeArmDisarmRequest.newBuilder()
        .build();

      stub.subscribeArmDisarm(request, new StreamObserver<ActionServerProto.ArmDisarmResponse>() {

        @Override
        public void onNext(ActionServerProto.ArmDisarmResponse value) {
          armDisarmProcessor.onNext(ArmDisarm.translateFromRpc(value.getArm()));
        }

        @Override
        public void onError(Throwable t) {
          armDisarmProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          armDisarmProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<ActionServer.ArmDisarm> getArmDisarm() {
      if (!isArmDisarmInitialized) {
        synchronized (this) {
          if (!isArmDisarmInitialized) {
            MavsdkEventQueue.executor().execute(() -> processArmDisarm());
            isArmDisarmInitialized = true;
          }
        }
      }
      return armDisarm;
    }



    // Infinite stream
    private final FlowableProcessor<ActionServer.FlightMode> flightModeChangeProcessor = PublishProcessor.create();
    private final Flowable<ActionServer.FlightMode> flightModeChange = flightModeChangeProcessor.onBackpressureBuffer().share();;
    private volatile boolean isFlightModeChangeInitialized = false;

    private void processFlightModeChange() {
      ActionServerProto.SubscribeFlightModeChangeRequest request = ActionServerProto.SubscribeFlightModeChangeRequest.newBuilder()
        .build();

      stub.subscribeFlightModeChange(request, new StreamObserver<ActionServerProto.FlightModeChangeResponse>() {

        @Override
        public void onNext(ActionServerProto.FlightModeChangeResponse value) {
          flightModeChangeProcessor.onNext(FlightMode.translateFromRpc(value.getFlightMode()));
        }

        @Override
        public void onError(Throwable t) {
          flightModeChangeProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          flightModeChangeProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<ActionServer.FlightMode> getFlightModeChange() {
      if (!isFlightModeChangeInitialized) {
        synchronized (this) {
          if (!isFlightModeChangeInitialized) {
            MavsdkEventQueue.executor().execute(() -> processFlightModeChange());
            isFlightModeChangeInitialized = true;
          }
        }
      }
      return flightModeChange;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> takeoffProcessor = PublishProcessor.create();
    private final Flowable<Boolean> takeoff = takeoffProcessor.onBackpressureBuffer().share();;
    private volatile boolean isTakeoffInitialized = false;

    private void processTakeoff() {
      ActionServerProto.SubscribeTakeoffRequest request = ActionServerProto.SubscribeTakeoffRequest.newBuilder()
        .build();

      stub.subscribeTakeoff(request, new StreamObserver<ActionServerProto.TakeoffResponse>() {

        @Override
        public void onNext(ActionServerProto.TakeoffResponse value) {
          takeoffProcessor.onNext(value.getTakeoff());
        }

        @Override
        public void onError(Throwable t) {
          takeoffProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          takeoffProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getTakeoff() {
      if (!isTakeoffInitialized) {
        synchronized (this) {
          if (!isTakeoffInitialized) {
            MavsdkEventQueue.executor().execute(() -> processTakeoff());
            isTakeoffInitialized = true;
          }
        }
      }
      return takeoff;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> landProcessor = PublishProcessor.create();
    private final Flowable<Boolean> land = landProcessor.onBackpressureBuffer().share();;
    private volatile boolean isLandInitialized = false;

    private void processLand() {
      ActionServerProto.SubscribeLandRequest request = ActionServerProto.SubscribeLandRequest.newBuilder()
        .build();

      stub.subscribeLand(request, new StreamObserver<ActionServerProto.LandResponse>() {

        @Override
        public void onNext(ActionServerProto.LandResponse value) {
          landProcessor.onNext(value.getLand());
        }

        @Override
        public void onError(Throwable t) {
          landProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          landProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getLand() {
      if (!isLandInitialized) {
        synchronized (this) {
          if (!isLandInitialized) {
            MavsdkEventQueue.executor().execute(() -> processLand());
            isLandInitialized = true;
          }
        }
      }
      return land;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> rebootProcessor = PublishProcessor.create();
    private final Flowable<Boolean> reboot = rebootProcessor.onBackpressureBuffer().share();;
    private volatile boolean isRebootInitialized = false;

    private void processReboot() {
      ActionServerProto.SubscribeRebootRequest request = ActionServerProto.SubscribeRebootRequest.newBuilder()
        .build();

      stub.subscribeReboot(request, new StreamObserver<ActionServerProto.RebootResponse>() {

        @Override
        public void onNext(ActionServerProto.RebootResponse value) {
          rebootProcessor.onNext(value.getReboot());
        }

        @Override
        public void onError(Throwable t) {
          rebootProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          rebootProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getReboot() {
      if (!isRebootInitialized) {
        synchronized (this) {
          if (!isRebootInitialized) {
            MavsdkEventQueue.executor().execute(() -> processReboot());
            isRebootInitialized = true;
          }
        }
      }
      return reboot;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> shutdownProcessor = PublishProcessor.create();
    private final Flowable<Boolean> shutdown = shutdownProcessor.onBackpressureBuffer().share();;
    private volatile boolean isShutdownInitialized = false;

    private void processShutdown() {
      ActionServerProto.SubscribeShutdownRequest request = ActionServerProto.SubscribeShutdownRequest.newBuilder()
        .build();

      stub.subscribeShutdown(request, new StreamObserver<ActionServerProto.ShutdownResponse>() {

        @Override
        public void onNext(ActionServerProto.ShutdownResponse value) {
          shutdownProcessor.onNext(value.getShutdown());
        }

        @Override
        public void onError(Throwable t) {
          shutdownProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          shutdownProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getShutdown() {
      if (!isShutdownInitialized) {
        synchronized (this) {
          if (!isShutdownInitialized) {
            MavsdkEventQueue.executor().execute(() -> processShutdown());
            isShutdownInitialized = true;
          }
        }
      }
      return shutdown;
    }



    // Infinite stream
    private final FlowableProcessor<Boolean> terminateProcessor = PublishProcessor.create();
    private final Flowable<Boolean> terminate = terminateProcessor.onBackpressureBuffer().share();;
    private volatile boolean isTerminateInitialized = false;

    private void processTerminate() {
      ActionServerProto.SubscribeTerminateRequest request = ActionServerProto.SubscribeTerminateRequest.newBuilder()
        .build();

      stub.subscribeTerminate(request, new StreamObserver<ActionServerProto.TerminateResponse>() {

        @Override
        public void onNext(ActionServerProto.TerminateResponse value) {
          terminateProcessor.onNext(value.getTerminate());
        }

        @Override
        public void onError(Throwable t) {
          terminateProcessor.onError(t);
        }

        @Override
        public void onCompleted() {
          terminateProcessor.onComplete();
        }
      });
    }

    @CheckReturnValue
    public Flowable<Boolean> getTerminate() {
      if (!isTerminateInitialized) {
        synchronized (this) {
          if (!isTerminateInitialized) {
            MavsdkEventQueue.executor().execute(() -> processTerminate());
            isTerminateInitialized = true;
          }
        }
      }
      return terminate;
    }


    @CheckReturnValue
    public Completable setAllowTakeoff(@NonNull Boolean allowTakeoff) {

      ActionServerProto.SetAllowTakeoffRequest request = ActionServerProto.SetAllowTakeoffRequest.newBuilder()
        .setAllowTakeoff(allowTakeoff)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setAllowTakeoff(request, new StreamObserver<ActionServerProto.SetAllowTakeoffResponse>() {

          @Override
          public void onNext(ActionServerProto.SetAllowTakeoffResponse value) {
            ActionServerResult result = ActionServerResult.translateFromRpc(value.getActionServerResult());

            if (result.result != ActionServerResult.Result.SUCCESS) {
              emitter.onError(new ActionServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setArmable(@NonNull Boolean armable, @NonNull Boolean forceArmable) {

      ActionServerProto.SetArmableRequest request = ActionServerProto.SetArmableRequest.newBuilder()
        .setArmable(armable)
        .setForceArmable(forceArmable)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setArmable(request, new StreamObserver<ActionServerProto.SetArmableResponse>() {

          @Override
          public void onNext(ActionServerProto.SetArmableResponse value) {
            ActionServerResult result = ActionServerResult.translateFromRpc(value.getActionServerResult());

            if (result.result != ActionServerResult.Result.SUCCESS) {
              emitter.onError(new ActionServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setDisarmable(@NonNull Boolean disarmable, @NonNull Boolean forceDisarmable) {

      ActionServerProto.SetDisarmableRequest request = ActionServerProto.SetDisarmableRequest.newBuilder()
        .setDisarmable(disarmable)
        .setForceDisarmable(forceDisarmable)
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setDisarmable(request, new StreamObserver<ActionServerProto.SetDisarmableResponse>() {

          @Override
          public void onNext(ActionServerProto.SetDisarmableResponse value) {
            ActionServerResult result = ActionServerResult.translateFromRpc(value.getActionServerResult());

            if (result.result != ActionServerResult.Result.SUCCESS) {
              emitter.onError(new ActionServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Completable setAllowableFlightModes(@NonNull AllowableFlightModes flightModes) {

      ActionServerProto.SetAllowableFlightModesRequest request = ActionServerProto.SetAllowableFlightModesRequest.newBuilder()
        .setFlightModes(flightModes.rpcAllowableFlightModes())
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.setAllowableFlightModes(request, new StreamObserver<ActionServerProto.SetAllowableFlightModesResponse>() {

          @Override
          public void onNext(ActionServerProto.SetAllowableFlightModesResponse value) {
            ActionServerResult result = ActionServerResult.translateFromRpc(value.getActionServerResult());

            if (result.result != ActionServerResult.Result.SUCCESS) {
              emitter.onError(new ActionServerException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
    @CheckReturnValue
    public Single<ActionServer.AllowableFlightModes> getAllowableFlightModes() {
      ActionServerProto.GetAllowableFlightModesRequest request = ActionServerProto.GetAllowableFlightModesRequest.newBuilder()
        .build();

      Single<ActionServer.AllowableFlightModes> single = Single.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.getAllowableFlightModes(request, new StreamObserver<ActionServerProto.GetAllowableFlightModesResponse>() {

          @Override
          public void onNext(ActionServerProto.GetAllowableFlightModesResponse value) {
              emitter.onSuccess(AllowableFlightModes.translateFromRpc(value.getFlightModes()));
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return single.subscribeOn(Schedulers.io());
    }
}