package io.mavsdk.calibration;

import io.mavsdk.Plugin;
import io.mavsdk.MavsdkException;
import io.mavsdk.MavsdkEventQueue;
import io.grpc.ManagedChannel;
import io.grpc.okhttp.OkHttpChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.reactivex.Completable;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.annotations.CheckReturnValue;
import io.reactivex.annotations.NonNull;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import io.reactivex.schedulers.Schedulers;
import java.lang.String;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Calibration implements Plugin {
  private static final Logger logger = LoggerFactory.getLogger(Calibration.class);

  /*
  Wait for 100ms for plugin to initialize in the mavsdk-event-queue before calls/requests/finite streams.
  If the plugin isn't ready after this time, then it is assumed that no system was present.
   */
  private static final long PLUGIN_INIT_TIMEOUT_MS = 100;

  private final String host;
  private final int port;

  private ManagedChannel channel;
  private CalibrationServiceGrpc.CalibrationServiceStub stub;

  private volatile boolean isInitialized = false;

  public Calibration(String host, int port) {
    this.host = host;
    this.port = port;
  }

  public Calibration() {
    this("127.0.0.1", 50051);
  }

  private static ManagedChannel createChannel(String host, int port) {
    logger.trace("Building channel to " + host + ":" + port);

    return OkHttpChannelBuilder.forAddress(host, port)
        .usePlaintext()
        .build();
  }

  // Double checked locking to ensure that two threads don't initialize the plugin at the same time.
  // This is not a problem in practice, since the plugin is only initialized once.
  @Override
  public void initialize() {
    if (!isInitialized) {
      synchronized (this) {
        if (!isInitialized) {
          channel = createChannel(host, port);
          stub = CalibrationServiceGrpc.newStub(channel);

          isInitialized = true;
        } else {
          throw new IllegalStateException("Already initialized!");
        }
      }
    } else {
      throw new IllegalStateException("Already initialized!");
    }
  }

  @Override
  public void dispose() {
    if (isInitialized) {
      this.channel.shutdown();
    }
  }

  
  public class CalibrationException extends MavsdkException {
    private CalibrationResult.Result code;
    private String description;

    public CalibrationException(CalibrationResult.Result code, String description) {
      super(code + ": " + description);

      this.code = code;
      this.description = description;
    }

    public CalibrationResult.Result getCode() {
      return this.code;
    }

    public String getDescription() {
      return this.description;
    }
  }
  


    public static class CalibrationResult {
      private Result result;
      private String resultStr;
      
        public enum Result {
          
          UNKNOWN {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_UNKNOWN;
            }
          }, 
          SUCCESS {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_SUCCESS;
            }
          }, 
          NEXT {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_NEXT;
            }
          }, 
          FAILED {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_FAILED;
            }
          }, 
          NO_SYSTEM {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_NO_SYSTEM;
            }
          }, 
          CONNECTION_ERROR {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_CONNECTION_ERROR;
            }
          }, 
          BUSY {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_BUSY;
            }
          }, 
          COMMAND_DENIED {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_COMMAND_DENIED;
            }
          }, 
          TIMEOUT {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_TIMEOUT;
            }
          }, 
          CANCELLED {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_CANCELLED;
            }
          }, 
          FAILED_ARMED {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_FAILED_ARMED;
            }
          }, 
          UNSUPPORTED {
            @Override
            protected CalibrationProto.CalibrationResult.Result rpcResult() {
              return CalibrationProto.CalibrationResult.Result.RESULT_UNSUPPORTED;
            }
          };

          protected static Result translateFromRpc(CalibrationProto.CalibrationResult.Result rpcResult) {
            switch (rpcResult) {
              case RESULT_UNKNOWN: default: 
                return Result.UNKNOWN;
              case RESULT_SUCCESS: 
                return Result.SUCCESS;
              case RESULT_NEXT: 
                return Result.NEXT;
              case RESULT_FAILED: 
                return Result.FAILED;
              case RESULT_NO_SYSTEM: 
                return Result.NO_SYSTEM;
              case RESULT_CONNECTION_ERROR: 
                return Result.CONNECTION_ERROR;
              case RESULT_BUSY: 
                return Result.BUSY;
              case RESULT_COMMAND_DENIED: 
                return Result.COMMAND_DENIED;
              case RESULT_TIMEOUT: 
                return Result.TIMEOUT;
              case RESULT_CANCELLED: 
                return Result.CANCELLED;
              case RESULT_FAILED_ARMED: 
                return Result.FAILED_ARMED;
              case RESULT_UNSUPPORTED: 
                return Result.UNSUPPORTED;
            }
          }

          protected abstract CalibrationProto.CalibrationResult.Result rpcResult();
        }

      public CalibrationResult(Result result, String resultStr) {
        this.result = result;
        this.resultStr = resultStr;
      }
      public Result getResult() {
        return result;
      }
      public String getResultStr() {
        return resultStr;
      }

      protected CalibrationProto.CalibrationResult rpcCalibrationResult() {
        return CalibrationProto.CalibrationResult.newBuilder()
          .setResult(this.result.rpcResult())
          .setResultStr(this.resultStr)
          .build();
      }

      protected static CalibrationResult translateFromRpc(CalibrationProto.CalibrationResult rpcCalibrationResult) {
        return new CalibrationResult(
                Result.translateFromRpc(rpcCalibrationResult.getResult()),
                rpcCalibrationResult.getResultStr());
      }
    }


    public static class ProgressData {
      private Boolean hasProgress;
      private Float progress;
      private Boolean hasStatusText;
      private String statusText;

      public ProgressData(Boolean hasProgress, Float progress, Boolean hasStatusText, String statusText) {
        this.hasProgress = hasProgress;
        this.progress = progress;
        this.hasStatusText = hasStatusText;
        this.statusText = statusText;
      }
      public Boolean getHasProgress() {
        return hasProgress;
      }
      public Float getProgress() {
        return progress;
      }
      public Boolean getHasStatusText() {
        return hasStatusText;
      }
      public String getStatusText() {
        return statusText;
      }

      protected CalibrationProto.ProgressData rpcProgressData() {
        return CalibrationProto.ProgressData.newBuilder()
          .setHasProgress(this.hasProgress)
          .setProgress(this.progress)
          .setHasStatusText(this.hasStatusText)
          .setStatusText(this.statusText)
          .build();
      }

      protected static ProgressData translateFromRpc(CalibrationProto.ProgressData rpcProgressData) {
        return new ProgressData(
                rpcProgressData.getHasProgress(),
                rpcProgressData.getProgress(),
                rpcProgressData.getHasStatusText(),
                rpcProgressData.getStatusText());
      }
    }



    // Finite stream
    private Flowable<Calibration.ProgressData> createCalibrateGyro() {
      CalibrationProto.SubscribeCalibrateGyroRequest request = CalibrationProto.SubscribeCalibrateGyroRequest.newBuilder()
        .build();

      Flowable<Calibration.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeCalibrateGyro(request, new StreamObserver<CalibrationProto.CalibrateGyroResponse>() {

          @Override
          public void onNext(CalibrationProto.CalibrateGyroResponse value) {
            CalibrationResult result = CalibrationResult.translateFromRpc(value.getCalibrationResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new CalibrationException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Calibration.ProgressData> calibrateGyro() {
      return createCalibrateGyro();
    }



    // Finite stream
    private Flowable<Calibration.ProgressData> createCalibrateAccelerometer() {
      CalibrationProto.SubscribeCalibrateAccelerometerRequest request = CalibrationProto.SubscribeCalibrateAccelerometerRequest.newBuilder()
        .build();

      Flowable<Calibration.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeCalibrateAccelerometer(request, new StreamObserver<CalibrationProto.CalibrateAccelerometerResponse>() {

          @Override
          public void onNext(CalibrationProto.CalibrateAccelerometerResponse value) {
            CalibrationResult result = CalibrationResult.translateFromRpc(value.getCalibrationResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new CalibrationException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Calibration.ProgressData> calibrateAccelerometer() {
      return createCalibrateAccelerometer();
    }



    // Finite stream
    private Flowable<Calibration.ProgressData> createCalibrateMagnetometer() {
      CalibrationProto.SubscribeCalibrateMagnetometerRequest request = CalibrationProto.SubscribeCalibrateMagnetometerRequest.newBuilder()
        .build();

      Flowable<Calibration.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeCalibrateMagnetometer(request, new StreamObserver<CalibrationProto.CalibrateMagnetometerResponse>() {

          @Override
          public void onNext(CalibrationProto.CalibrateMagnetometerResponse value) {
            CalibrationResult result = CalibrationResult.translateFromRpc(value.getCalibrationResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new CalibrationException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Calibration.ProgressData> calibrateMagnetometer() {
      return createCalibrateMagnetometer();
    }



    // Finite stream
    private Flowable<Calibration.ProgressData> createCalibrateLevelHorizon() {
      CalibrationProto.SubscribeCalibrateLevelHorizonRequest request = CalibrationProto.SubscribeCalibrateLevelHorizonRequest.newBuilder()
        .build();

      Flowable<Calibration.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeCalibrateLevelHorizon(request, new StreamObserver<CalibrationProto.CalibrateLevelHorizonResponse>() {

          @Override
          public void onNext(CalibrationProto.CalibrateLevelHorizonResponse value) {
            CalibrationResult result = CalibrationResult.translateFromRpc(value.getCalibrationResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new CalibrationException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Calibration.ProgressData> calibrateLevelHorizon() {
      return createCalibrateLevelHorizon();
    }



    // Finite stream
    private Flowable<Calibration.ProgressData> createCalibrateGimbalAccelerometer() {
      CalibrationProto.SubscribeCalibrateGimbalAccelerometerRequest request = CalibrationProto.SubscribeCalibrateGimbalAccelerometerRequest.newBuilder()
        .build();

      Flowable<Calibration.ProgressData> flowable = Flowable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.subscribeCalibrateGimbalAccelerometer(request, new StreamObserver<CalibrationProto.CalibrateGimbalAccelerometerResponse>() {

          @Override
          public void onNext(CalibrationProto.CalibrateGimbalAccelerometerResponse value) {
            CalibrationResult result = CalibrationResult.translateFromRpc(value.getCalibrationResult());

            switch (result.result) {
              case SUCCESS:
                emitter.onComplete();
                break;
              case NEXT:
                emitter.onNext(ProgressData.translateFromRpc(value.getProgressData()));
                break;
              default:
                emitter.onError(new CalibrationException(result.result, result.resultStr));
                break;
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {
            emitter.onComplete();
          }
        });
      }, BackpressureStrategy.BUFFER);

      return flowable.subscribeOn(Schedulers.io()).share();
    }

    @CheckReturnValue
    public Flowable<Calibration.ProgressData> calibrateGimbalAccelerometer() {
      return createCalibrateGimbalAccelerometer();
    }


    @CheckReturnValue
    public Completable cancel() {

      CalibrationProto.CancelRequest request = CalibrationProto.CancelRequest.newBuilder()
        .build();

      Completable completable = Completable.create(emitter -> {
        if (!isInitialized) {
          Thread.sleep(PLUGIN_INIT_TIMEOUT_MS);
          if (!isInitialized) {
            throw new MavsdkException("No System");
          }
        }

        stub.cancel(request, new StreamObserver<CalibrationProto.CancelResponse>() {

          @Override
          public void onNext(CalibrationProto.CancelResponse value) {
            CalibrationResult result = CalibrationResult.translateFromRpc(value.getCalibrationResult());

            if (result.result != CalibrationResult.Result.SUCCESS) {
              emitter.onError(new CalibrationException(result.result, result.resultStr));
            } else {
              emitter.onComplete();
            }
          }

          @Override
          public void onError(Throwable t) {
            emitter.onError(t);
          }

          @Override
          public void onCompleted() {}
        });
      });

      return completable.subscribeOn(Schedulers.io());
    }
}